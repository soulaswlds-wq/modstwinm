package com.twnmmod

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.concurrent.ConcurrentLinkedQueue

sealed interface AuthState {
    data class SignedOut(val error: String? = null) : AuthState
    object Busy : AuthState
    data class Waiting(val device: DeviceCode) : AuthState
    object SignedIn : AuthState
}

data class ChannelsState(
    val list: List<ChannelRef> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
)

data class ChatState(
    val messages: List<ChatMsg> = emptyList(),
    val status: String = "",
    val connected: Boolean = false,
    val settings: ChatSettings = ChatSettings(),
    val stream: StreamInfo? = null,
    val self: SelfState = SelfState(),
)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)
    private val authApi = Auth(store)
    private val api = Helix(authApi)
    private val queue = ConcurrentLinkedQueue<IrcEvent>()
    private val irc = IrcClient(authApi, { store.login }, viewModelScope) { queue.add(it) }

    private var sysCounter = 0L
    private var loginJob: Job? = null
    private var flushJob: Job? = null
    private var streamJob: Job? = null
    private var pollJob: Job? = null
    private var predJob: Job? = null

    // ---------- настройки ----------
    private val _prefs = MutableStateFlow(
        Prefs(
            store.accent, store.timeoutSec, store.modIcons, store.confirmBan,
            store.textSize, store.showTime, store.keepScreen,
        )
    )
    val prefs: StateFlow<Prefs> = _prefs.asStateFlow()

    fun updatePrefs(f: (Prefs) -> Prefs) {
        val p = f(_prefs.value)
        _prefs.value = p
        store.accent = p.accent
        store.timeoutSec = p.timeoutSec
        store.modIcons = p.modIcons
        store.confirmBan = p.confirmBan
        store.textSize = p.textSize
        store.showTime = p.showTime
        store.keepScreen = p.keepScreen
    }

    private val _showSettings = MutableStateFlow(false)
    val showSettings: StateFlow<Boolean> = _showSettings.asStateFlow()
    fun openSettings(v: Boolean) {
        _showSettings.value = v
    }

    // ---------- вход ----------
    private val _auth = MutableStateFlow<AuthState>(
        if (store.accessToken.isNotBlank() && store.userId.isNotBlank()) AuthState.SignedIn else AuthState.SignedOut()
    )
    val authState: StateFlow<AuthState> = _auth.asStateFlow()

    val myId: String get() = store.userId
    val myLogin: String get() = store.login
    val me: ChannelRef get() = ChannelRef(store.userId, store.login, store.display.ifBlank { store.login })

    private val _toasts = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val toasts: SharedFlow<String> = _toasts.asSharedFlow()
    private fun toast(s: String) {
        _toasts.tryEmit(s)
    }

    init {
        if (_auth.value == AuthState.SignedIn) loadChannels()
    }

    fun startLogin() {
        loginJob?.cancel()
        loginJob = viewModelScope.launch {
            _auth.value = AuthState.Busy
            try {
                val d = authApi.startDevice()
                _auth.value = AuthState.Waiting(d)
                var interval = d.interval.coerceAtLeast(3) * 1000L
                val deadline = System.currentTimeMillis() + d.expiresIn * 1000L
                while (isActive && System.currentTimeMillis() < deadline) {
                    delay(interval)
                    val r = try {
                        authApi.pollDevice(d)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: java.io.IOException) {
                        PollResult.Pending
                    }
                    when (r) {
                        is PollResult.Success -> {
                            finishLogin()
                            return@launch
                        }
                        is PollResult.SlowDown -> interval += 5000
                        is PollResult.Failed -> {
                            _auth.value = AuthState.SignedOut(r.message)
                            return@launch
                        }
                        else -> {}
                    }
                }
                _auth.value = AuthState.SignedOut("Время ввода кода истекло. Попробуй ещё раз.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _auth.value = AuthState.SignedOut(userMessage(e))
            }
        }
    }

    fun cancelLogin() {
        loginJob?.cancel()
        _auth.value = AuthState.SignedOut()
    }

    private suspend fun finishLogin() {
        try {
            val u = api.me()
            store.userId = u.id
            store.login = u.login
            store.display = u.name
            _auth.value = AuthState.SignedIn
            loadChannels()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            store.clearAuth()
            _auth.value = AuthState.SignedOut(userMessage(e))
        }
    }

    fun logout(reason: String? = null) {
        closeChannel()
        loginJob?.cancel()
        val token = store.accessToken
        store.clearAuth()
        viewModelScope.launch {
            try {
                authApi.revoke(token)
            } catch (e: Exception) {
            }
        }
        _channels.value = ChannelsState()
        _showSettings.value = false
        _auth.value = AuthState.SignedOut(reason)
    }

    private fun userMessage(e: Throwable): String = when (e) {
        is ApiException -> e.message ?: "Ошибка Twitch"
        is java.io.IOException -> "Нет связи с Twitch. Проверь интернет."
        else -> e.message ?: "Неизвестная ошибка"
    }

    private fun handleError(e: Throwable) {
        if (e is ApiException && e.sessionExpired) logout("Сессия истекла. Войди снова.")
    }

    private fun launchSafe(prefix: String = "", block: suspend () -> Unit): Job = viewModelScope.launch {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleError(e)
            toast((if (prefix.isNotBlank()) "$prefix: " else "") + userMessage(e))
        }
    }

    // ---------- каналы ----------
    private val _channels = MutableStateFlow(ChannelsState())
    val channels: StateFlow<ChannelsState> = _channels.asStateFlow()

    fun loadChannels() {
        viewModelScope.launch {
            _channels.value = _channels.value.copy(loading = true, error = null)
            try {
                val mods = api.moderatedChannels(store.userId)
                val list = listOf(me) + mods.filter { it.id != store.userId }.sortedBy { it.login }
                _channels.value = ChannelsState(list, false, null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleError(e)
                _channels.value = ChannelsState(listOf(me), false, userMessage(e))
            }
        }
    }

    fun openByLogin(login: String) {
        launchSafe("Канал") {
            val u = api.userByLogin(login)
            if (u == null) toast("Канал «${login.trim()}» не найден") else openChannel(u)
        }
    }

    // ---------- текущий канал ----------
    private val _current = MutableStateFlow<ChannelRef?>(null)
    val current: StateFlow<ChannelRef?> = _current.asStateFlow()

    private val _chat = MutableStateFlow(ChatState())
    val chat: StateFlow<ChatState> = _chat.asStateFlow()

    fun isOwnChannel(): Boolean = _current.value?.id == store.userId

    fun openChannel(ref: ChannelRef) {
        closeChannel()
        _current.value = ref
        _chat.value = ChatState(status = "Подключение к чату…")
        queue.clear()
        flushJob = viewModelScope.launch {
            while (isActive) {
                delay(120)
                drain()
            }
        }
        irc.connect(ref.login)
        loadChatSettings()
        streamJob = viewModelScope.launch {
            while (isActive) {
                try {
                    val s = api.stream(ref.id)
                    _chat.update { it.copy(stream = s) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    handleError(e)
                }
                delay(30_000)
            }
        }
        if (ref.id == store.userId) loadChannelInfo()
    }

    fun closeChannel() {
        irc.disconnect()
        flushJob?.cancel()
        streamJob?.cancel()
        pollJob?.cancel()
        predJob?.cancel()
        queue.clear()
        _current.value = null
        _chat.value = ChatState()
        _poll.value = null
        _prediction.value = null
        _panelNote.value = null
        _channelInfo.value = null
    }

    private fun sys(text: String) = ChatMsg(
        id = "sys-${sysCounter++}", userId = "", login = "", display = "", color = null,
        text = text, kind = MsgKind.SYSTEM,
    )

    private fun applyRoom(s: ChatSettings, t: Map<String, String>): ChatSettings {
        var r = s
        t["slow"]?.toIntOrNull()?.let { r = if (it > 0) r.copy(slow = true, slowSec = it) else r.copy(slow = false) }
        t["followers-only"]?.toIntOrNull()?.let {
            r = if (it >= 0) r.copy(followers = true, followersMin = it) else r.copy(followers = false)
        }
        t["subs-only"]?.let { r = r.copy(subs = it == "1") }
        t["emote-only"]?.let { r = r.copy(emote = it == "1") }
        t["r9k"]?.let { r = r.copy(unique = it == "1") }
        return r
    }

    private fun drain() {
        if (queue.isEmpty()) return
        val events = ArrayList<IrcEvent>()
        while (true) events.add(queue.poll() ?: break)
        _chat.update { s ->
            val msgs = ArrayList(s.messages)
            var settings = s.settings
            var status = s.status
            var connected = s.connected
            var self = s.self
            for (e in events) {
                when (e) {
                    is IrcEvent.Message -> if (msgs.none { it.id == e.msg.id }) msgs.add(e.msg)
                    is IrcEvent.Deleted -> {
                        val i = msgs.indexOfFirst { it.id == e.msgId }
                        if (i >= 0) msgs[i] = msgs[i].copy(deleted = true)
                    }
                    is IrcEvent.Cleared -> {
                        if (e.userId == null) {
                            msgs.add(sys("Чат очищен"))
                        } else {
                            val label = if (e.durationSec != null) "таймаут ${fmtDur(e.durationSec)}" else "бан"
                            for (i in msgs.indices) {
                                val m = msgs[i]
                                if (m.userId == e.userId && m.kind != MsgKind.SYSTEM) msgs[i] = m.copy(punished = label)
                            }
                            msgs.add(sys("@${e.login}: $label"))
                        }
                    }
                    is IrcEvent.Notice -> msgs.add(sys(e.text))
                    is IrcEvent.Status -> {
                        status = e.text
                        connected = e.connected
                    }
                    is IrcEvent.Room -> settings = applyRoom(settings, e.tags)
                    is IrcEvent.Self -> self = e.state
                }
            }
            val trimmed = if (msgs.size > MAX_MSGS) msgs.subList(msgs.size - MAX_MSGS, msgs.size).toList() else msgs
            s.copy(messages = trimmed, settings = settings, status = status, connected = connected, self = self)
        }
    }

    // ---------- отправка и команды ----------
    fun sendChat(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        if (text.startsWith("/") && !text.startsWith("/me ")) {
            runCommand(text)
            return
        }
        if (!irc.send(text)) {
            toast("Нет подключения к чату")
            return
        }
        val st = _chat.value.self
        val isAction = text.startsWith("/me ")
        queue.add(
            IrcEvent.Message(
                ChatMsg(
                    id = "local-${System.nanoTime()}", userId = store.userId, login = store.login,
                    display = store.display.ifBlank { store.login },
                    color = st.color ?: parseColor(null, store.login),
                    text = if (isAction) text.removePrefix("/me ") else text,
                    isBroadcaster = isOwnChannel() || st.isBroadcaster, isMod = st.isMod,
                    isVip = st.isVip, isSub = st.isSub,
                    kind = if (isAction) MsgKind.ACTION else MsgKind.CHAT, local = true,
                )
            )
        )
    }

    private fun withUser(login: String, block: (ChannelRef) -> Unit) {
        if (login.isBlank()) {
            toast("Укажи ник")
            return
        }
        launchSafe("Поиск ника") {
            val u = api.userByLogin(login)
            if (u == null) toast("Пользователь «$login» не найден") else block(u)
        }
    }

    private fun runCommand(text: String) {
        val parts = text.split(Regex("\\s+"), limit = 3)
        val cmd = parts[0].lowercase()
        val a1 = parts.getOrNull(1).orEmpty()
        val rest = parts.getOrNull(2).orEmpty()
        when (cmd) {
            "/clear" -> clearChat()
            "/ban" -> withUser(a1) { banUser(it.id, it.login, rest) }
            "/unban", "/untimeout" -> withUser(a1) { unbanUser(it.id, it.login) }
            "/warn" -> withUser(a1) { warnUser(it.id, it.login, rest) }
            "/timeout" -> {
                val tk = rest.split(" ", limit = 2)
                val dur = parseDuration(tk[0])
                val sec = (dur ?: 600).coerceIn(1, 1_209_600)
                val reason = if (dur != null) tk.getOrElse(1) { "" } else rest
                withUser(a1) { timeoutUser(it.id, it.login, sec, reason) }
            }
            "/slow" -> setSlow(true, (parseDuration(a1) ?: 30).coerceIn(3, 120))
            "/slowoff" -> setSlow(false, 30)
            "/subscribers", "/subs" -> setSubs(true)
            "/subscribersoff", "/subsoff" -> setSubs(false)
            "/emoteonly" -> setEmote(true)
            "/emoteonlyoff" -> setEmote(false)
            "/followers" -> setFollowers(true, ((parseDuration(a1) ?: 0) / 60).coerceAtLeast(0))
            "/followersoff" -> setFollowers(false, 0)
            "/uniquechat" -> setUnique(true)
            "/uniquechatoff" -> setUnique(false)
            "/announce" -> announce(listOf(a1, rest).filter { it.isNotBlank() }.joinToString(" "), "primary")
            "/title" -> {
                val t = listOf(a1, rest).filter { it.isNotBlank() }.joinToString(" ")
                if (t.isBlank()) toast("Напиши название: /title Новое название") else saveChannel(t, null, null)
            }
            else -> toast("Неизвестная команда $cmd")
        }
    }

    // ---------- модерация ----------
    private val _log = MutableStateFlow(store.loadLog())
    val log: StateFlow<List<LogEntry>> = _log.asStateFlow()

    private fun addLog(e: LogEntry) {
        _log.update { (listOf(e) + it).take(300) }
        store.saveLog(_log.value)
    }

    fun clearLog() {
        _log.value = emptyList()
        store.saveLog(emptyList())
    }

    private fun moderate(
        action: String,
        targetLogin: String,
        targetId: String,
        detail: String,
        block: suspend (broadcaster: String, moderator: String) -> Unit,
    ) {
        val ch = _current.value ?: return
        viewModelScope.launch {
            try {
                block(ch.id, store.userId)
                addLog(LogEntry(System.currentTimeMillis(), ch.login, action, targetLogin, targetId, detail, true, null))
                toast("✓ $action ${if (targetLogin.isNotBlank()) "@$targetLogin" else ""} $detail".trim())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = userMessage(e)
                addLog(LogEntry(System.currentTimeMillis(), ch.login, action, targetLogin, targetId, detail, false, msg))
                handleError(e)
                toast("✗ $action: $msg")
            }
        }
    }

    fun timeoutUser(userId: String, login: String, sec: Int, reason: String) {
        moderate("Мут", login, userId, fmtDur(sec) + if (reason.isNotBlank()) " · $reason" else "") { b, m ->
            api.ban(b, m, userId, sec.coerceIn(1, 1_209_600), reason)
        }
    }

    fun banUser(userId: String, login: String, reason: String) {
        moderate("Бан", login, userId, reason) { b, m -> api.ban(b, m, userId, null, reason) }
    }

    fun unbanUser(userId: String, login: String) {
        moderate("Снят бан/мут", login, userId, "") { b, m -> api.unban(b, m, userId) }
    }

    fun warnUser(userId: String, login: String, reason: String) {
        moderate("Предупреждение", login, userId, reason) { b, m -> api.warn(b, m, userId, reason) }
    }

    fun deleteMessage(msg: ChatMsg) {
        if (msg.local || msg.id.startsWith("irc-")) {
            toast("Это сообщение нельзя удалить")
            return
        }
        moderate("Удалено", msg.login, msg.userId, msg.text.take(40)) { b, m -> api.deleteMessage(b, m, msg.id) }
    }

    fun clearChat() {
        moderate("Очистка чата", "", "", "") { b, m -> api.clearChat(b, m) }
    }

    fun announce(text: String, color: String) {
        if (text.isBlank()) return
        moderate("Объявление", "", "", text.take(40)) { b, m -> api.announce(b, m, text.take(500), color) }
    }

    // ---------- режимы чата ----------
    private fun loadChatSettings() {
        val ch = _current.value ?: return
        viewModelScope.launch {
            try {
                val s = api.chatSettings(ch.id, store.userId)
                _chat.update { it.copy(settings = s) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleError(e)
            }
        }
    }

    private fun patchSettings(label: String, body: JSONObject, apply: (ChatSettings) -> ChatSettings) {
        moderate(label, "", "", "") { b, m ->
            api.patchChatSettings(b, m, body)
            _chat.update { it.copy(settings = apply(it.settings)) }
        }
    }

    fun setSlow(on: Boolean, sec: Int) {
        val s = sec.coerceIn(3, 120)
        val body = JSONObject().put("slow_mode", on)
        if (on) body.put("slow_mode_wait_time", s)
        patchSettings(if (on) "Медленный режим $s с" else "Медленный режим выкл", body) {
            if (on) it.copy(slow = true, slowSec = s) else it.copy(slow = false)
        }
    }

    fun setFollowers(on: Boolean, minutes: Int) {
        val mm = minutes.coerceIn(0, 129_600)
        val body = JSONObject().put("follower_mode", on)
        if (on) body.put("follower_mode_duration", mm)
        patchSettings(if (on) "Только фолловеры" else "Режим фолловеров выкл", body) {
            if (on) it.copy(followers = true, followersMin = mm) else it.copy(followers = false)
        }
    }

    fun setSubs(on: Boolean) {
        patchSettings(if (on) "Только сабы" else "Режим сабов выкл", JSONObject().put("subscriber_mode", on)) {
            it.copy(subs = on)
        }
    }

    fun setEmote(on: Boolean) {
        patchSettings(if (on) "Только эмоуты" else "Режим эмоутов выкл", JSONObject().put("emote_mode", on)) {
            it.copy(emote = on)
        }
    }

    fun setUnique(on: Boolean) {
        patchSettings(if (on) "Уникальный чат" else "Уникальный чат выкл", JSONObject().put("unique_chat_mode", on)) {
            it.copy(unique = on)
        }
    }

    // ---------- название / категория ----------
    private val _channelInfo = MutableStateFlow<ChannelInfo?>(null)
    val channelInfo: StateFlow<ChannelInfo?> = _channelInfo.asStateFlow()
    private val _channelBusy = MutableStateFlow(false)
    val channelBusy: StateFlow<Boolean> = _channelBusy.asStateFlow()

    private val _presets = MutableStateFlow(store.loadPresets())
    val presets: StateFlow<List<Preset>> = _presets.asStateFlow()

    fun loadChannelInfo() {
        val ch = _current.value ?: return
        launchSafe("Канал") {
            _channelInfo.value = api.channelInfo(ch.id)
        }
    }

    fun saveChannel(title: String, gameId: String?, gameName: String?) {
        val ch = _current.value ?: return
        if (ch.id != store.userId) {
            toast("Менять название и категорию может только владелец канала")
            return
        }
        viewModelScope.launch {
            _channelBusy.value = true
            try {
                api.updateChannel(ch.id, title.take(140), gameId?.takeIf { it.isNotBlank() })
                val old = _channelInfo.value
                _channelInfo.value = ChannelInfo(
                    title.take(140),
                    gameId?.takeIf { it.isNotBlank() } ?: old?.gameId.orEmpty(),
                    gameName?.takeIf { it.isNotBlank() } ?: old?.gameName.orEmpty(),
                )
                addLog(LogEntry(System.currentTimeMillis(), ch.login, "Название/категория", "", "", title.take(40), true, null))
                toast("✓ Название и категория обновлены")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleError(e)
                toast("✗ " + userMessage(e))
            } finally {
                _channelBusy.value = false
            }
        }
    }

    suspend fun searchCategories(q: String): List<Category> = try {
        api.searchCategories(q)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleError(e)
        emptyList()
    }

    fun addPreset(title: String, gameId: String, gameName: String) {
        if (title.isBlank()) return
        val p = Preset(title, gameId, gameName)
        _presets.update { (listOf(p) + it.filter { x -> x != p }).take(12) }
        store.savePresets(_presets.value)
        toast("Пресет сохранён")
    }

    fun removePreset(p: Preset) {
        _presets.update { it.filter { x -> x != p } }
        store.savePresets(_presets.value)
    }

    // ---------- опросы ----------
    private val _poll = MutableStateFlow<PollInfo?>(null)
    val poll: StateFlow<PollInfo?> = _poll.asStateFlow()
    private val _prediction = MutableStateFlow<PredictionInfo?>(null)
    val prediction: StateFlow<PredictionInfo?> = _prediction.asStateFlow()
    private val _panelNote = MutableStateFlow<String?>(null)
    val panelNote: StateFlow<String?> = _panelNote.asStateFlow()

    private val _pollTpl = MutableStateFlow(store.loadTemplates(true))
    val pollTemplates: StateFlow<List<Template>> = _pollTpl.asStateFlow()
    private val _predTpl = MutableStateFlow(store.loadTemplates(false))
    val predTemplates: StateFlow<List<Template>> = _predTpl.asStateFlow()

    fun refreshPoll() {
        val ch = _current.value ?: return
        if (pollJob?.isActive == true) return
        pollJob = viewModelScope.launch {
            try {
                _poll.value = api.latestPoll(ch.id)
                _panelNote.value = null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleError(e)
                _panelNote.value = userMessage(e)
            }
        }
    }

    fun refreshPrediction() {
        val ch = _current.value ?: return
        if (predJob?.isActive == true) return
        predJob = viewModelScope.launch {
            try {
                _prediction.value = api.latestPrediction(ch.id)
                _panelNote.value = null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleError(e)
                _panelNote.value = userMessage(e)
            }
        }
    }

    fun createPoll(title: String, choices: List<String>, seconds: Int, onDone: () -> Unit) {
        val ch = _current.value ?: return
        launchSafe("Опрос") {
            api.createPoll(ch.id, title, choices, seconds)
            val t = Template(title, choices, seconds)
            _pollTpl.update { (listOf(t) + it.filter { x -> x.title != title }).take(6) }
            store.saveTemplates(true, _pollTpl.value)
            addLog(LogEntry(System.currentTimeMillis(), ch.login, "Опрос запущен", "", "", title.take(40), true, null))
            toast("✓ Опрос запущен")
            onDone()
            _poll.value = api.latestPoll(ch.id)
        }
    }

    fun endPoll(archive: Boolean) {
        val ch = _current.value ?: return
        val p = _poll.value ?: return
        launchSafe("Опрос") {
            api.endPoll(ch.id, p.id, archive)
            toast(if (archive) "✓ Опрос удалён" else "✓ Опрос завершён")
            _poll.value = api.latestPoll(ch.id)
        }
    }

    fun createPrediction(title: String, outcomes: List<String>, seconds: Int, onDone: () -> Unit) {
        val ch = _current.value ?: return
        launchSafe("Ставки") {
            api.createPrediction(ch.id, title, outcomes, seconds)
            val t = Template(title, outcomes, seconds)
            _predTpl.update { (listOf(t) + it.filter { x -> x.title != title }).take(6) }
            store.saveTemplates(false, _predTpl.value)
            addLog(LogEntry(System.currentTimeMillis(), ch.login, "Ставки запущены", "", "", title.take(40), true, null))
            toast("✓ Ставки запущены")
            onDone()
            _prediction.value = api.latestPrediction(ch.id)
        }
    }

    fun patchPrediction(status: String, winnerId: String?) {
        val ch = _current.value ?: return
        val p = _prediction.value ?: return
        launchSafe("Ставки") {
            api.patchPrediction(ch.id, p.id, status, winnerId)
            toast(
                when (status) {
                    "LOCKED" -> "✓ Приём ставок закрыт"
                    "RESOLVED" -> "✓ Победитель выбран"
                    else -> "✓ Ставки отменены, баллы возвращены"
                }
            )
            _prediction.value = api.latestPrediction(ch.id)
        }
    }

    companion object {
        const val MAX_MSGS = 600
    }
}
