package com.twnmmod

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

fun fmtDur(sec: Int): String = when {
    sec >= 86400 && sec % 86400 == 0 -> "${sec / 86400} д"
    sec >= 3600 && sec % 3600 == 0 -> "${sec / 3600} ч"
    sec >= 60 && sec % 60 == 0 -> "${sec / 60} м"
    else -> "$sec с"
}

fun fmtClock(totalSec: Long): String {
    val s = totalSec.coerceAtLeast(0L)
    val h = s / 3600
    val m = (s % 3600) / 60
    val x = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, x)
    else String.format(Locale.US, "%d:%02d", m, x)
}

fun fmtCount(n: Long): String = when {
    n >= 1_000_000 -> String.format(Locale.US, "%.1fM", n / 1_000_000.0)
    n >= 10_000 -> String.format(Locale.US, "%.1fK", n / 1000.0)
    else -> n.toString()
}

/** "10m", "2h", "30", "45с" -> секунды */
fun parseDuration(token: String): Int? {
    val t = token.trim().lowercase()
    if (t.isEmpty()) return null
    val mult = when (t.last()) {
        's', 'с' -> 1
        'm', 'м' -> 60
        'h', 'ч' -> 3600
        'd', 'д' -> 86400
        else -> 0
    }
    val num = if (mult == 0) t.toIntOrNull() else t.dropLast(1).toIntOrNull()
    return num?.let { it * (if (mult == 0) 1 else mult) }
}

fun fmtAge(ms: Long): String {
    val days = (ms / 86_400_000L).coerceAtLeast(0L)
    return when {
        days < 30 -> "$days дн."
        days < 365 -> "${days / 30} мес."
        else -> "${days / 365} г. ${(days % 365) / 30} мес."
    }
}

fun parseIso(s: String): Long = try {
    java.time.Instant.parse(s).toEpochMilli()
} catch (e: Exception) {
    0L
}

class Store(context: Context) {
    private val sp = context.getSharedPreferences("twnmmod", Context.MODE_PRIVATE)

    private fun sP(key: String, def: String = ""): ReadWriteProperty<Any?, String> =
        object : ReadWriteProperty<Any?, String> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): String = try {
                sp.getString(key, def) ?: def
            } catch (e: ClassCastException) {
                def
            }
            override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
                sp.edit().putString(key, value).apply()
            }
        }

    private fun lP(key: String, def: Long): ReadWriteProperty<Any?, Long> =
        object : ReadWriteProperty<Any?, Long> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): Long = try {
                sp.getLong(key, def)
            } catch (e: ClassCastException) {
                def
            }
            override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) {
                sp.edit().putLong(key, value).apply()
            }
        }

    private fun iP(key: String, def: Int): ReadWriteProperty<Any?, Int> =
        object : ReadWriteProperty<Any?, Int> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): Int = try {
                sp.getInt(key, def)
            } catch (e: ClassCastException) {
                def
            }
            override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
                sp.edit().putInt(key, value).apply()
            }
        }

    private fun fP(key: String, def: Float): ReadWriteProperty<Any?, Float> =
        object : ReadWriteProperty<Any?, Float> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): Float = try {
                sp.getFloat(key, def)
            } catch (e: ClassCastException) {
                def
            }
            override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) {
                sp.edit().putFloat(key, value).apply()
            }
        }

    private fun bP(key: String, def: Boolean): ReadWriteProperty<Any?, Boolean> =
        object : ReadWriteProperty<Any?, Boolean> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = try {
                sp.getBoolean(key, def)
            } catch (e: ClassCastException) {
                def
            }
            override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
                sp.edit().putBoolean(key, value).apply()
            }
        }

    var accessToken: String by sP("access")
    var refreshToken: String by sP("refresh")
    var expiresAt: Long by lP("expires", 0L)
    var userId: String by sP("uid")
    var login: String by sP("login")
    var display: String by sP("display")

    var accent: Long by lP("accent", 0xFF9146FF)
    var timeoutSec: Int by iP("timeoutSec", 600)
    var modIcons: String by sP("modIcons", "always")
    var confirmBan: Boolean by bP("confirmBan", true)
    var textSize: Float by fP("textSize", 15f)
    var showTime: Boolean by bP("showTime", false)
    var keepScreen: Boolean by bP("keepScreen", true)
    var thirdEmotes: Boolean by bP("thirdEmotes", true)
    var animEmotes: Boolean by bP("animEmotes", true)
    var bg: String by sP("bg", "twitch")
    var rounding: String by sP("rounding", "normal")
    var density: String by sP("density", "normal")
    var iconSize: String by sP("iconSize", "normal")
    var iconSide: String by sP("iconSide", "right")
    var quickItems: String by sP("quickItems", "slow,followers,subs,emote,clear,clip")
    var startTab: Int by iP("startTab", 0)
    var showBadges: Boolean by bP("showBadges", true)
    var highlightWords: String by sP("highlightWords", "")
    var bufferSize: Int by iP("bufferSize", 600)

    private var logJson: String by sP("log", "[]")
    private var presetsJson: String by sP("presets", "[]")
    private var tplPollJson: String by sP("tplPoll", "[]")
    private var tplPredJson: String by sP("tplPred", "[]")

    fun readPrefs() = Prefs(
        accent, timeoutSec, modIcons, confirmBan, textSize, showTime, keepScreen, thirdEmotes, animEmotes,
        bg, rounding, density, iconSize, iconSide, quickItems, startTab, showBadges, highlightWords, bufferSize,
    )

    fun writePrefs(p: Prefs) {
        accent = p.accent
        timeoutSec = p.timeoutSec
        modIcons = p.modIcons
        confirmBan = p.confirmBan
        textSize = p.textSize
        showTime = p.showTime
        keepScreen = p.keepScreen
        thirdEmotes = p.thirdEmotes
        animEmotes = p.animEmotes
        bg = p.bg
        rounding = p.rounding
        density = p.density
        iconSize = p.iconSize
        iconSide = p.iconSide
        quickItems = p.quickItems
        startTab = p.startTab
        showBadges = p.showBadges
        highlightWords = p.highlightWords
        bufferSize = p.bufferSize
    }

    fun exportBackup(): String {
        val p = readPrefs()
        return JSONObject()
            .put("app", "TwNmMod").put("v", 2)
            .put("accent", p.accent).put("timeoutSec", p.timeoutSec).put("modIcons", p.modIcons)
            .put("confirmBan", p.confirmBan).put("textSize", p.textSize.toDouble())
            .put("showTime", p.showTime).put("keepScreen", p.keepScreen)
            .put("thirdEmotes", p.thirdEmotes).put("animEmotes", p.animEmotes)
            .put("bg", p.bg).put("rounding", p.rounding).put("density", p.density)
            .put("iconSize", p.iconSize).put("iconSide", p.iconSide).put("quickItems", p.quickItems)
            .put("startTab", p.startTab).put("showBadges", p.showBadges)
            .put("highlightWords", p.highlightWords).put("bufferSize", p.bufferSize)
            .put("presets", JSONArray(presetsJson))
            .put("tplPoll", JSONArray(tplPollJson)).put("tplPred", JSONArray(tplPredJson))
            .toString()
    }

    fun importBackup(text: String): Boolean {
        return try {
            val o = JSONObject(text.trim())
            if (o.optString("app") != "TwNmMod") return false
            val b = readPrefs()
            writePrefs(
                Prefs(
                    accent = o.optLong("accent", b.accent),
                    timeoutSec = o.optInt("timeoutSec", b.timeoutSec),
                    modIcons = o.optString("modIcons", b.modIcons),
                    confirmBan = o.optBoolean("confirmBan", b.confirmBan),
                    textSize = o.optDouble("textSize", b.textSize.toDouble()).toFloat(),
                    showTime = o.optBoolean("showTime", b.showTime),
                    keepScreen = o.optBoolean("keepScreen", b.keepScreen),
                    thirdEmotes = o.optBoolean("thirdEmotes", b.thirdEmotes),
                    animEmotes = o.optBoolean("animEmotes", b.animEmotes),
                    bg = o.optString("bg", b.bg),
                    rounding = o.optString("rounding", b.rounding),
                    density = o.optString("density", b.density),
                    iconSize = o.optString("iconSize", b.iconSize),
                    iconSide = o.optString("iconSide", b.iconSide),
                    quickItems = o.optString("quickItems", b.quickItems),
                    startTab = o.optInt("startTab", b.startTab),
                    showBadges = o.optBoolean("showBadges", b.showBadges),
                    highlightWords = o.optString("highlightWords", b.highlightWords),
                    bufferSize = o.optInt("bufferSize", b.bufferSize),
                )
            )
            o.optJSONArray("presets")?.let { presetsJson = it.toString() }
            o.optJSONArray("tplPoll")?.let { tplPollJson = it.toString() }
            o.optJSONArray("tplPred")?.let { tplPredJson = it.toString() }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun clearAuth() {
        accessToken = ""
        refreshToken = ""
        expiresAt = 0L
        userId = ""
        login = ""
        display = ""
    }

    fun loadLog(): List<LogEntry> = try {
        val a = JSONArray(logJson)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            LogEntry(
                time = o.getLong("t"),
                channel = o.optString("c"),
                action = o.optString("a"),
                target = o.optString("n"),
                targetId = o.optString("i"),
                detail = o.optString("d"),
                ok = o.optBoolean("ok", true),
                error = if (o.has("e")) o.getString("e") else null,
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveLog(list: List<LogEntry>) {
        val a = JSONArray()
        list.forEach { e ->
            val o = JSONObject()
                .put("t", e.time).put("c", e.channel).put("a", e.action)
                .put("n", e.target).put("i", e.targetId).put("d", e.detail).put("ok", e.ok)
            if (e.error != null) o.put("e", e.error)
            a.put(o)
        }
        logJson = a.toString()
    }

    fun loadPresets(): List<Preset> = try {
        val a = JSONArray(presetsJson)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Preset(o.optString("t"), o.optString("g"), o.optString("n"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun savePresets(list: List<Preset>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("t", it.title).put("g", it.gameId).put("n", it.gameName)) }
        presetsJson = a.toString()
    }

    fun loadTemplates(poll: Boolean): List<Template> = try {
        val a = JSONArray(if (poll) tplPollJson else tplPredJson)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val opts = o.getJSONArray("o")
            Template(o.optString("t"), (0 until opts.length()).map { i -> opts.getString(i) }, o.optInt("s", 120))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveTemplates(poll: Boolean, list: List<Template>) {
        val a = JSONArray()
        list.forEach { t ->
            val opts = JSONArray()
            t.options.forEach { opts.put(it) }
            a.put(JSONObject().put("t", t.title).put("o", opts).put("s", t.seconds))
        }
        if (poll) tplPollJson = a.toString() else tplPredJson = a.toString()
    }
}
