package com.twnmmod

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class HeldMsg(
    val id: String,
    val userId: String,
    val login: String,
    val display: String,
    val text: String,
    val reason: String,
)

sealed class EsEvent {
    class Hold(val msg: HeldMsg) : EsEvent()
    class Resolved(val id: String) : EsEvent()
}

private fun categoryRu(c: String): String = when (c) {
    "aggressive" -> "агрессия"
    "bullying" -> "буллинг"
    "disability" -> "дискриминация по инвалидности"
    "misogyny" -> "мизогиния"
    "race_ethnicity_or_religion" -> "раса, этнос, религия"
    "sex_based_terms" -> "сексуальные термины"
    "sexuality_sex_or_gender" -> "сексуальность, пол"
    "swearing" -> "нецензурная лексика"
    "" -> "AutoMod"
    else -> c
}

/** Очередь AutoMod через EventSub WebSocket. Ошибки сети и подписки не ломают приложение. */
class EventSubClient(
    private val scope: CoroutineScope,
    private val onEvent: (EsEvent) -> Unit,
    private val onWelcome: suspend (sessionId: String) -> Unit,
) {
    private val client = Http.client.newBuilder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(30, TimeUnit.SECONDS)
        .build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var welcomed = false
    private var job: Job? = null

    fun connect() {
        disconnect()
        job = scope.launch(Dispatchers.IO) {
            var backoff = 2000L
            while (isActive) {
                val closed = CompletableDeferred<Unit>()
                welcomed = false
                try {
                    val req = Request.Builder().url("wss://eventsub.wss.twitch.tv/ws").build()
                    val ws = client.newWebSocket(req, object : WebSocketListener() {
                        override fun onMessage(webSocket: WebSocket, text: String) {
                            handle(webSocket, text)
                        }

                        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                            webSocket.close(1000, null)
                        }

                        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                            closed.complete(Unit)
                        }

                        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                            closed.complete(Unit)
                        }
                    })
                    socket = ws
                    try {
                        closed.await()
                    } finally {
                        ws.cancel()
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // сеть: переподключимся
                }
                if (!isActive) break
                if (welcomed) backoff = 2000L
                delay(backoff)
                backoff = (backoff * 2).coerceAtMost(30_000L)
            }
        }
    }

    fun disconnect() {
        job?.cancel()
        job = null
        socket?.close(1000, null)
        socket = null
    }

    private fun handle(ws: WebSocket, text: String) {
        try {
            val j = JSONObject(text)
            val meta = j.getJSONObject("metadata")
            when (meta.optString("message_type")) {
                "session_welcome" -> {
                    val id = j.getJSONObject("payload").getJSONObject("session").getString("id")
                    welcomed = true
                    scope.launch(Dispatchers.IO) {
                        try {
                            onWelcome(id)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                        }
                    }
                }
                "session_reconnect" -> ws.close(1000, null)
                "notification" -> {
                    val type = meta.optString("subscription_type")
                    val ev = j.getJSONObject("payload").getJSONObject("event")
                    when (type) {
                        "automod.message.hold" -> parseHold(ev)?.let { onEvent(EsEvent.Hold(it)) }
                        "automod.message.update" -> {
                            val id = ev.optString("message_id")
                            if (id.isNotBlank()) onEvent(EsEvent.Resolved(id))
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun parseHold(ev: JSONObject): HeldMsg? {
        val id = ev.optString("message_id")
        if (id.isBlank()) return null
        val msgAny = ev.opt("message")
        val text = if (msgAny is JSONObject) msgAny.optString("text") else ev.optString("message")
        val automod = ev.optJSONObject("automod")
        val level = automod?.optInt("level", 0) ?: ev.optInt("level", 0)
        val category = automod?.optString("category") ?: ev.optString("category")
        val reason = if (ev.optString("reason") == "blocked_term") {
            "запрещённое слово"
        } else {
            categoryRu(category) + if (level > 0) " (уровень $level)" else ""
        }
        val login = ev.optString("user_login")
        return HeldMsg(id, ev.optString("user_id"), login, ev.optString("user_name", login), text, reason)
    }
}
