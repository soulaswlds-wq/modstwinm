@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.twnmmod.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val logFmt = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault())

@Composable
fun LogTab(vm: AppViewModel, modifier: Modifier) {
    val log by vm.log.collectAsState()
    val ch by vm.current.collectAsState()
    val list = log.filter { ch == null || it.channel.equals(ch?.login, true) }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Журнал действий (${list.size})",
                Modifier.weight(1f),
                fontWeight = FontWeight.Bold,
            )
            if (log.isNotEmpty()) TextButton(onClick = { vm.clearLog() }) { Text("Очистить") }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Пока пусто. Здесь будут баны, муты, удаления и другие действия, сделанные из приложения.",
                    Modifier.padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(list) { e ->
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (e.ok) MaterialTheme.colorScheme.surfaceVariant
                            else MaterialTheme.colorScheme.errorContainer,
                        ),
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                            Icon(
                                if (e.ok) Icons.Filled.Check else Icons.Filled.Warning,
                                null,
                                Modifier.size(20.dp),
                                tint = if (e.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    e.action + if (e.target.isNotBlank()) " · @${e.target}" else "",
                                    fontWeight = FontWeight.Bold,
                                )
                                if (e.detail.isNotBlank()) Text(e.detail, style = MaterialTheme.typography.bodySmall)
                                if (e.error != null) {
                                    Text(
                                        e.error,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error,
                                    )
                                }
                                Text(
                                    "${logFmt.format(Date(e.time))} · #${e.channel}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (e.ok && e.targetId.isNotBlank() && (e.action == "Бан" || e.action == "Мут")) {
                                    TextButton(
                                        onClick = { vm.unbanUser(e.targetId, e.target) },
                                        contentPadding = PaddingValues(0.dp),
                                    ) { Text("Снять") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val p by vm.prefs.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки") },
                navigationIcon = {
                    IconButton(onClick = { vm.openSettings(false) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад")
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionCard("Цвет акцента") {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    AccentChoices.forEach { (name, value) ->
                        Box(
                            Modifier
                                .size(44.dp)
                                .background(Color(value), CircleShape)
                                .clickable { vm.updatePrefs { it.copy(accent = value) } },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (p.accent == value) Icon(Icons.Filled.Check, name, tint = Color.Black)
                        }
                    }
                }
            }

            SectionCard("Чат") {
                Text("Размер текста: ${p.textSize.toInt()} sp")
                Slider(
                    value = p.textSize,
                    onValueChange = { v -> vm.updatePrefs { it.copy(textSize = v.toInt().toFloat()) } },
                    valueRange = 12f..24f,
                )
                SwitchLine("Показывать время сообщений", p.showTime) { v -> vm.updatePrefs { it.copy(showTime = v) } }
                SwitchLine("Не гасить экран в чате", p.keepScreen) { v -> vm.updatePrefs { it.copy(keepScreen = v) } }
            }

            SectionCard("Значки модерации у сообщений") {
                ChipChoice(
                    listOf("Всегда видны" to "always", "По тапу" to "tap", "Выкл" to "off"),
                    p.modIcons,
                    { v -> vm.updatePrefs { it.copy(modIcons = v) } },
                )
                SwitchLine("Спрашивать перед баном", p.confirmBan) { v -> vm.updatePrefs { it.copy(confirmBan = v) } }
                Text("Длительность мута по значку")
                ChipChoice(
                    listOf(10, 60, 600, 3600, 86400).map { com.twnmmod.fmtDur(it) to it },
                    p.timeoutSec,
                    { v -> vm.updatePrefs { it.copy(timeoutSec = v) } },
                )
                Text(
                    "Значки: бан, мут, предупреждение, удалить сообщение. Долгое нажатие на сообщение открывает " +
                        "полную карточку: причины, своё время мута, снятие бана, история.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SectionCard("Команды в поле чата") {
                Text(
                    "/ban ник причина\n/timeout ник 10m причина\n/unban ник\n/warn ник причина\n" +
                        "/clear\n/slow 30  /slowoff\n/followers 10m  /followersoff\n/subs  /subsoff\n" +
                        "/emoteonly  /emoteonlyoff\n/announce текст\n/title новое название",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SectionCard("Аккаунт") {
                Text("Вы вошли как ${vm.me.name}")
                OutlinedButton(
                    onClick = { vm.logout() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Выйти из аккаунта") }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SwitchLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
