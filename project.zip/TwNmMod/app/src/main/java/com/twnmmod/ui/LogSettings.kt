@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.twnmmod.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val logFmt = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault())

@Composable
fun LogTab(vm: AppViewModel, modifier: Modifier) {
    val log by vm.log.collectAsState()
    val ch by vm.current.collectAsState()
    val list = log.filter { ch == null || it.channel.equals(ch?.login, true) }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Журнал действий (${list.size})",
                Modifier.weight(1f),
                fontWeight = FontWeight.Bold,
            )
            if (log.isNotEmpty()) TextButton(onClick = { vm.clearLog() }) { Text("Очистить") }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Пока пусто. Здесь будут баны, муты, удаления и другие действия, сделанные из приложения.",
                    Modifier.padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(list) { e ->
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (e.ok) MaterialTheme.colorScheme.surfaceVariant
                            else MaterialTheme.colorScheme.errorContainer,
                        ),
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                            Icon(
                                if (e.ok) Icons.Filled.Check else Icons.Filled.Warning,
                                null,
                                Modifier.size(20.dp),
                                tint = if (e.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    e.action + if (e.target.isNotBlank()) " · @${e.target}" else "",
                                    fontWeight = FontWeight.Bold,
                                )
                                if (e.detail.isNotBlank()) Text(e.detail, style = MaterialTheme.typography.bodySmall)
                                if (e.error != null) {
                                    Text(
                                        e.error,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error,
                                    )
                                }
                                Text(
                                    "${logFmt.format(Date(e.time))} · #${e.channel}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (e.ok && e.targetId.isNotBlank() && (e.action == "Бан" || e.action == "Мут")) {
                                    TextButton(
                                        onClick = { vm.unbanUser(e.targetId, e.target) },
                                        contentPadding = PaddingValues(0.dp),
                                    ) { Text("Снять") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private val QuickChoices = listOf(
    "slow" to "Медленный",
    "followers" to "Фолловеры",
    "subs" to "Сабы",
    "emote" to "Эмоуты",
    "unique" to "Уникальный",
    "shield" to "Щит",
    "clear" to "Очистить",
    "clip" to "Клип",
)

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val p by vm.prefs.collectAsState()
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    var query by remember { mutableStateOf("") }
    val q = query.trim()
    fun show(text: String) = q.isEmpty() || text.contains(q, ignoreCase = true)

    val sThemes = show("Темы тема стекло материал сакура аврора закат люкс классика фон оформление стиль")
    val sEvents = show("Карточки событий подписки рейды фолловеры биты баны объявления очистка стиль")
    val sAnim = show("Анимации вибрация темп чата скорость батарея производительность отклик")
    val sStyles = show("Стили ников сообщений VIP модераторы сабы новички команда градиент цвет шрифт правила оформление пресеты")
    val sIcons = show("Набор значков модерации иконки бан мут эмодзи буквы контур наборы")
    val sAppIcon = show("Значок иконка приложения цвет лаунчер")
    val sTheme = show("Оформление тема цвет акцент фон amoled чёрный тёмный полночь вино синий скругления углы форма")
    val sChat = show("Чат вид текст размер шрифт плотность компактно время бейджи значки экран не гасить первая вкладка стартовая")
    val sEmote = show("Эмоуты смайлы 7TV BTTV FFZ анимация анимированные сторонние")
    val sMod = show("Значки модерации бан мут таймаут предупреждение удалить справа слева размер подтверждение")
    val sQuick = show("Быстрые кнопки чат панель режимы клип очистить медленный фолловеры сабы порядок")
    val sWords = show("Подсветка слов ключевые слова триггеры фильтр выделять история чата размер буфер сообщений")
    val sPhr = show("Быстрые фразы шаблоны ответы кнопки сообщения правила чата")
    val sPlayer = show("Плеер видео стрим окно трансляция звук без звука")
    val sCat = show("Категория команда бот подсказки !g смена категории автоотправка")
    val sCmd = show("Команды чат слэш ban timeout unban warn clear slow followers announce title")
    val sBackup = show("Резервная копия backup экспорт импорт восстановить скопировать перенос")
    val sAcc = show("Аккаунт выйти вход версия")
    val none = !(sThemes || sEvents || sAnim || sStyles || sIcons || sAppIcon || sTheme || sChat || sEmote || sMod || sQuick || sWords || sPhr || sPlayer || sCat || sCmd || sBackup || sAcc)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки") },
                navigationIcon = {
                    IconButton(onClick = { vm.openSettings(false) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад")
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Поиск по настройкам") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Очистить") }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            if (none) {
                Text(
                    "Ничего не найдено. Попробуй другое слово: цвет, эмоуты, бан, клип…",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            if (sThemes) ThemesCard(p, vm)

            if (sTheme) {
                SectionCard("Оформление") {
                    Text("Цвет акцента")
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        AccentChoices.forEach { (name, value) ->
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .background(Color(value), CircleShape)
                                    .clickable { vm.updatePrefs { it.copy(accent = value) } },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (p.accent == value) Icon(Icons.Filled.Check, name, tint = Color.Black)
                            }
                        }
                    }
                    Text("Фон")
                    ChipChoice(
                        listOf("Twitch" to "twitch", "AMOLED" to "amoled", "Полночь" to "navy", "Вино" to "wine"),
                        p.bg,
                        { v -> vm.updatePrefs { it.copy(bg = v) } },
                    )
                    Text("Скругления")
                    ChipChoice(
                        listOf("Острые" to "sharp", "Обычные" to "normal", "Круглые" to "round"),
                        p.rounding,
                        { v -> vm.updatePrefs { it.copy(rounding = v) } },
                    )
                }
            }

            if (sChat) {
                SectionCard("Вид чата") {
                    Text("Размер текста: ${p.textSize.toInt()} sp")
                    Slider(
                        value = p.textSize,
                        onValueChange = { v -> vm.updatePrefs { it.copy(textSize = v.toInt().toFloat()) } },
                        valueRange = 12f..24f,
                    )
                    Text("Плотность сообщений")
                    ChipChoice(
                        listOf("Компактно" to "compact", "Обычно" to "normal", "Просторно" to "roomy"),
                        p.density,
                        { v -> vm.updatePrefs { it.copy(density = v) } },
                    )
                    SwitchLine("Показывать бейджи (модер, VIP, саб)", p.showBadges) { v -> vm.updatePrefs { it.copy(showBadges = v) } }
                    SwitchLine("Показывать время сообщений", p.showTime) { v -> vm.updatePrefs { it.copy(showTime = v) } }
                    SwitchLine("Не гасить экран в чате", p.keepScreen) { v -> vm.updatePrefs { it.copy(keepScreen = v) } }
                    Text("Какая вкладка открывается первой")
                    ChipChoice(
                        listOf("Чат" to 0, "Стрим" to 1, "Опросы" to 2, "Модер" to 3, "Журнал" to 4),
                        p.startTab,
                        { v -> vm.updatePrefs { it.copy(startTab = v) } },
                    )
                }
            }

            if (sEmote) {
                SectionCard("Эмоуты") {
                    SwitchLine("Сторонние эмоуты (7TV, BTTV, FFZ)", p.thirdEmotes) { v -> vm.updatePrefs { it.copy(thirdEmotes = v) } }
                    Text("Размер эмоутов в чате")
                    ChipChoice(
                        listOf("1×" to 1f, "1.5×" to 1.5f, "2×" to 2f, "2.5×" to 2.5f, "3×" to 3f),
                        p.emoteScale,
                        { v -> vm.updatePrefs { it.copy(emoteScale = v) } },
                    )
                    SwitchLine("Анимированные эмоуты", p.animEmotes) { v -> vm.updatePrefs { it.copy(animEmotes = v) } }
                    Text(
                        "Настройка применяется к новым сообщениям. Если чат тормозит, выключи анимацию.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (sMod) {
                SectionCard("Значки модерации") {
                    Text("Когда показывать")
                    ChipChoice(
                        listOf("Всегда видны" to "always", "По тапу" to "tap", "Выкл" to "off"),
                        p.modIcons,
                        { v -> vm.updatePrefs { it.copy(modIcons = v) } },
                    )
                    Text("Сторона")
                    ChipChoice(
                        listOf("Справа" to "right", "Слева" to "left"),
                        p.iconSide,
                        { v -> vm.updatePrefs { it.copy(iconSide = v) } },
                    )
                    Text("Размер значков")
                    ChipChoice(
                        listOf("Мелкие" to "small", "Обычные" to "normal", "Крупные" to "large"),
                        p.iconSize,
                        { v -> vm.updatePrefs { it.copy(iconSize = v) } },
                    )
                    SwitchLine("Спрашивать перед баном", p.confirmBan) { v -> vm.updatePrefs { it.copy(confirmBan = v) } }
                    Text("Длительность мута по значку")
                    ChipChoice(
                        listOf(10, 60, 600, 3600, 86400).map { com.twnmmod.fmtDur(it) to it },
                        p.timeoutSec,
                        { v -> vm.updatePrefs { it.copy(timeoutSec = v) } },
                    )
                    Text(
                        "Значки: бан, мут, предупреждение, удалить. Долгое нажатие на сообщение открывает полную карточку: " +
                            "причины, своё время мута, снятие бана, история.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (sIcons) IconPackCard(p, vm)

            if (sQuick) {
                SectionCard("Быстрые кнопки над чатом") {
                    val active = p.quickItems.split(',').filter { it.isNotBlank() }
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        QuickChoices.forEach { (key, label) ->
                            val on = key in active
                            FilterChip(
                                selected = on,
                                onClick = {
                                    val next = if (on) active - key else active + key
                                    vm.updatePrefs { it.copy(quickItems = next.joinToString(",")) }
                                },
                                label = { Text(if (on) "${active.indexOf(key) + 1}. $label" else label) },
                            )
                        }
                    }
                    Text(
                        "Включай кнопки в том порядке, в каком хочешь их видеть. Номер показывает место в ряду.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (sCat) {
                SectionCard("Смена категории через бота") {
                    Text("Команда бота")
                    OutlinedTextField(
                        value = p.categoryCmd,
                        onValueChange = { v -> vm.updatePrefs { it.copy(categoryCmd = v.take(12).trim()) } },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    SwitchLine("Отправлять сразу после выбора", p.catAutoSend) { v -> vm.updatePrefs { it.copy(catAutoSend = v) } }
                    Text(
                        "Пишешь в чате команду и начало названия, например «!g ju». Над полем ввода появляются подходящие " +
                            "категории (ищется по началу слов и по инициалам, например jc). Тап подставляет точное название.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (sPlayer) {
                SectionCard("Плеер стрима") {
                    SwitchLine("Показывать видео над чатом", p.showPlayer) { v -> vm.updatePrefs { it.copy(showPlayer = v) } }
                    SwitchLine("Запускать без звука", p.playerMuted) { v -> vm.updatePrefs { it.copy(playerMuted = v) } }
                    Text(
                        "Плеер Twitch открывается над чатом, а в альбомной ориентации слева. Кнопка ▶ в шапке канала " +
                            "прячет и показывает его. Качество и полный экран переключаются прямо в плеере. " +
                            "Если канал оффлайн, плеер скрывается сам.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (sEvents) EventsCard(p, vm)

            if (sAnim) AnimationsCard(p, vm)

            if (sStyles) RulesCard(vm)

            if (sPhr) {
                SectionCard("Быстрые фразы") {
                    PhraseEditor(vm)
                }
            }

            if (sWords) {
                SectionCard("Слова и история") {
                    Text("Подсвечивать сообщения со словами")
                    OutlinedTextField(
                        value = p.highlightWords,
                        onValueChange = { v -> vm.updatePrefs { it.copy(highlightWords = v.take(300)) } },
                        placeholder = { Text("слово1, слово2, фраза") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                    )
                    Text(
                        "Слова через запятую. Такие сообщения в чате выделяются жёлтым.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text("История чата (сообщений в памяти)")
                    ChipChoice(
                        listOf(300, 600, 1000, 2000).map { it.toString() to it },
                        p.bufferSize,
                        { v -> vm.updatePrefs { it.copy(bufferSize = v) } },
                    )
                }
            }

            if (sCmd) {
                SectionCard("Команды в поле чата") {
                    Text(
                        "/ban ник причина\n/timeout ник 10m причина\n/unban ник\n/warn ник причина\n" +
                            "/clear\n/slow 30  /slowoff\n/followers 10m  /followersoff\n/subs  /subsoff\n" +
                            "/emoteonly  /emoteonlyoff\n/announce текст\n/title новое название",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (sBackup) {
                SectionCard("Резервная копия") {
                    Text(
                        "Настройки, оформление, пресеты и шаблоны опросов можно скопировать и сохранить, например в «Избранном» " +
                            "Telegram. Данные входа в копию не попадают.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                clip.setText(AnnotatedString(vm.backupText()))
                                vm.notify("Копия скопирована в буфер обмена")
                            },
                            modifier = Modifier.weight(1f),
                        ) { Text("Скопировать") }
                        OutlinedButton(
                            onClick = {
                                val t = clip.getText()?.text.orEmpty()
                                vm.notify(if (vm.restoreBackup(t)) "Настройки восстановлены" else "В буфере нет копии TwNmMod")
                            },
                            modifier = Modifier.weight(1f),
                        ) { Text("Восстановить") }
                    }
                }
            }

            if (sAppIcon) AppIconCard()

            if (sAcc) {
                SectionCard("Аккаунт") {
                    Text("Вы вошли как ${vm.me.name}")
                    if (version.isNotBlank()) {
                        Text(
                            "Версия приложения: $version",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    OutlinedButton(
                        onClick = { vm.logout() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Выйти из аккаунта") }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SwitchLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
