package com.twnmmod

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

data class ThirdEmote(val name: String, val url: String)

/** Сторонние эмоуты: 7TV, BTTV, FFZ. Любая ошибка сети даёт пустой набор, чат от этого не ломается. */
object Emotes {

    private suspend fun get(url: String): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(url).build()
            Http.client.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
        } catch (e: Exception) {
            null
        }
    }

    private fun obj(s: String?): JSONObject? = try {
        if (s == null) null else JSONObject(s)
    } catch (e: Exception) {
        null
    }

    private fun arr(s: String?): JSONArray? = try {
        if (s == null) null else JSONArray(s)
    } catch (e: Exception) {
        null
    }

    // ---- 7TV ----
    private fun parse7tv(set: JSONObject?): Map<String, ThirdEmote> {
        val a = set?.optJSONArray("emotes") ?: return emptyMap()
        val m = HashMap<String, ThirdEmote>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id")
            val name = o.optString("name")
            if (id.isBlank() || name.isBlank()) continue
            m[name] = ThirdEmote(name, "https://cdn.7tv.app/emote/$id/2x.webp")
        }
        return m
    }

    private suspend fun seventvGlobal() = parse7tv(obj(get("https://7tv.io/v3/emote-sets/global")))

    private suspend fun seventvChannel(twitchId: String) =
        parse7tv(obj(get("https://7tv.io/v3/users/twitch/$twitchId"))?.optJSONObject("emote_set"))

    // ---- BTTV ----
    private fun parseBttv(a: JSONArray?): Map<String, ThirdEmote> {
        if (a == null) return emptyMap()
        val m = HashMap<String, ThirdEmote>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id")
            val code = o.optString("code")
            if (id.isBlank() || code.isBlank()) continue
            m[code] = ThirdEmote(code, "https://cdn.betterttv.net/emote/$id/2x.webp")
        }
        return m
    }

    private suspend fun bttvGlobal() = parseBttv(arr(get("https://api.betterttv.net/3/cached/emotes/global")))

    private suspend fun bttvChannel(twitchId: String): Map<String, ThirdEmote> {
        val o = obj(get("https://api.betterttv.net/3/cached/users/twitch/$twitchId")) ?: return emptyMap()
        return parseBttv(o.optJSONArray("sharedEmotes")) + parseBttv(o.optJSONArray("channelEmotes"))
    }

    // ---- FFZ ----
    private fun parseFfzSet(set: JSONObject?, into: MutableMap<String, ThirdEmote>) {
        val a = set?.optJSONArray("emoticons") ?: return
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val name = o.optString("name")
            val urls = o.optJSONObject("urls") ?: continue
            var u = urls.optString("2")
            if (u.isBlank()) u = urls.optString("1")
            if (u.isBlank() || name.isBlank()) continue
            if (u.startsWith("//")) u = "https:$u"
            into[name] = ThirdEmote(name, u)
        }
    }

    private suspend fun ffzGlobal(): Map<String, ThirdEmote> {
        val o = obj(get("https://api.frankerfacez.com/v1/set/global")) ?: return emptyMap()
        val sets = o.optJSONObject("sets") ?: return emptyMap()
        val defaults = o.optJSONArray("default_sets")
        val out = HashMap<String, ThirdEmote>()
        if (defaults != null) {
            for (i in 0 until defaults.length()) parseFfzSet(sets.optJSONObject(defaults.opt(i).toString()), out)
        }
        return out
    }

    private suspend fun ffzChannel(twitchId: String): Map<String, ThirdEmote> {
        val o = obj(get("https://api.frankerfacez.com/v1/room/id/$twitchId")) ?: return emptyMap()
        val sets = o.optJSONObject("sets") ?: return emptyMap()
        val out = HashMap<String, ThirdEmote>()
        val keys = sets.keys()
        while (keys.hasNext()) parseFfzSet(sets.optJSONObject(keys.next()), out)
        return out
    }

    // Приоритет (от большего): 7TV > BTTV > FFZ, канальные выше глобальных.
    suspend fun loadGlobal(): Map<String, ThirdEmote> = coroutineScope {
        val f = async { ffzGlobal() }
        val b = async { bttvGlobal() }
        val s = async { seventvGlobal() }
        f.await() + b.await() + s.await()
    }

    suspend fun loadChannel(twitchId: String): Map<String, ThirdEmote> = coroutineScope {
        val f = async { ffzChannel(twitchId) }
        val b = async { bttvChannel(twitchId) }
        val s = async { seventvChannel(twitchId) }
        f.await() + b.await() + s.await()
    }
}
