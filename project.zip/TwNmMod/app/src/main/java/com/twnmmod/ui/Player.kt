package com.twnmmod.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Полноэкранный режим для видео из WebView: поворачивает экран и прячет системные панели. */
class PlayerChrome(private val activity: Activity) : WebChromeClient() {
    private var custom: View? = null
    private var callback: CustomViewCallback? = null
    private var oldOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

    var isFull by mutableStateOf(false)
        private set

    override fun onShowCustomView(view: View, cb: CustomViewCallback) {
        if (custom != null) {
            cb.onCustomViewHidden()
            return
        }
        custom = view
        callback = cb
        oldOrientation = activity.requestedOrientation
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        (activity.window.decorView as FrameLayout).addView(
            view,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        val c = WindowCompat.getInsetsController(activity.window, view)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
        isFull = true
    }

    override fun onHideCustomView() {
        val v = custom ?: return
        (activity.window.decorView as FrameLayout).removeView(v)
        custom = null
        WindowCompat.getInsetsController(activity.window, activity.window.decorView)
            .show(WindowInsetsCompat.Type.systemBars())
        activity.requestedOrientation = oldOrientation
        callback?.onCustomViewHidden()
        callback = null
        isFull = false
    }

    fun exit() {
        if (custom != null) onHideCustomView()
    }
}

@SuppressLint("SetJavaScriptEnabled")
fun createPlayerWebView(activity: Activity, chrome: PlayerChrome): WebView = WebView(activity).apply {
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    settings.mediaPlaybackRequiresUserGesture = false
    settings.userAgentString = WebSettings.getDefaultUserAgent(activity)
        .replace("; wv", "")
        .replace(Regex("Version/\\d+\\.\\d+ "), "")
    setBackgroundColor(android.graphics.Color.BLACK)
    webViewClient = WebViewClient()
    webChromeClient = chrome
}

fun loadPlayer(web: WebView, login: String, muted: Boolean) {
    val html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>" +
        "<style>html,body{margin:0;height:100%;background:#000}iframe{border:0}</style></head><body>" +
        "<iframe src='https://player.twitch.tv/?channel=$login&parent=localhost&muted=$muted&autoplay=true' " +
        "height='100%' width='100%' allowfullscreen allow='autoplay; fullscreen'></iframe></body></html>"
    web.loadDataWithBaseURL("https://localhost", html, "text/html", "utf-8", null)
}

/** Плеер сверху (портрет) или слева (альбомная ориентация), под ним или справа чат. */
@Composable
fun PlayerLayout(
    modifier: Modifier,
    web: WebView?,
    landscape: Boolean,
    compact: Boolean,
    content: @Composable ColumnScope.() -> Unit,
) {
    val player: @Composable () -> Unit = {
        if (web != null) AndroidView(factory = { web }, modifier = Modifier.fillMaxSize())
    }
    if (web != null && landscape) {
        Row(modifier.fillMaxSize()) {
            Box(Modifier.weight(0.58f).fillMaxHeight().background(Color.Black)) { player() }
            Column(Modifier.weight(0.42f).fillMaxHeight(), content = content)
        }
    } else {
        Column(modifier.fillMaxSize()) {
            if (web != null) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .then(if (compact) Modifier.height(0.dp) else Modifier.aspectRatio(16f / 9f))
                        .background(Color.Black)
                ) { player() }
            }
            content()
        }
    }
}
