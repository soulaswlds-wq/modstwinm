@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.twnmmod.AppViewModel
import com.twnmmod.Phrase

/** Редактор быстрых фраз: используется и в листе над чатом, и в настройках. */
@Composable
fun PhraseEditor(vm: AppViewModel) {
    val phrases by vm.phrases.collectAsState()
    var editIndex by remember { mutableStateOf(-1) }
    var label by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        phrases.forEachIndexed { i, p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.label, fontWeight = FontWeight.Bold)
                    Text(
                        p.text,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (i > 0) {
                    IconButton(onClick = { vm.movePhraseUp(i) }) { Icon(Icons.Filled.KeyboardArrowUp, "Выше") }
                }
                IconButton(onClick = {
                    editIndex = i
                    label = p.label
                    text = p.text
                }) { Icon(Icons.Filled.Edit, "Править") }
                IconButton(onClick = {
                    vm.removePhrase(i)
                    if (editIndex == i) {
                        editIndex = -1
                        label = ""
                        text = ""
                    }
                }) { Icon(Icons.Filled.Delete, "Удалить") }
            }
        }
        OutlinedTextField(
            value = label,
            onValueChange = { if (it.length <= 20) label = it },
            label = { Text("Название кнопки (коротко)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = text,
            onValueChange = { if (it.length <= 500) text = it },
            label = { Text("Текст сообщения") },
            minLines = 2,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            "В тексте можно написать {user} (ник из ответа) и {channel} (канал). " +
                "Если фраза начинается с /, она выполнится как команда, например /slow 30.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    vm.savePhrase(editIndex, label.trim(), text.trim())
                    editIndex = -1
                    label = ""
                    text = ""
                },
                enabled = label.isNotBlank() && text.isNotBlank(),
            ) { Text(if (editIndex >= 0) "Сохранить" else "Добавить") }
            if (editIndex >= 0) {
                TextButton(onClick = {
                    editIndex = -1
                    label = ""
                    text = ""
                }) { Text("Отмена") }
            }
        }
    }
}

@Composable
fun PhrasesSheet(vm: AppViewModel, onPick: (Phrase) -> Unit, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val phrases by vm.phrases.collectAsState()
    var edit by remember { mutableStateOf(phrases.isEmpty()) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Быстрые фразы", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (!edit) {
                phrases.forEach { p ->
                    FilledTonalButton(onClick = { onPick(p) }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(p.label, fontWeight = FontWeight.Bold)
                            Text(
                                p.text,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
                TextButton(onClick = { edit = true }) { Text("Настроить фразы") }
            } else {
                PhraseEditor(vm)
                if (phrases.isNotEmpty()) TextButton(onClick = { edit = false }) { Text("Готово") }
            }
        }
    }
}
