@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.twnmmod.AppViewModel
import com.twnmmod.Category
import com.twnmmod.fmtClock
import com.twnmmod.fmtCount
import kotlinx.coroutines.delay

@Composable
fun StreamTab(vm: AppViewModel, modifier: Modifier) {
    val chat by vm.chat.collectAsState()
    val info by vm.channelInfo.collectAsState()
    val busy by vm.channelBusy.collectAsState()
    val presets by vm.presets.collectAsState()
    val clipBusy by vm.clipBusy.collectAsState()
    val shield by vm.shield.collectAsState()
    val terms by vm.terms.collectAsState()
    val lastClip by vm.lastClip.collectAsState()
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val isOwn = vm.isOwnChannel()
    val s = chat.settings

    LaunchedEffect(Unit) {
        vm.loadTerms()
        if (isOwn) vm.loadChannelInfo()
    }

    var title by remember(info) { mutableStateOf(info?.title ?: "") }
    var cat by remember(info) {
        mutableStateOf<Category?>(info?.let { if (it.gameId.isNotBlank()) Category(it.gameId, it.gameName, "") else null })
    }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Category>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var slowText by remember(s.slowSec) { mutableStateOf(s.slowSec.toString()) }
    var folText by remember(s.followersMin) { mutableStateOf(s.followersMin.toString()) }
    var annText by remember { mutableStateOf("") }
    var annColor by remember { mutableStateOf("primary") }
    var confirmClear by remember { mutableStateOf(false) }
    var termText by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var confirmRaid by remember { mutableStateOf(false) }

    LaunchedEffect(query) {
        if (query.trim().length < 2) {
            results = emptyList()
            searching = false
        } else {
            searching = true
            delay(350)
            results = vm.searchCategories(query.trim())
            searching = false
        }
    }

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            delay(1000)
            value = System.currentTimeMillis()
        }
    }

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // --- статус ---
        SectionCard("Эфир") {
            val st = chat.stream
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(10.dp).background(
                        if (st != null && st.live) Color(0xFFFF4D4D) else MaterialTheme.colorScheme.outline,
                        CircleShape,
                    )
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    if (st != null && st.live) "В эфире" else "Оффлайн",
                    fontWeight = FontWeight.Bold,
                )
            }
            if (st != null && st.live) {
                Text("Зрителей: ${fmtCount(st.viewers.toLong())}")
                if (st.startedAt > 0) Text("Идёт уже: ${fmtClock((now - st.startedAt) / 1000)}")
                if (st.gameName.isNotBlank()) Text("Категория: ${st.gameName}")
            }
        }

        // --- клипы ---
        SectionCard("Клипы") {
            Button(
                onClick = { vm.createClip() },
                enabled = !clipBusy,
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (clipBusy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else Text("Сделать клип (последние ~30 секунд)")
            }
            Text(
                "Работает только во время эфира. Для клипов нужны права, которые выдаются при входе.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            lastClip?.let { url ->
                Text(url, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        clipboard.setText(AnnotatedString(url))
                        vm.notify("Ссылка скопирована")
                    }) { Text("Копировать ссылку") }
                    OutlinedButton(onClick = {
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e: Exception) {
                        }
                    }) { Text("Открыть") }
                }
            }
        }

        // --- название и категория ---
        SectionCard("Название и категория") {
            if (!isOwn) {
                Text(
                    "Менять название и категорию через API Twitch может только владелец канала. " +
                        "Открой свой канал, чтобы редактировать.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                )
            } else {
                OutlinedTextField(
                    value = title,
                    onValueChange = { if (it.length <= 140) title = it },
                    label = { Text("Название стрима") },
                    supportingText = { Text("${title.length}/140") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 4,
                )
                Text(
                    "Категория: ${cat?.name ?: "не выбрана"}",
                    fontWeight = FontWeight.Bold,
                )
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Найти категорию") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        if (searching) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    },
                )
                results.forEach { c ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            cat = c
                            query = ""
                            results = emptyList()
                        }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AsyncImage(
                            model = c.art,
                            contentDescription = null,
                            modifier = Modifier.size(width = 36.dp, height = 50.dp),
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(c.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { vm.saveChannel(title.trim(), cat?.id, cat?.name) },
                        enabled = title.isNotBlank() && !busy,
                        modifier = Modifier.weight(1f),
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Text("Применить")
                    }
                    OutlinedButton(
                        onClick = { vm.addPreset(title.trim(), cat?.id.orEmpty(), cat?.name.orEmpty()) },
                        enabled = title.isNotBlank(),
                    ) { Text("В пресеты") }
                }
                if (presets.isNotEmpty()) {
                    Text("Пресеты", style = MaterialTheme.typography.labelMedium)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        presets.forEach { p ->
                            InputChip(
                                selected = false,
                                onClick = {
                                    title = p.title
                                    cat = if (p.gameId.isNotBlank()) Category(p.gameId, p.gameName, "") else null
                                },
                                label = {
                                    Text(
                                        (if (p.gameName.isNotBlank()) p.gameName + " — " else "") + p.title,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.width(200.dp),
                                    )
                                },
                                trailingIcon = {
                                    Icon(
                                        Icons.Filled.Close,
                                        "Удалить пресет",
                                        Modifier.size(16.dp).clickable { vm.removePreset(p) },
                                    )
                                },
                            )
                        }
                    }
                }
            }
        }

        // --- режимы чата ---
        SectionCard("Режимы чата") {
            ModeRow(
                label = "Медленный режим (сек)",
                checked = s.slow,
                value = slowText,
                onValue = { v -> if (v.length <= 3 && v.all { it.isDigit() }) slowText = v },
                dirty = s.slow && slowText.toIntOrNull() != s.slowSec,
                onToggle = { vm.setSlow(it, slowText.toIntOrNull() ?: 30) },
                onApply = { vm.setSlow(true, slowText.toIntOrNull() ?: 30) },
            )
            ModeRow(
                label = "Только фолловеры (мин)",
                checked = s.followers,
                value = folText,
                onValue = { v -> if (v.length <= 6 && v.all { it.isDigit() }) folText = v },
                dirty = s.followers && folText.toIntOrNull() != s.followersMin,
                onToggle = { vm.setFollowers(it, folText.toIntOrNull() ?: 0) },
                onApply = { vm.setFollowers(true, folText.toIntOrNull() ?: 0) },
            )
            SwitchRow("Только для сабов", s.subs) { vm.setSubs(it) }
            SwitchRow("Только эмоуты", s.emote) { vm.setEmote(it) }
            SwitchRow("Уникальные сообщения", s.unique) { vm.setUnique(it) }
        }

        // --- защита и фильтры ---
        SectionCard("Защита и фильтры") {
            SwitchRow("Режим защиты (Shield Mode)", shield) { vm.setShield(it) }
            Text(
                "Включает ограничения чата, настроенные на Twitch для защиты от рейдов и спама.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text("Запрещённые слова", style = MaterialTheme.typography.labelMedium)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = termText,
                    onValueChange = { if (it.length <= 100) termText = it },
                    label = { Text("Слово или фраза") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Button(
                    onClick = {
                        vm.addTerm(termText)
                        termText = ""
                    },
                    enabled = termText.trim().length >= 2,
                ) { Text("Добавить") }
            }
            if (terms.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    terms.forEach { (id, text) ->
                        InputChip(
                            selected = false,
                            onClick = {},
                            label = { Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            trailingIcon = {
                                Icon(
                                    Icons.Filled.Close,
                                    "Убрать слово",
                                    Modifier.size(16.dp).clickable { vm.removeTerm(id, text) },
                                )
                            },
                        )
                    }
                }
            }
        }

        // --- шаутаут и рейд ---
        SectionCard(if (isOwn) "Шаутаут и рейд" else "Шаутаут") {
            OutlinedTextField(
                value = target,
                onValueChange = { target = it.trim() },
                label = { Text("Ник канала") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { vm.shoutout(target) },
                    enabled = target.isNotBlank(),
                    modifier = Modifier.weight(1f),
                ) { Text("Шаутаут") }
                if (isOwn) {
                    OutlinedButton(
                        onClick = { confirmRaid = true },
                        enabled = target.isNotBlank(),
                        modifier = Modifier.weight(1f),
                    ) { Text("Рейд") }
                }
            }
            if (isOwn) {
                TextButton(onClick = { vm.cancelRaid() }) { Text("Отменить запущенный рейд") }
            }
            Text(
                "Шаутаут работает во время эфира, у Twitch есть интервал между шаутаутами.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // --- объявление ---
        SectionCard("Объявление в чат") {
            OutlinedTextField(
                value = annText,
                onValueChange = { if (it.length <= 500) annText = it },
                label = { Text("Текст объявления") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
            )
            ChipChoice(
                options = listOf(
                    "Обычное" to "primary", "Синее" to "blue", "Зелёное" to "green",
                    "Оранжевое" to "orange", "Фиолетовое" to "purple",
                ),
                selected = annColor,
                onSelect = { annColor = it },
            )
            Button(
                onClick = {
                    vm.announce(annText.trim(), annColor)
                    annText = ""
                },
                enabled = annText.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Отправить объявление") }
        }

        Button(
            onClick = { confirmClear = true },
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.errorContainer,
                contentColor = MaterialTheme.colorScheme.onErrorContainer,
            ),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Очистить чат") }
        Spacer(Modifier.height(8.dp))
    }

    if (confirmRaid) {
        AlertDialog(
            onDismissRequest = { confirmRaid = false },
            title = { Text("Начать рейд на $target?") },
            text = { Text("Зрители будут перенаправлены на канал после короткого отсчёта. Рейд можно отменить.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRaid = false
                    vm.raid(target)
                }) { Text("Рейд") }
            },
            dismissButton = { TextButton(onClick = { confirmRaid = false }) { Text("Отмена") } },
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Очистить чат?") },
            text = { Text("Все сообщения будут удалены у всех зрителей.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    vm.clearChat()
                }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ModeRow(
    label: String,
    checked: Boolean,
    value: String,
    onValue: (String) -> Unit,
    dirty: Boolean,
    onToggle: (Boolean) -> Unit,
    onApply: () -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        OutlinedTextField(
            value = value,
            onValueChange = onValue,
            modifier = Modifier.width(84.dp),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )
        if (dirty) {
            IconButton(onClick = onApply) { Icon(Icons.Filled.Check, "Применить") }
        }
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}
