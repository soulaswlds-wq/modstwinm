package com.twnmmod

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

sealed class IrcEvent {
    class Message(val msg: ChatMsg) : IrcEvent()
    class Deleted(val msgId: String) : IrcEvent()
    class Cleared(val userId: String?, val login: String, val durationSec: Int?) : IrcEvent()
    class Notice(val text: String) : IrcEvent()
    class Status(val text: String, val connected: Boolean) : IrcEvent()
    class Room(val tags: Map<String, String>) : IrcEvent()
    class Self(val state: SelfState) : IrcEvent()
}

private fun planRu(plan: String?): String = when (plan) {
    "Prime" -> "Prime"
    "1000" -> "Tier 1"
    "2000" -> "Tier 2"
    "3000" -> "Tier 3"
    else -> ""
}

private val FALLBACK_COLORS = longArrayOf(
    0xFFFF6B6B, 0xFF4DA3FF, 0xFF5BE37D, 0xFFFFB347, 0xFFC77DFF, 0xFF3DD6D0, 0xFFFF7AC6,
)

fun parseColor(tag: String?, login: String): Long {
    if (tag != null && tag.length == 7 && tag[0] == '#') {
        val v = tag.substring(1).toLongOrNull(16)
        if (v != null) {
            var r = ((v shr 16) and 0xFF).toInt()
            var g = ((v shr 8) and 0xFF).toInt()
            var b = (v and 0xFF).toInt()
            val lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
            if (lum < 0.35) {
                r += ((255 - r) * 0.5).toInt()
                g += ((255 - g) * 0.5).toInt()
                b += ((255 - b) * 0.5).toInt()
            }
            return 0xFF000000L or (r.toLong() shl 16) or (g.toLong() shl 8) or b.toLong()
        }
    }
    return FALLBACK_COLORS[(login.hashCode() and 0x7FFFFFFF) % FALLBACK_COLORS.size]
}

class IrcClient(
    private val auth: Auth,
    private val selfLogin: () -> String,
    private val scope: CoroutineScope,
    private val onEvent: (IrcEvent) -> Unit,
) {
    private val client = Http.client.newBuilder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(30, TimeUnit.SECONDS)
        .build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var channel = ""
    @Volatile private var authFailed = false
    @Volatile private var joined = false
    private var job: Job? = null

    fun connect(login: String) {
        disconnect()
        channel = login.lowercase()
        job = scope.launch(Dispatchers.IO) {
            var backoff = 1000L
            while (isActive) {
                val closed = CompletableDeferred<Unit>()
                joined = false
                onEvent(IrcEvent.Status("Подключение к чату…", false))
                try {
                    if (authFailed) {
                        authFailed = false
                        auth.refresh()
                    }
                    val token = auth.validToken()
                    val req = Request.Builder().url("wss://irc-ws.chat.twitch.tv:443").build()
                    val ws = client.newWebSocket(req, object : WebSocketListener() {
                        override fun onOpen(webSocket: WebSocket, response: Response) {
                            webSocket.send("CAP REQ :twitch.tv/tags twitch.tv/commands")
                            webSocket.send("PASS oauth:$token")
                            webSocket.send("NICK ${selfLogin().lowercase()}")
                            webSocket.send("JOIN #$channel")
                        }

                        override fun onMessage(webSocket: WebSocket, text: String) {
                            text.split("\r\n").forEach { if (it.isNotBlank()) handle(webSocket, it) }
                        }

                        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                            webSocket.close(1000, null)
                        }

                        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                            closed.complete(Unit)
                        }

                        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                            closed.complete(Unit)
                        }
                    })
                    socket = ws
                    try {
                        closed.await()
                    } finally {
                        ws.cancel()
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: ApiException) {
                    onEvent(IrcEvent.Notice(e.message ?: "Ошибка чата"))
                } catch (e: Exception) {
                    // сеть: просто переподключимся
                }
                if (!isActive) break
                if (joined) backoff = 1000L
                onEvent(IrcEvent.Status("Нет связи, переподключаюсь…", false))
                delay(backoff)
                backoff = (backoff * 2).coerceAtMost(15_000L)
            }
        }
    }

    fun disconnect() {
        job?.cancel()
        job = null
        socket?.close(1000, null)
        socket = null
    }

    fun send(text: String, replyTo: String? = null): Boolean {
        val clean = text.replace('\r', ' ').replace('\n', ' ').take(500)
        val tag = if (replyTo != null) "@reply-parent-msg-id=$replyTo " else ""
        return socket?.send("${tag}PRIVMSG #$channel :$clean") ?: false
    }

    private fun unescape(v: String): String {
        if (!v.contains('\\')) return v
        val sb = StringBuilder()
        var i = 0
        while (i < v.length) {
            val c = v[i]
            if (c == '\\' && i + 1 < v.length) {
                when (v[i + 1]) {
                    's' -> sb.append(' ')
                    ':' -> sb.append(';')
                    '\\' -> sb.append('\\')
                    'r' -> sb.append('\r')
                    'n' -> sb.append('\n')
                    else -> sb.append(v[i + 1])
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }

    private fun parseEmotes(tag: String?, text: String): List<EmoteSpan> {
        if (tag.isNullOrBlank()) return emptyList()
        val out = ArrayList<EmoteSpan>()
        for (group in tag.split('/')) {
            val colon = group.indexOf(':')
            if (colon < 0) continue
            val id = group.substring(0, colon)
            for (r in group.substring(colon + 1).split(',')) {
                val dash = r.indexOf('-')
                if (dash < 0) continue
                val s = r.substring(0, dash).toIntOrNull() ?: continue
                val e = r.substring(dash + 1).toIntOrNull() ?: continue
                try {
                    // Twitch считает позиции в code points
                    val a = text.offsetByCodePoints(0, s)
                    val b = text.offsetByCodePoints(0, e + 1)
                    out.add(EmoteSpan(id, a, b))
                } catch (ex: IndexOutOfBoundsException) {
                }
            }
        }
        return out.sortedBy { it.start }
    }

    private fun handle(sock: WebSocket, raw: String) {
        var line = raw
        val tags = HashMap<String, String>()
        if (line.startsWith("@")) {
            val sp = line.indexOf(' ')
            if (sp < 0) return
            line.substring(1, sp).split(';').forEach { kv ->
                val i = kv.indexOf('=')
                if (i > 0) tags[kv.substring(0, i)] = unescape(kv.substring(i + 1)) else tags[kv] = ""
            }
            line = line.substring(sp + 1)
        }
        var prefix = ""
        if (line.startsWith(":")) {
            val sp = line.indexOf(' ')
            if (sp < 0) return
            prefix = line.substring(1, sp)
            line = line.substring(sp + 1)
        }
        val tIdx = line.indexOf(" :")
        val trailing = if (tIdx >= 0) line.substring(tIdx + 2) else ""
        val head = if (tIdx >= 0) line.substring(0, tIdx) else line
        val cmd = head.split(' ')[0]

        when (cmd) {
            "PING" -> sock.send("PONG :$trailing")
            "RECONNECT" -> sock.close(1000, null)
            "JOIN" -> {
                if (prefix.substringBefore('!').equals(selfLogin(), true)) {
                    joined = true
                    onEvent(IrcEvent.Status("В чате", true))
                }
            }
            "ROOMSTATE" -> {
                joined = true
                onEvent(IrcEvent.Status("В чате", true))
                onEvent(IrcEvent.Room(tags))
            }
            "USERSTATE" -> {
                val badges = tags["badges"].orEmpty()
                onEvent(
                    IrcEvent.Self(
                        SelfState(
                            color = tags["color"]?.takeIf { it.isNotBlank() }?.let { parseColor(it, selfLogin()) },
                            isMod = tags["mod"] == "1" || badges.contains("moderator/"),
                            isBroadcaster = badges.contains("broadcaster/"),
                            isVip = badges.contains("vip/"),
                            isSub = badges.contains("subscriber/"),
                        )
                    )
                )
            }
            "PRIVMSG" -> {
                val login = prefix.substringBefore('!')
                var text = trailing
                var kind = MsgKind.CHAT
                if (text.startsWith("\u0001ACTION ") && text.endsWith("\u0001")) {
                    text = text.substring(8, text.length - 1)
                    kind = MsgKind.ACTION
                }
                val badges = tags["badges"].orEmpty()
                val me = selfLogin()
                val msgIdTag = tags["msg-id"]
                val bits = tags["bits"]
                val reward: Pair<String, Long>? = when {
                    msgIdTag == "highlighted-message" -> "⭐ Выделенное сообщение за баллы" to 0xFFFFC107
                    msgIdTag == "skip-subs-mode-message" -> "🔓 Сообщение в режиме «только сабы» за баллы" to 0xFF26C6DA
                    msgIdTag == "animated-message" -> "✨ Анимированное сообщение за баллы" to 0xFFB388FF
                    msgIdTag == "gigantified-emote-message" -> "🔥 Гигантский смайл за баллы" to 0xFFFF7043
                    tags["custom-reward-id"] != null -> "🎁 Награда за баллы" to 0xFF9146FF
                    bits != null -> "⚡ $bits битсов" to 0xFF3B9BFF
                    else -> null
                }
                val msg = ChatMsg(
                    id = tags["id"] ?: "irc-${System.nanoTime()}",
                    userId = tags["user-id"].orEmpty(),
                    login = login,
                    display = tags["display-name"]?.takeIf { it.isNotBlank() } ?: login,
                    color = parseColor(tags["color"], login),
                    text = text,
                    emotes = parseEmotes(tags["emotes"], text),
                    isBroadcaster = badges.contains("broadcaster/"),
                    isMod = tags["mod"] == "1" || badges.contains("moderator/"),
                    isVip = badges.contains("vip/"),
                    isSub = badges.contains("subscriber/") || badges.contains("founder/"),
                    firstMsg = tags["first-msg"] == "1",
                    time = tags["tmi-sent-ts"]?.toLongOrNull() ?: System.currentTimeMillis(),
                    kind = kind,
                    replyTo = tags["reply-parent-display-name"]?.let { n ->
                        "$n: ${tags["reply-parent-msg-body"].orEmpty()}"
                    },
                    mention = me.isNotBlank() && !login.equals(me, true) &&
                        text.contains("@$me", ignoreCase = true),
                    rewardTag = reward?.first,
                    rewardColor = reward?.second,
                )
                onEvent(IrcEvent.Message(msg))
            }
            "USERNOTICE" -> {
                val msgId = tags["msg-id"].orEmpty()
                val login = tags["login"].orEmpty()
                val name = tags["display-name"]?.takeIf { it.isNotBlank() } ?: login
                val sysMsg = tags["system-msg"].orEmpty()
                val plan = planRu(tags["msg-param-sub-plan"])
                val kindTitle: Pair<String, String> = when (msgId) {
                    "sub" -> "sub" to "$name подписался" + (if (plan.isNotEmpty()) " · $plan" else "")
                    "resub" -> "resub" to "$name продлил подписку · ${tags["msg-param-cumulative-months"] ?: "?"} мес." +
                        (if (plan.isNotEmpty()) " · $plan" else "")
                    "subgift", "anonsubgift" -> "gift" to "$name подарил подписку ${tags["msg-param-recipient-display-name"] ?: ""}".trim()
                    "submysterygift" -> "gift" to "$name раздаёт подписки: ${tags["msg-param-mass-gift-count"] ?: "?"}"
                    "giftpaidupgrade", "primepaidupgrade", "anongiftpaidupgrade" -> "sub" to "$name продолжает подписку"
                    "raid" -> "raid" to "Рейд от $name · ${tags["msg-param-viewerCount"] ?: "?"} зрителей"
                    "ritual" -> "ritual" to "$name впервые в чате"
                    "announcement" -> "announce" to "Объявление · $name"
                    "bitsbadgetier" -> "cheer" to "$name получил новый бейдж битсов"
                    else -> "notice" to sysMsg.ifBlank { msgId }
                }
                val color: Long? = when (tags["msg-param-color"]?.uppercase()) {
                    "BLUE" -> 0xFF3B9BFF
                    "GREEN" -> 0xFF00C897
                    "ORANGE" -> 0xFFFF8A3D
                    "PURPLE" -> 0xFFB388FF
                    else -> null
                }
                if (kindTitle.second.isNotBlank()) {
                    onEvent(
                        IrcEvent.Message(
                            ChatMsg(
                                id = tags["id"] ?: "un-${System.nanoTime()}",
                                userId = tags["user-id"].orEmpty(),
                                login = login,
                                display = name,
                                color = null,
                                text = trailing,
                                emotes = parseEmotes(tags["emotes"], trailing),
                                kind = if (tags["user-id"].isNullOrBlank()) MsgKind.SYSTEM else MsgKind.CHAT,
                                eventKind = kindTitle.first,
                                eventTitle = kindTitle.second,
                                eventColor = color,
                            )
                        )
                    )
                }
            }
            "CLEARMSG" -> tags["target-msg-id"]?.let { onEvent(IrcEvent.Deleted(it)) }
            "CLEARCHAT" -> {
                val uid = tags["target-user-id"]
                onEvent(IrcEvent.Cleared(uid, trailing, tags["ban-duration"]?.toIntOrNull()))
            }
            "NOTICE" -> {
                if (trailing.contains("authentication failed", true)) authFailed = true
                onEvent(IrcEvent.Notice(trailing))
            }
        }
    }
}
