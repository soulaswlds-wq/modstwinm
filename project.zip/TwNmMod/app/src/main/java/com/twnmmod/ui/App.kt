@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twnmmod.AppViewModel
import com.twnmmod.AuthState
import com.twnmmod.ChannelRef
import com.twnmmod.CrashReport
import com.twnmmod.fmtCount

@Composable
fun App(vm: AppViewModel, crash: CrashReport? = null, onCrashClosed: () -> Unit = {}) {
    val prefs by vm.prefs.collectAsState()
    val auth by vm.authState.collectAsState()
    val current by vm.current.collectAsState()
    val settings by vm.showSettings.collectAsState()
    val ctx = LocalContext.current
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.toasts.collect { msg ->
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(msg)
        }
    }

    val keepOn = current != null && prefs.keepScreen
    DisposableEffect(keepOn) {
        val w = (ctx as? Activity)?.window
        if (keepOn) w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    AppTheme(Color(prefs.accent), prefs.bg, prefs.rounding, prefs.themeId) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Box(Modifier.fillMaxSize()) {
                ThemeBackdrop(prefs.themeId, Modifier.fillMaxSize())
                if (auth !is AuthState.SignedIn) {
                    LoginScreen(vm)
                } else if (settings) {
                    BackHandler { vm.openSettings(false) }
                    SettingsScreen(vm)
                } else if (current != null) {
                    BackHandler { vm.closeChannel() }
                    ChannelScreen(vm)
                } else {
                    ChannelsScreen(vm)
                }
                var crashOpen by remember { mutableStateOf(crash != null) }
                if (crash != null && crashOpen) {
                    val clip = LocalClipboardManager.current
                    AlertDialog(
                        onDismissRequest = {
                            crashOpen = false
                            onCrashClosed()
                        },
                        title = { Text("Прошлый запуск завершился ошибкой") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (crash.wasReset) {
                                    Text(
                                        "Вход и настройки сброшены автоматически, чтобы приложение открылось. Войди заново.",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                                Text(
                                    "Нажми «Копировать» и пришли текст ошибки разработчику:",
                                    style = MaterialTheme.typography.bodySmall,
                                )
                                Box(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                                    Text(crash.text, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { clip.setText(AnnotatedString(crash.text)) }) { Text("Копировать") }
                        },
                        dismissButton = {
                            TextButton(onClick = {
                                crashOpen = false
                                onCrashClosed()
                            }) { Text("Закрыть") }
                        },
                    )
                }
                var splash by rememberSaveable { mutableStateOf(true) }
                LaunchedEffect(Unit) {
                    delay(1000)
                    splash = false
                }
                AnimatedVisibility(
                    visible = splash,
                    enter = EnterTransition.None,
                    exit = fadeOut(tween(280)),
                ) { SplashOverlay(Color(prefs.accent)) }
                SnackbarHost(
                    snackbar,
                    Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 56.dp),
                )
            }
        }
    }
}

@Composable
fun LoginScreen(vm: AppViewModel) {
    val state by vm.authState.collectAsState()
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Filled.Security, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text("TwNmMod", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(
            "Модерация Twitch с телефона",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(32.dp))

        when (val s = state) {
            is AuthState.Waiting -> {
                Text("Твой код:", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text(
                    s.device.userCode,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 6.sp,
                    color = MaterialTheme.colorScheme.primary,
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        clipboard.setText(AnnotatedString(s.device.userCode))
                        try {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(s.device.uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Exception) {
                        }
                    },
                    Modifier.fillMaxWidth(),
                ) { Text("Скопировать код и открыть Twitch") }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Откроется twitch.tv/activate. Введи код (если не подставился сам) и нажми «Авторизовать». Потом вернись сюда.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
                CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                Spacer(Modifier.height(4.dp))
                Text("Жду подтверждения…", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.cancelLogin() }) { Text("Отмена") }
            }
            is AuthState.Busy -> CircularProgressIndicator()
            else -> {
                val err = (s as? AuthState.SignedOut)?.error
                if (err != null) {
                    NoteCard(err, error = true)
                    Spacer(Modifier.height(12.dp))
                }
                Button(onClick = { vm.startLogin() }, Modifier.fillMaxWidth()) { Text("Войти через Twitch") }
            }
        }
    }
}

@Composable
fun ChannelsScreen(vm: AppViewModel) {
    val st by vm.channels.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    val myId = vm.myId

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Каналы") },
                actions = {
                    IconButton(onClick = { vm.loadChannels() }) { Icon(Icons.Filled.Refresh, "Обновить") }
                    IconButton(onClick = { vm.openSettings(true) }) { Icon(Icons.Filled.Settings, "Настройки") }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("Открыть чат по нику") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = {
                            if (query.isNotBlank()) vm.openByLogin(query)
                        }),
                    )
                    Button(onClick = { if (query.isNotBlank()) vm.openByLogin(query) }) { Text("Открыть") }
                }
            }
            if (st.loading) {
                item {
                    Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                    }
                }
            }
            st.error?.let { e -> item { NoteCard("Не удалось загрузить список каналов: $e", error = true) } }
            items(st.list, key = { it.id }) { ch ->
                ChannelCard(ch, own = ch.id == myId) { vm.openChannel(ch) }
            }
            item {
                Text(
                    "Здесь твой канал и каналы, где ты модератор.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ChannelCard(ch: ChannelRef, own: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(ch.name.take(1).uppercase(), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(ch.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (own) "Твой канал · полный доступ" else "Ты модератор",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun ChannelScreen(vm: AppViewModel) {
    val ch by vm.current.collectAsState()
    val chat by vm.chat.collectAsState()
    val prefs by vm.prefs.collectAsState()
    val clipBusy by vm.clipBusy.collectAsState()
    val unbanState by vm.unban.collectAsState()
    val suspectList by vm.suspects.collectAsState()
    val modBadge = unbanState.items.size + suspectList.size
    var tab by rememberSaveable { mutableStateOf(prefs.startTab.coerceIn(0, 4)) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var filter by rememberSaveable { mutableStateOf("") }
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val channel = ch ?: return
    val appCtx = LocalContext.current.applicationContext
    val activity = LocalContext.current as? Activity
    val chrome = remember(channel.login) { activity?.let { PlayerChrome(it) } }
    val playerWeb = remember(channel.login) {
        lazy {
            try {
                if (activity != null && chrome != null) createPlayerWebView(activity, chrome) else null
            } catch (e: Throwable) {
                null
            }
        }
    }
    DisposableEffect(playerWeb) {
        onDispose {
            chrome?.exit()
            if (playerWeb.isInitialized()) playerWeb.value?.destroy()
        }
    }
    BackHandler(enabled = chrome?.isFull == true) { chrome?.exit() }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, playerWeb) {
        val observer = LifecycleEventObserver { _, event ->
            if (playerWeb.isInitialized()) {
                when (event) {
                    Lifecycle.Event.ON_STOP -> playerWeb.value?.onPause()
                    Lifecycle.Event.ON_START -> playerWeb.value?.onResume()
                    else -> {}
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val modWeb = remember(channel.login) { lazy { try { createModWebView(appCtx) } catch (e: Throwable) { null } } }
    DisposableEffect(modWeb) { onDispose { if (modWeb.isInitialized()) modWeb.value?.destroy() } }

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = { vm.closeChannel() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад")
                    }
                },
                title = {
                    if (searching && tab == 0) {
                        OutlinedTextField(
                            value = filter,
                            onValueChange = { filter = it },
                            singleLine = true,
                            placeholder = { Text("Поиск по чату") },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    } else {
                        Column {
                            Text(channel.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val s = chat.stream
                            Text(
                                when {
                                    !chat.connected -> chat.status
                                    s != null && s.live -> "● В эфире · ${fmtCount(s.viewers.toLong())}"
                                    else -> "Оффлайн"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (chat.connected && s != null && s.live) Color(0xFFFF5C5C)
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                actions = {
                    if (tab == 0) {
                        IconButton(onClick = {
                            searching = !searching
                            if (!searching) filter = ""
                        }) {
                            Icon(if (searching) Icons.Filled.Close else Icons.Filled.Search, "Поиск")
                        }
                    }
                    IconButton(onClick = { vm.updatePrefs { it.copy(showPlayer = !it.showPlayer) } }) {
                        Icon(
                            Icons.Filled.PlayArrow,
                            "Плеер",
                            tint = if (prefs.showPlayer) MaterialTheme.colorScheme.primary else LocalContentColor.current,
                        )
                    }
                    IconButton(onClick = { vm.createClip() }, enabled = !clipBusy) {
                        Icon(Icons.Filled.ContentCut, "Быстрый клип")
                    }
                    IconButton(onClick = { vm.openSettings(true) }) { Icon(Icons.Filled.Settings, "Настройки") }
                },
            )
        },
        bottomBar = {
            if (!imeVisible) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    val items = listOf(
                        "Чат" to Icons.Filled.Chat,
                        "Стрим" to Icons.Filled.LiveTv,
                        "Опросы" to Icons.Filled.Poll,
                        "Модер" to Icons.Filled.Security,
                        "Журнал" to Icons.Filled.History,
                    )
                    items.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = {
                                if (label == "Модер" && modBadge > 0) {
                                    BadgedBox(badge = { Badge { Text("$modBadge") } }) { Icon(icon, label) }
                                } else {
                                    Icon(icon, label)
                                }
                            },
                            label = { Text(label) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        val m = Modifier.padding(pad)
        when (tab) {
            0 -> ChatTab(vm, m, if (searching) filter else "", playerWeb) {
                searching = !searching
                if (!searching) filter = ""
            }
            1 -> StreamTab(vm, m)
            2 -> PollsTab(vm, m, modWeb)
            3 -> ModTab(vm, m)
            else -> LogTab(vm, m)
        }
    }
}
