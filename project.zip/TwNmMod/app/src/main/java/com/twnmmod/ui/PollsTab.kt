@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.layout.fillMaxSize
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.background
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.twnmmod.AppViewModel
import com.twnmmod.fmtClock
import com.twnmmod.fmtCount
import com.twnmmod.fmtDur
import kotlinx.coroutines.delay

private val PollColors = listOf(
    Color(0xFF9146FF), Color(0xFF3B9BFF), Color(0xFF00C897), Color(0xFFFF8A3D), Color(0xFFFF5C9D),
    Color(0xFFB6F442), Color(0xFF00B8D9), Color(0xFFE6B800), Color(0xFFB388FF), Color(0xFFFF6B6B),
)

fun openCustomTab(ctx: Context, url: String) {
    try {
        CustomTabsIntent.Builder().setShowTitle(true).build().launchUrl(ctx, Uri.parse(url))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) {
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
fun createModWebView(ctx: Context): WebView = WebView(ctx).apply {
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    settings.useWideViewPort = true
    settings.loadWithOverviewMode = true
    settings.setSupportZoom(true)
    settings.builtInZoomControls = true
    settings.displayZoomControls = false
    settings.userAgentString = WebSettings.getDefaultUserAgent(ctx)
        .replace("; wv", "")
        .replace(Regex("Version/\\d+\\.\\d+ "), "")
    setBackgroundColor(android.graphics.Color.parseColor("#0E0E10"))
    CookieManager.getInstance().setAcceptCookie(true)
    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
    webViewClient = WebViewClient()
}

@Composable
fun PollsTab(vm: AppViewModel, modifier: Modifier, webLazy: Lazy<WebView?>) {
    val isOwn = vm.isOwnChannel()
    var mode by rememberSaveable { mutableStateOf(0) }
    val note by vm.panelNote.collectAsState()
    val ctx = LocalContext.current
    val login = vm.current.collectAsState().value?.login.orEmpty()
    val modUrl = "https://www.twitch.tv/moderator/$login"

    if (!isOwn) {
        var embedded by rememberSaveable { mutableStateOf(false) }
        Column(
            modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            NoteCard(
                "Опросы и ставки на чужом канале Twitch API не даёт. Панель модератора откроется в Chrome, " +
                    "где ты уже вошёл в Twitch, в том числе через Google. Назад в приложение вернёт кнопка «назад»."
            )
            Button(onClick = { openCustomTab(ctx, modUrl) }, modifier = Modifier.fillMaxWidth()) {
                Text("Открыть панель модератора")
            }
            OutlinedButton(onClick = { embedded = !embedded }, modifier = Modifier.fillMaxWidth()) {
                Text(if (embedded) "Скрыть встроенную панель" else "Попробовать встроенную панель")
            }
            if (embedded) {
                val web = webLazy.value
                if (web == null) {
                    NoteCard("Встроенный браузер недоступен на этом телефоне. Используй кнопку выше.", error = true)
                } else {
                    LaunchedEffect(login) { if (web.url == null) web.loadUrl(modUrl) }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { web.loadUrl(modUrl) }) { Text("Панель") }
                        TextButton(onClick = { web.reload() }) { Text("Обновить") }
                        Text(
                            "Вход Twitch тут может блокироваться",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    AndroidView(factory = { web }, modifier = Modifier.weight(1f).fillMaxWidth())
                }
            }
        }
        return
    }

    Column(modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChipChoice(listOf("Опросы" to 0, "Ставки" to 1), mode, { mode = it })
        }
        LaunchedEffect(mode) {
            while (true) {
                if (mode == 0) vm.refreshPoll() else vm.refreshPrediction()
                delay(4000)
            }
        }
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 12.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            note?.let { NoteCard(it, error = true) }
            if (mode == 0) PollPanel(vm) else PredictionPanel(vm)
        }
    }
}

@Composable
private fun ShareBar(fraction: Float, color: Color) {
    Box(
        Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
            .background(MaterialTheme.colorScheme.outline)
    ) {
        Box(
            Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().background(color)
        )
    }
}

@Composable
private fun OptionFields(
    options: List<String>,
    maxCount: Int,
    maxLen: Int,
    label: String,
    onChange: (List<String>) -> Unit,
) {
    options.forEachIndexed { i, v ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = v,
                onValueChange = { nv ->
                    if (nv.length <= maxLen) onChange(options.toMutableList().also { it[i] = nv })
                },
                label = { Text("$label ${i + 1}") },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            if (options.size > 2) {
                IconButton(onClick = { onChange(options.toMutableList().also { it.removeAt(i) }) }) {
                    Icon(Icons.Filled.Close, "Убрать")
                }
            }
        }
    }
    if (options.size < maxCount) {
        TextButton(onClick = { onChange(options + "") }) {
            Icon(Icons.Filled.Add, null)
            Text("Добавить вариант")
        }
    }
}

// ---------------- опросы ----------------

@Composable
private fun PollPanel(vm: AppViewModel) {
    val poll by vm.poll.collectAsState()
    val templates by vm.pollTemplates.collectAsState()
    var title by remember { mutableStateOf("") }
    var options by remember { mutableStateOf(listOf("", "")) }
    var seconds by remember { mutableStateOf(120) }

    poll?.let { p ->
        val active = p.status == "ACTIVE"
        SectionCard(if (active) "Идёт опрос" else "Последний опрос (${statusRu(p.status)})") {
            Text(p.title, fontWeight = FontWeight.Bold)
            if (active) {
                val left by produceState(0L, p.id, p.startedAt) {
                    while (true) {
                        value = (p.startedAt + p.duration * 1000L - System.currentTimeMillis()) / 1000
                        delay(1000)
                    }
                }
                Text("Осталось: ${fmtClock(left)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val total = p.choices.sumOf { it.votes }.coerceAtLeast(1)
            val maxVotes = p.choices.maxOfOrNull { it.votes } ?: 0
            p.choices.forEachIndexed { i, c ->
                Row {
                    Text(
                        c.title,
                        Modifier.weight(1f),
                        fontWeight = if (!active && c.votes == maxVotes && maxVotes > 0) FontWeight.Bold else FontWeight.Normal,
                    )
                    Text("${c.votes} · ${c.votes * 100 / total}%")
                }
                ShareBar(c.votes.toFloat() / total, PollColors[i % PollColors.size])
            }
            if (active) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.endPoll(false) }, Modifier.weight(1f)) { Text("Завершить") }
                    OutlinedButton(onClick = { vm.endPoll(true) }, Modifier.weight(1f)) { Text("Удалить") }
                }
            }
        }
    }

    val pollActive = poll?.status == "ACTIVE"
    SectionCard("Новый опрос") {
        if (pollActive) {
            Text(
                "Сначала заверши текущий опрос.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        if (templates.isNotEmpty()) {
            Text("Недавние", style = MaterialTheme.typography.labelMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                templates.forEach { t ->
                    AssistChip(
                        onClick = {
                            title = t.title
                            options = t.options
                            seconds = t.seconds
                        },
                        label = { Text(t.title.take(28)) },
                    )
                }
            }
        }
        OutlinedTextField(
            value = title,
            onValueChange = { if (it.length <= 60) title = it },
            label = { Text("Вопрос") },
            supportingText = { Text("${title.length}/60") },
            modifier = Modifier.fillMaxWidth(),
        )
        OptionFields(options, 5, 25, "Вариант") { options = it }
        Text("Длительность", style = MaterialTheme.typography.labelMedium)
        ChipChoice(
            listOf(30 to "30 с", 60 to "1 м", 120 to "2 м", 300 to "5 м", 600 to "10 м", 1800 to "30 м")
                .map { it.second to it.first },
            seconds,
            { seconds = it },
        )
        val clean = options.map { it.trim() }.filter { it.isNotEmpty() }
        Button(
            onClick = {
                vm.createPoll(title.trim(), clean, seconds) {
                    title = ""
                    options = listOf("", "")
                }
            },
            enabled = title.isNotBlank() && clean.size >= 2 && !pollActive,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Запустить опрос") }
    }
}

private fun statusRu(s: String) = when (s) {
    "ACTIVE" -> "идёт"
    "COMPLETED" -> "завершён"
    "TERMINATED" -> "остановлен"
    "ARCHIVED" -> "удалён"
    "MODERATED" -> "скрыт"
    "LOCKED" -> "приём закрыт"
    "RESOLVED" -> "итог подведён"
    "CANCELED" -> "отменён"
    else -> s.lowercase()
}

// ---------------- ставки (прогнозы) ----------------

@Composable
private fun PredictionPanel(vm: AppViewModel) {
    val pred by vm.prediction.collectAsState()
    val templates by vm.predTemplates.collectAsState()
    var title by remember { mutableStateOf("") }
    var outcomes by remember { mutableStateOf(listOf("", "")) }
    var seconds by remember { mutableStateOf(120) }

    pred?.let { p ->
        val open = p.status == "ACTIVE" || p.status == "LOCKED"
        SectionCard(if (open) "Ставки: ${statusRu(p.status)}" else "Последние ставки (${statusRu(p.status)})") {
            Text(p.title, fontWeight = FontWeight.Bold)
            if (p.status == "ACTIVE") {
                val left by produceState(0L, p.id, p.createdAt) {
                    while (true) {
                        value = (p.createdAt + p.window * 1000L - System.currentTimeMillis()) / 1000
                        delay(1000)
                    }
                }
                Text(
                    if (left > 0) "Приём ставок: ещё ${fmtClock(left)}" else "Время приёма вышло — закрой ставки",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            val totalPts = p.outcomes.sumOf { it.points }.coerceAtLeast(1L)
            p.outcomes.forEachIndexed { i, o ->
                val winner = p.winnerId == o.id
                Row {
                    Text(
                        (if (winner) "🏆 " else "") + o.title,
                        Modifier.weight(1f),
                        fontWeight = if (winner) FontWeight.Bold else FontWeight.Normal,
                    )
                    Text("${o.users} чел · ${fmtCount(o.points)}")
                }
                ShareBar(o.points.toFloat() / totalPts, PollColors[i % PollColors.size])
            }
            if (p.status == "ACTIVE") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.patchPrediction("LOCKED", null) }, Modifier.weight(1f)) { Text("Закрыть приём") }
                    OutlinedButton(onClick = { vm.patchPrediction("CANCELED", null) }, Modifier.weight(1f)) { Text("Отменить") }
                }
            }
            if (p.status == "LOCKED") {
                Text("Кто победил?", style = MaterialTheme.typography.labelMedium)
                p.outcomes.forEach { o ->
                    FilledTonalButton(
                        onClick = { vm.patchPrediction("RESOLVED", o.id) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("🏆 ${o.title}") }
                }
                OutlinedButton(
                    onClick = { vm.patchPrediction("CANCELED", null) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                ) { Text("Отменить и вернуть баллы") }
            }
        }
    }

    val open = pred?.status == "ACTIVE" || pred?.status == "LOCKED"
    SectionCard("Новые ставки") {
        if (open) {
            Text(
                "Сначала заверши текущие ставки.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        Text(
            "Прогнозы доступны аффилиатам и партнёрам Twitch.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall,
        )
        if (templates.isNotEmpty()) {
            Text("Недавние", style = MaterialTheme.typography.labelMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                templates.forEach { t ->
                    AssistChip(
                        onClick = {
                            title = t.title
                            outcomes = t.options
                            seconds = t.seconds
                        },
                        label = { Text(t.title.take(28)) },
                    )
                }
            }
        }
        OutlinedTextField(
            value = title,
            onValueChange = { if (it.length <= 45) title = it },
            label = { Text("Вопрос") },
            supportingText = { Text("${title.length}/45") },
            modifier = Modifier.fillMaxWidth(),
        )
        OptionFields(outcomes, 10, 25, "Исход") { outcomes = it }
        Text("Время на ставки", style = MaterialTheme.typography.labelMedium)
        ChipChoice(
            listOf(60, 120, 300, 600, 900, 1800).map { fmtDur(it) to it },
            seconds,
            { seconds = it },
        )
        val clean = outcomes.map { it.trim() }.filter { it.isNotEmpty() }
        Button(
            onClick = {
                vm.createPrediction(title.trim(), clean, seconds) {
                    title = ""
                    outcomes = listOf("", "")
                }
            },
            enabled = title.isNotBlank() && clean.size >= 2 && !open,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Запустить ставки") }
    }
}
