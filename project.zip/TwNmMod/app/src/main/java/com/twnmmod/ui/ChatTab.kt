@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)

package com.twnmmod.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.decode.BitmapFactoryDecoder
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import com.twnmmod.AppViewModel
import com.twnmmod.ChatMsg
import com.twnmmod.MsgKind
import com.twnmmod.Prefs
import com.twnmmod.fmtDur
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

private val ReasonPresets = listOf("Спам", "Оскорбления", "Реклама", "Токсичность", "Спойлеры", "Флуд", "18+ контент")
private val MuteDurations = listOf(10, 60, 600, 3600, 21600, 86400, 259200, 1209600)

@Composable
fun ChatTab(vm: AppViewModel, modifier: Modifier, filter: String) {
    val chat by vm.chat.collectAsState()
    val prefs by vm.prefs.collectAsState()
    val clipBusy by vm.clipBusy.collectAsState()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var follow by remember { mutableStateOf(true) }
    var draft by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<ChatMsg?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var banTarget by remember { mutableStateOf<ChatMsg?>(null) }
    val selfLogin = vm.myLogin

    val shown = remember(chat.messages, filter) {
        if (filter.isBlank()) chat.messages
        else chat.messages.filter {
            it.display.contains(filter, true) || it.login.contains(filter, true) || it.text.contains(filter, true)
        }
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.filter { !it }.collect {
            follow = !listState.canScrollForward
        }
    }
    LaunchedEffect(shown.lastOrNull()?.id, shown.size) {
        if (follow && shown.isNotEmpty()) listState.scrollToItem(shown.lastIndex)
    }

    Column(modifier.fillMaxSize()) {
        if (!chat.connected) {
            Text(
                chat.status,
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(6.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        val s = chat.settings
        val quick = remember(prefs.quickItems) { prefs.quickItems.split(',').filter { it.isNotBlank() } }
        if (quick.isNotEmpty()) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                quick.forEach { key ->
                    when (key) {
                        "slow" -> FilterChip(
                            selected = s.slow,
                            onClick = { vm.setSlow(!s.slow, s.slowSec) },
                            label = { Text(if (s.slow) "Медленный ${s.slowSec}с" else "Медленный") },
                        )
                        "followers" -> FilterChip(
                            selected = s.followers,
                            onClick = { vm.setFollowers(!s.followers, s.followersMin) },
                            label = { Text(if (s.followers) "Фолловеры ${s.followersMin}м" else "Фолловеры") },
                        )
                        "subs" -> FilterChip(selected = s.subs, onClick = { vm.setSubs(!s.subs) }, label = { Text("Сабы") })
                        "emote" -> FilterChip(selected = s.emote, onClick = { vm.setEmote(!s.emote) }, label = { Text("Эмоуты") })
                        "unique" -> FilterChip(selected = s.unique, onClick = { vm.setUnique(!s.unique) }, label = { Text("Уникальный") })
                        "clear" -> AssistChip(
                            onClick = { confirmClear = true },
                            label = { Text("Очистить") },
                            leadingIcon = { Icon(Icons.Filled.Delete, null, Modifier.size(18.dp)) },
                        )
                        "clip" -> AssistChip(
                            onClick = { vm.createClip() },
                            enabled = !clipBusy,
                            label = { Text(if (clipBusy) "Клип…" else "Клип") },
                            leadingIcon = { Icon(Icons.Filled.ContentCut, null, Modifier.size(18.dp)) },
                        )
                        else -> {}
                    }
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                items(shown, key = { it.id }) { m ->
                    MessageRow(
                        m = m,
                        prefs = prefs,
                        canModerate = m.kind != MsgKind.SYSTEM && !m.local && !m.isBroadcaster &&
                            m.userId.isNotBlank() && !m.login.equals(selfLogin, true),
                        expanded = expandedId == m.id,
                        onTap = {
                            if (m.kind != MsgKind.SYSTEM) {
                                if (prefs.modIcons == "tap") expandedId = if (expandedId == m.id) null else m.id
                                else selected = m
                            }
                        },
                        onLong = { if (m.kind != MsgKind.SYSTEM) selected = m },
                        onBan = { if (prefs.confirmBan) banTarget = m else vm.banUser(m.userId, m.login, "") },
                        onMute = { vm.timeoutUser(m.userId, m.login, prefs.timeoutSec, "") },
                        onWarn = { vm.warnUser(m.userId, m.login, "") },
                        onDelete = { vm.deleteMessage(m) },
                        onMore = { selected = m },
                    )
                }
            }
            if (!follow && shown.isNotEmpty()) {
                FilledTonalButton(
                    onClick = {
                        follow = true
                        scope.launch { listState.scrollToItem(shown.lastIndex) }
                    },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
                ) {
                    Icon(Icons.Filled.KeyboardArrowDown, null)
                    Text("К новым сообщениям")
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { if (it.length <= 500) draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Сообщение или /команда") },
                maxLines = 3,
                shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    vm.sendChat(draft)
                    draft = ""
                }),
            )
            FilledIconButton(
                onClick = {
                    vm.sendChat(draft)
                    draft = ""
                },
                enabled = draft.isNotBlank(),
            ) { Icon(Icons.AutoMirrored.Filled.Send, "Отправить") }
        }
    }

    selected?.let { m ->
        val history = remember(chat.messages, m.userId) {
            chat.messages.filter { it.userId == m.userId && it.kind != MsgKind.SYSTEM }.takeLast(15).reversed()
        }
        UserSheet(
            m = m,
            vm = vm,
            history = history,
            onMention = { draft = (draft + " @$it ").trimStart() },
            onDismiss = { selected = null },
        )
    }

    banTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { banTarget = null },
            title = { Text("Забанить @${t.login}?") },
            text = { Text("Бан навсегда. Снять можно в карточке пользователя или в журнале.") },
            confirmButton = {
                TextButton(onClick = {
                    banTarget = null
                    vm.banUser(t.userId, t.login, "")
                }) { Text("Забанить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { banTarget = null }) { Text("Отмена") } },
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Очистить чат?") },
            text = { Text("Все сообщения будут удалены у всех зрителей.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    vm.clearChat()
                }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } },
        )
    }
}

// ---------------- строка сообщения ----------------

private fun badgeContent(icon: ImageVector, tint: Color, sizeSp: Float) = InlineTextContent(
    Placeholder(sizeSp.sp, sizeSp.sp, PlaceholderVerticalAlign.TextCenter)
) { Icon(icon, null, Modifier.fillMaxSize(), tint = tint) }

private fun twitchEmoteUrl(id: String) = "https://static-cdn.jtvnw.net/emoticons/v2/$id/default/dark/2.0"

private fun emoteContent(url: String, sizeSp: Float, animated: Boolean) = InlineTextContent(
    Placeholder(sizeSp.sp, sizeSp.sp, PlaceholderVerticalAlign.TextCenter)
) {
    val ctx = LocalContext.current
    val request = remember(url, animated) {
        ImageRequest.Builder(ctx).data(url).apply {
            if (!animated) decoderFactory(BitmapFactoryDecoder.Factory())
        }.build()
    }
    AsyncImage(
        model = request,
        contentDescription = it,
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Fit,
    )
}

private fun inlineMap(m: ChatMsg, textSize: Float, animated: Boolean): Map<String, InlineTextContent> {
    val map = HashMap<String, InlineTextContent>()
    val badge = textSize * 1.1f
    val emote = textSize * 1.7f
    if (m.isBroadcaster) map["b_bc"] = badgeContent(Icons.Filled.Videocam, Color(0xFFE91916), badge)
    if (m.isMod) map["b_mod"] = badgeContent(Icons.Filled.Security, Color(0xFF00C853), badge)
    if (m.isVip) map["b_vip"] = badgeContent(Icons.Filled.Stars, Color(0xFFE005B9), badge)
    if (m.isSub) map["b_sub"] = badgeContent(Icons.Filled.Star, Color(0xFFB388FF), badge)
    m.emotes.forEach { e -> map["e_${e.id}"] = emoteContent(e.url ?: twitchEmoteUrl(e.id), emote, animated) }
    return map
}

private fun buildMsg(m: ChatMsg, showTime: Boolean, showBadges: Boolean): AnnotatedString = buildAnnotatedString {
    if (showTime) {
        withStyle(SpanStyle(color = Color(0xFF7A7A85), fontSize = 0.8.em)) {
            append(timeFmt.format(Date(m.time)))
            append(" ")
        }
    }
    if (m.firstMsg) {
        withStyle(SpanStyle(background = Color(0x55FFC400), fontWeight = FontWeight.Bold, fontSize = 0.75.em)) {
            append(" NEW ")
        }
        append(" ")
    }
    if (showBadges && m.isBroadcaster) { appendInlineContent("b_bc", "[B]"); append(" ") }
    if (showBadges && m.isMod) { appendInlineContent("b_mod", "[M]"); append(" ") }
    if (showBadges && m.isVip) { appendInlineContent("b_vip", "[V]"); append(" ") }
    if (showBadges && m.isSub) { appendInlineContent("b_sub", "[S]"); append(" ") }

    val nameColor = Color(m.color ?: 0xFFFFFFFF)
    withStyle(SpanStyle(color = nameColor, fontWeight = FontWeight.Bold)) { append(m.display) }
    append(if (m.kind == MsgKind.ACTION) " " else ": ")

    val bodyStyle = SpanStyle(
        color = if (m.kind == MsgKind.ACTION) nameColor else Color.Unspecified,
        textDecoration = if (m.deleted) TextDecoration.LineThrough else null,
    )
    withStyle(bodyStyle) {
        var i = 0
        for (e in m.emotes) {
            if (e.start < i || e.end > m.text.length || e.start >= e.end) continue
            append(m.text.substring(i, e.start))
            appendInlineContent("e_${e.id}", m.text.substring(e.start, e.end))
            i = e.end
        }
        append(m.text.substring(i))
    }
}

@Composable
private fun ModIcon(icon: ImageVector, desc: String, tint: Color, box: Dp, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.size(box).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, Modifier.size(box * 0.56f), tint = if (enabled) tint else tint.copy(alpha = 0.3f))
    }
}

@Composable
private fun ModIconBar(
    m: ChatMsg,
    box: Dp,
    onBan: () -> Unit,
    onMute: () -> Unit,
    onWarn: () -> Unit,
    onDelete: () -> Unit,
    onMore: (() -> Unit)? = null,
) {
    Row {
        ModIcon(Icons.Filled.Gavel, "Бан", Color(0xFFFF6B6B), box, onClick = onBan)
        ModIcon(Icons.Filled.Timer, "Мут", Color(0xFFFFB347), box, onClick = onMute)
        ModIcon(Icons.Filled.Warning, "Предупреждение", Color(0xFFFFD54F), box, onClick = onWarn)
        ModIcon(Icons.Filled.Delete, "Удалить сообщение", Color(0xFFC4C4CC), box, enabled = !m.deleted, onClick = onDelete)
        if (onMore != null) ModIcon(Icons.Filled.MoreHoriz, "Ещё", Color(0xFFC4C4CC), box, onClick = onMore)
    }
}

@Composable
private fun MessageRow(
    m: ChatMsg,
    prefs: Prefs,
    canModerate: Boolean,
    expanded: Boolean,
    onTap: () -> Unit,
    onLong: () -> Unit,
    onBan: () -> Unit,
    onMute: () -> Unit,
    onWarn: () -> Unit,
    onDelete: () -> Unit,
    onMore: () -> Unit,
) {
    val bg = MaterialTheme.colorScheme.background
    if (m.kind == MsgKind.SYSTEM) {
        Text(
            m.text,
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontStyle = FontStyle.Italic,
        )
        return
    }
    val text = remember(m, prefs.showTime, prefs.showBadges) { buildMsg(m, prefs.showTime, prefs.showBadges) }
    val inline = remember(m.id, m.emotes, m.isMod, m.isSub, m.isVip, m.isBroadcaster, prefs.textSize, prefs.animEmotes) {
        inlineMap(m, prefs.textSize, prefs.animEmotes)
    }
    val rowBg = if (m.mention) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f).compositeOver(bg) else bg
    val box = when (prefs.iconSize) {
        "small" -> 30.dp
        "large" -> 42.dp
        else -> 34.dp
    }
    val vPad = when (prefs.density) {
        "compact" -> 0.dp
        "roomy" -> 7.dp
        else -> 3.dp
    }
    val side = canModerate && prefs.modIcons == "always"
    val left = prefs.iconSide == "left"
    val below = canModerate && prefs.modIcons == "tap" && expanded

    Column(
        Modifier
            .fillMaxWidth()
            .background(rowBg)
            .combinedClickable(onClick = onTap, onLongClick = onLong)
            .padding(
                start = if (side && left) 2.dp else 10.dp,
                end = if (side && !left) 2.dp else 10.dp,
                top = 3.dp,
                bottom = 3.dp,
            )
    ) {
        Row(verticalAlignment = Alignment.Top) {
            if (side && left) ModIconBar(m, box, onBan, onMute, onWarn, onDelete)
            Column(Modifier.weight(1f).padding(vertical = vPad).alpha(if (m.deleted) 0.5f else 1f)) {
                m.replyTo?.let {
                    Text(
                        "↪ $it",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(text, inlineContent = inline, fontSize = prefs.textSize.sp)
                val tag = when {
                    m.punished != null -> "⛔ ${m.punished}"
                    m.deleted -> "сообщение удалено"
                    else -> null
                }
                if (tag != null) {
                    Text(tag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                }
            }
            if (side && !left) ModIconBar(m, box, onBan, onMute, onWarn, onDelete)
        }
        if (below) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                ModIconBar(m, box, onBan, onMute, onWarn, onDelete, onMore)
            }
        }
    }
}

// ---------------- действия над пользователем ----------------

@Composable
private fun UserSheet(
    m: ChatMsg,
    vm: AppViewModel,
    history: List<ChatMsg>,
    onMention: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val clipboard = LocalClipboardManager.current
    var reason by remember { mutableStateOf("") }
    var customVal by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf(60) }
    var showHistory by remember { mutableStateOf(false) }
    var confirmBan by remember { mutableStateOf(false) }
    val locked = m.isBroadcaster

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    m.display,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(m.color ?: 0xFFFFFFFF),
                )
                Text("@${m.login}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val roles = listOfNotNull(
                if (m.isBroadcaster) "стример" else null,
                if (m.isMod) "модератор" else null,
                if (m.isVip) "VIP" else null,
                if (m.isSub) "сабскрайбер" else null,
                if (m.firstMsg) "первое сообщение" else null,
            )
            if (roles.isNotEmpty()) {
                Text(roles.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Text(m.text, Modifier.padding(12.dp).fillMaxWidth())
            }

            OutlinedTextField(
                value = reason,
                onValueChange = { if (it.length <= 200) reason = it },
                label = { Text("Причина (необязательно)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReasonPresets.forEach { r -> AssistChip(onClick = { reason = r }, label = { Text(r) }) }
            }

            Text("Мут", fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MuteDurations.forEach { sec ->
                    FilledTonalButton(
                        onClick = {
                            vm.timeoutUser(m.userId, m.login, sec, reason.trim())
                            onDismiss()
                        },
                        enabled = !locked,
                    ) { Text(fmtDur(sec)) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = customVal,
                    onValueChange = { v -> if (v.length <= 6 && v.all { it.isDigit() }) customVal = v },
                    label = { Text("Своё") },
                    modifier = Modifier.width(100.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                ChipChoice(
                    options = listOf("с" to 1, "м" to 60, "ч" to 3600, "д" to 86400),
                    selected = unit,
                    onSelect = { unit = it },
                    modifier = Modifier.weight(1f),
                )
            }
            val customSec = (customVal.toLongOrNull() ?: 0L) * unit
            Button(
                onClick = {
                    vm.timeoutUser(m.userId, m.login, customSec.coerceIn(1L, 1_209_600L).toInt(), reason.trim())
                    onDismiss()
                },
                enabled = !locked && customSec > 0,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Мут на своё время") }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilledTonalButton(
                    onClick = {
                        vm.warnUser(m.userId, m.login, reason.trim())
                        onDismiss()
                    },
                    enabled = !locked,
                    modifier = Modifier.weight(1f),
                ) { Text("Предупредить") }
                FilledTonalButton(
                    onClick = {
                        vm.deleteMessage(m)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Удалить") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { confirmBan = true },
                    enabled = !locked,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError,
                    ),
                    modifier = Modifier.weight(1f),
                ) { Text("Бан") }
                OutlinedButton(
                    onClick = {
                        vm.unbanUser(m.userId, m.login)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Снять бан/мут") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    onMention(m.login)
                    onDismiss()
                }) { Text("Ответить @") }
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(m.text))
                    onDismiss()
                }) { Text("Копировать текст") }
                TextButton(onClick = { showHistory = !showHistory }) {
                    Text(if (showHistory) "Скрыть историю" else "История (${history.size})")
                }
            }
            if (showHistory) {
                history.forEach { h ->
                    Text(
                        "${timeFmt.format(Date(h.time))}  ${h.text}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.size(4.dp))
        }
    }

    if (confirmBan) {
        AlertDialog(
            onDismissRequest = { confirmBan = false },
            title = { Text("Забанить @${m.login}?") },
            text = { Text("Бан навсегда. Снять его можно кнопкой «Снять бан/мут» или в журнале.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmBan = false
                    vm.banUser(m.userId, m.login, reason.trim())
                    onDismiss()
                }) { Text("Забанить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmBan = false }) { Text("Отмена") } },
        )
    }
}
