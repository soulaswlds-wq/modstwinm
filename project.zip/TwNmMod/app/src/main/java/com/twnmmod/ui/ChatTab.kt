@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.twnmmod.AppViewModel
import com.twnmmod.ChatMsg
import com.twnmmod.MsgKind
import com.twnmmod.Prefs
import com.twnmmod.fmtDur
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

private val ReasonPresets = listOf("Спам", "Оскорбления", "Реклама", "Токсичность", "Спойлеры", "Флуд", "18+ контент")
private val MuteDurations = listOf(10, 60, 600, 3600, 21600, 86400, 259200, 1209600)

@Composable
fun ChatTab(vm: AppViewModel, modifier: Modifier, filter: String) {
    val chat by vm.chat.collectAsState()
    val prefs by vm.prefs.collectAsState()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var follow by remember { mutableStateOf(true) }
    var draft by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<ChatMsg?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    val selfLogin = vm.myLogin

    val shown = remember(chat.messages, filter) {
        if (filter.isBlank()) chat.messages
        else chat.messages.filter {
            it.display.contains(filter, true) || it.login.contains(filter, true) || it.text.contains(filter, true)
        }
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.filter { !it }.collect {
            follow = !listState.canScrollForward
        }
    }
    LaunchedEffect(shown.lastOrNull()?.id, shown.size) {
        if (follow && shown.isNotEmpty()) listState.scrollToItem(shown.lastIndex)
    }

    fun action(kind: String, m: ChatMsg): (() -> Unit)? = when (kind) {
        "delete" -> ({ vm.deleteMessage(m) })
        "timeout" -> ({ vm.timeoutUser(m.userId, m.login, prefs.timeoutSec, "") })
        "warn" -> ({ vm.warnUser(m.userId, m.login, "") })
        else -> null
    }

    fun iconFor(kind: String): ImageVector? = when (kind) {
        "delete" -> Icons.Filled.Delete
        "timeout" -> Icons.Filled.Timer
        "warn" -> Icons.Filled.Warning
        else -> null
    }

    fun colorFor(kind: String): Color = when (kind) {
        "delete" -> Color(0xFFB3261E)
        "timeout" -> Color(0xFFC77700)
        else -> Color(0xFF9A7B00)
    }

    Column(modifier.fillMaxSize()) {
        if (!chat.connected) {
            Text(
                chat.status,
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(6.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        val s = chat.settings
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = s.slow,
                onClick = { vm.setSlow(!s.slow, s.slowSec) },
                label = { Text(if (s.slow) "Медленный ${s.slowSec}с" else "Медленный") },
            )
            FilterChip(
                selected = s.followers,
                onClick = { vm.setFollowers(!s.followers, s.followersMin) },
                label = { Text(if (s.followers) "Фолловеры ${s.followersMin}м" else "Фолловеры") },
            )
            FilterChip(selected = s.subs, onClick = { vm.setSubs(!s.subs) }, label = { Text("Сабы") })
            FilterChip(selected = s.emote, onClick = { vm.setEmote(!s.emote) }, label = { Text("Эмоуты") })
            AssistChip(
                onClick = { confirmClear = true },
                label = { Text("Очистить") },
                leadingIcon = { Icon(Icons.Filled.Delete, null, Modifier.size(18.dp)) },
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                items(shown, key = { it.id }) { m ->
                    MessageRow(
                        m = m,
                        prefs = prefs,
                        swipeable = m.kind != MsgKind.SYSTEM && !m.local && !m.isBroadcaster &&
                            m.userId.isNotBlank() && !m.login.equals(selfLogin, true),
                        onOpen = { if (m.kind != MsgKind.SYSTEM) selected = m },
                        rightIcon = iconFor(prefs.swipeRight),
                        rightColor = colorFor(prefs.swipeRight),
                        onRight = action(prefs.swipeRight, m),
                        leftIcon = iconFor(prefs.swipeLeft),
                        leftColor = colorFor(prefs.swipeLeft),
                        onLeft = action(prefs.swipeLeft, m),
                    )
                }
            }
            if (!follow && shown.isNotEmpty()) {
                FilledTonalButton(
                    onClick = {
                        follow = true
                        scope.launch { listState.scrollToItem(shown.lastIndex) }
                    },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
                ) {
                    Icon(Icons.Filled.KeyboardArrowDown, null)
                    Text("К новым сообщениям")
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { if (it.length <= 500) draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Сообщение или /команда") },
                maxLines = 3,
                shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    vm.sendChat(draft)
                    draft = ""
                }),
            )
            FilledIconButton(
                onClick = {
                    vm.sendChat(draft)
                    draft = ""
                },
                enabled = draft.isNotBlank(),
            ) { Icon(Icons.AutoMirrored.Filled.Send, "Отправить") }
        }
    }

    selected?.let { m ->
        val history = remember(chat.messages, m.userId) {
            chat.messages.filter { it.userId == m.userId && it.kind != MsgKind.SYSTEM }.takeLast(15).reversed()
        }
        UserSheet(
            m = m,
            vm = vm,
            history = history,
            onMention = { draft = (draft + " @$it ").trimStart() },
            onDismiss = { selected = null },
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Очистить чат?") },
            text = { Text("Все сообщения будут удалены у всех зрителей.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    vm.clearChat()
                }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } },
        )
    }
}

// ---------------- строка сообщения ----------------

@Composable
private fun SwipeRow(
    rightIcon: ImageVector?,
    rightColor: Color,
    onRight: (() -> Unit)?,
    leftIcon: ImageVector?,
    leftColor: Color,
    onLeft: (() -> Unit)?,
    content: @Composable () -> Unit,
) {
    val offset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var width by remember { mutableStateOf(1) }
    val widthState = rememberUpdatedState(width)
    val rightState = rememberUpdatedState(onRight)
    val leftState = rememberUpdatedState(onLeft)

    Box(Modifier.fillMaxWidth().onSizeChanged { width = it.width }.clipToBounds()) {
        val o = offset.value
        if (o != 0f) {
            val right = o > 0f
            Box(
                Modifier.matchParentSize().background(if (right) rightColor else leftColor).padding(horizontal = 20.dp),
                contentAlignment = if (right) Alignment.CenterStart else Alignment.CenterEnd,
            ) {
                val ic = if (right) rightIcon else leftIcon
                if (ic != null) Icon(ic, null, tint = Color.White)
            }
        }
        Box(
            Modifier
                .offset { IntOffset(offset.value.roundToInt(), 0) }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            scope.launch {
                                val cur = offset.value
                                val th = widthState.value * 0.28f
                                val r = rightState.value
                                val l = leftState.value
                                if (cur > th && r != null) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    r()
                                } else if (cur < -th && l != null) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    l()
                                }
                                offset.animateTo(0f)
                            }
                        },
                        onDragCancel = { scope.launch { offset.animateTo(0f) } },
                        onHorizontalDrag = { change, dx ->
                            change.consume()
                            val n = offset.value + dx
                            val allowed = (n > 0f && rightState.value != null) || (n < 0f && leftState.value != null)
                            val lim = widthState.value * 0.45f
                            scope.launch { offset.snapTo(if (allowed) n.coerceIn(-lim, lim) else 0f) }
                        },
                    )
                }
        ) { content() }
    }
}

private fun badgeContent(icon: ImageVector, tint: Color, sizeSp: Float) = InlineTextContent(
    Placeholder(sizeSp.sp, sizeSp.sp, PlaceholderVerticalAlign.TextCenter)
) { Icon(icon, null, Modifier.fillMaxSize(), tint = tint) }

private fun emoteContent(id: String, sizeSp: Float) = InlineTextContent(
    Placeholder(sizeSp.sp, sizeSp.sp, PlaceholderVerticalAlign.TextCenter)
) {
    AsyncImage(
        model = "https://static-cdn.jtvnw.net/emoticons/v2/$id/default/dark/2.0",
        contentDescription = it,
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Fit,
    )
}

private fun inlineMap(m: ChatMsg, textSize: Float): Map<String, InlineTextContent> {
    val map = HashMap<String, InlineTextContent>()
    val badge = textSize * 1.1f
    val emote = textSize * 1.7f
    if (m.isBroadcaster) map["b_bc"] = badgeContent(Icons.Filled.Videocam, Color(0xFFE91916), badge)
    if (m.isMod) map["b_mod"] = badgeContent(Icons.Filled.Security, Color(0xFF00C853), badge)
    if (m.isVip) map["b_vip"] = badgeContent(Icons.Filled.Stars, Color(0xFFE005B9), badge)
    if (m.isSub) map["b_sub"] = badgeContent(Icons.Filled.Star, Color(0xFFB388FF), badge)
    m.emotes.forEach { e -> map["e_${e.id}"] = emoteContent(e.id, emote) }
    return map
}

private fun buildMsg(m: ChatMsg, showTime: Boolean): AnnotatedString = buildAnnotatedString {
    if (showTime) {
        withStyle(SpanStyle(color = Color(0xFF7A7A85), fontSize = 0.8.em)) {
            append(timeFmt.format(Date(m.time)))
            append(" ")
        }
    }
    if (m.firstMsg) {
        withStyle(SpanStyle(background = Color(0x55FFC400), fontWeight = FontWeight.Bold, fontSize = 0.75.em)) {
            append(" NEW ")
        }
        append(" ")
    }
    if (m.isBroadcaster) { appendInlineContent("b_bc", "[B]"); append(" ") }
    if (m.isMod) { appendInlineContent("b_mod", "[M]"); append(" ") }
    if (m.isVip) { appendInlineContent("b_vip", "[V]"); append(" ") }
    if (m.isSub) { appendInlineContent("b_sub", "[S]"); append(" ") }

    val nameColor = Color(m.color ?: 0xFFFFFFFF)
    withStyle(SpanStyle(color = nameColor, fontWeight = FontWeight.Bold)) { append(m.display) }
    append(if (m.kind == MsgKind.ACTION) " " else ": ")

    val bodyStyle = SpanStyle(
        color = if (m.kind == MsgKind.ACTION) nameColor else Color.Unspecified,
        textDecoration = if (m.deleted) TextDecoration.LineThrough else null,
    )
    withStyle(bodyStyle) {
        var i = 0
        for (e in m.emotes) {
            if (e.start < i || e.end > m.text.length || e.start >= e.end) continue
            append(m.text.substring(i, e.start))
            appendInlineContent("e_${e.id}", m.text.substring(e.start, e.end))
            i = e.end
        }
        append(m.text.substring(i))
    }
}

@Composable
private fun MessageRow(
    m: ChatMsg,
    prefs: Prefs,
    swipeable: Boolean,
    onOpen: () -> Unit,
    rightIcon: ImageVector?,
    rightColor: Color,
    onRight: (() -> Unit)?,
    leftIcon: ImageVector?,
    leftColor: Color,
    onLeft: (() -> Unit)?,
) {
    val bg = MaterialTheme.colorScheme.background
    if (m.kind == MsgKind.SYSTEM) {
        Text(
            m.text,
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontStyle = FontStyle.Italic,
        )
        return
    }
    val text = remember(m, prefs.showTime) { buildMsg(m, prefs.showTime) }
    val inline = remember(m.id, m.emotes, m.isMod, m.isSub, m.isVip, m.isBroadcaster, prefs.textSize) {
        inlineMap(m, prefs.textSize)
    }
    val rowBg = if (m.mention) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f).compositeOver(bg) else bg

    val body: @Composable () -> Unit = {
        Column(
            Modifier
                .fillMaxWidth()
                .background(rowBg)
                .clickable { onOpen() }
                .padding(horizontal = 10.dp, vertical = 5.dp)
                .alpha(if (m.deleted) 0.5f else 1f)
        ) {
            m.replyTo?.let {
                Text(
                    "↪ $it",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(text, inlineContent = inline, fontSize = prefs.textSize.sp)
            val tag = when {
                m.punished != null -> "⛔ ${m.punished}"
                m.deleted -> "сообщение удалено"
                else -> null
            }
            if (tag != null) {
                Text(tag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (swipeable && (onRight != null || onLeft != null)) {
        SwipeRow(rightIcon, rightColor, onRight, leftIcon, leftColor, onLeft, body)
    } else {
        body()
    }
}

// ---------------- действия над пользователем ----------------

@Composable
private fun UserSheet(
    m: ChatMsg,
    vm: AppViewModel,
    history: List<ChatMsg>,
    onMention: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val clipboard = LocalClipboardManager.current
    var reason by remember { mutableStateOf("") }
    var customVal by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf(60) }
    var showHistory by remember { mutableStateOf(false) }
    var confirmBan by remember { mutableStateOf(false) }
    val locked = m.isBroadcaster

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    m.display,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(m.color ?: 0xFFFFFFFF),
                )
                Text("@${m.login}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val roles = listOfNotNull(
                if (m.isBroadcaster) "стример" else null,
                if (m.isMod) "модератор" else null,
                if (m.isVip) "VIP" else null,
                if (m.isSub) "сабскрайбер" else null,
                if (m.firstMsg) "первое сообщение" else null,
            )
            if (roles.isNotEmpty()) {
                Text(roles.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Text(m.text, Modifier.padding(12.dp).fillMaxWidth())
            }

            OutlinedTextField(
                value = reason,
                onValueChange = { if (it.length <= 200) reason = it },
                label = { Text("Причина (необязательно)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReasonPresets.forEach { r -> AssistChip(onClick = { reason = r }, label = { Text(r) }) }
            }

            Text("Мут", fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MuteDurations.forEach { sec ->
                    FilledTonalButton(
                        onClick = {
                            vm.timeoutUser(m.userId, m.login, sec, reason.trim())
                            onDismiss()
                        },
                        enabled = !locked,
                    ) { Text(fmtDur(sec)) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = customVal,
                    onValueChange = { v -> if (v.length <= 6 && v.all { it.isDigit() }) customVal = v },
                    label = { Text("Своё") },
                    modifier = Modifier.width(100.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                ChipChoice(
                    options = listOf("с" to 1, "м" to 60, "ч" to 3600, "д" to 86400),
                    selected = unit,
                    onSelect = { unit = it },
                    modifier = Modifier.weight(1f),
                )
            }
            val customSec = (customVal.toLongOrNull() ?: 0L) * unit
            Button(
                onClick = {
                    vm.timeoutUser(m.userId, m.login, customSec.coerceIn(1L, 1_209_600L).toInt(), reason.trim())
                    onDismiss()
                },
                enabled = !locked && customSec > 0,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Мут на своё время") }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilledTonalButton(
                    onClick = {
                        vm.warnUser(m.userId, m.login, reason.trim())
                        onDismiss()
                    },
                    enabled = !locked,
                    modifier = Modifier.weight(1f),
                ) { Text("Предупредить") }
                FilledTonalButton(
                    onClick = {
                        vm.deleteMessage(m)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Удалить") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { confirmBan = true },
                    enabled = !locked,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError,
                    ),
                    modifier = Modifier.weight(1f),
                ) { Text("Бан") }
                OutlinedButton(
                    onClick = {
                        vm.unbanUser(m.userId, m.login)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Снять бан/мут") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    onMention(m.login)
                    onDismiss()
                }) { Text("Ответить @") }
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(m.text))
                    onDismiss()
                }) { Text("Копировать текст") }
                TextButton(onClick = { showHistory = !showHistory }) {
                    Text(if (showHistory) "Скрыть историю" else "История (${history.size})")
                }
            }
            if (showHistory) {
                history.forEach { h ->
                    Text(
                        "${timeFmt.format(Date(h.time))}  ${h.text}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.size(4.dp))
        }
    }

    if (confirmBan) {
        AlertDialog(
            onDismissRequest = { confirmBan = false },
            title = { Text("Забанить @${m.login}?") },
            text = { Text("Бан навсегда. Снять его можно кнопкой «Снять бан/мут» или в журнале.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmBan = false
                    vm.banUser(m.userId, m.login, reason.trim())
                    onDismiss()
                }) { Text("Забанить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmBan = false }) { Text("Отмена") } },
        )
    }
}
