@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)

package com.twnmmod.ui

import android.content.res.Configuration
import android.webkit.WebView
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import com.twnmmod.NickStyle
import com.twnmmod.StyleRule
import com.twnmmod.styleFor
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Surface
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.foundation.layout.height
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.decode.BitmapFactoryDecoder
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import com.twnmmod.AppViewModel
import com.twnmmod.Category
import com.twnmmod.ChatMsg
import com.twnmmod.HeldMsg
import com.twnmmod.MsgKind
import com.twnmmod.Prefs
import com.twnmmod.UserInfo
import com.twnmmod.fmtAge
import com.twnmmod.fmtDur
import androidx.compose.foundation.layout.heightIn
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private fun markOn(on: Boolean, t: String) = if (on) "✓ $t" else t

private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

private val ReasonPresets = listOf("Спам", "Оскорбления", "Реклама", "Токсичность", "Спойлеры", "Флуд", "18+ контент")
private val MuteDurations = listOf(10, 60, 600, 3600, 21600, 86400, 259200, 1209600)

@Composable
fun ChatTab(vm: AppViewModel, modifier: Modifier, filter: String, player: Lazy<WebView?>, onToggleSearch: () -> Unit) {
    val chat by vm.chat.collectAsState()
    val prefs by vm.prefs.collectAsState()
    val clipBusy by vm.clipBusy.collectAsState()
    val held by vm.held.collectAsState()
    val shield by vm.shield.collectAsState()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var follow by remember { mutableStateOf(true) }
    var draft by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<ChatMsg?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var banTarget by remember { mutableStateOf<ChatMsg?>(null) }
    var heldBan by remember { mutableStateOf<HeldMsg?>(null) }
    var replyTo by remember { mutableStateOf<ChatMsg?>(null) }
    var phrasesOpen by remember { mutableStateOf(false) }
    var emoteOpen by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    val picker by vm.picker.collectAsState()
    val lastSent by vm.lastSent.collectAsState()
    val focus = LocalFocusManager.current
    val phrases by vm.phrases.collectAsState()
    val rules by vm.styleRules.collectAsState()
    val tempo by vm.tempo.collectAsState()
    val pendingMention by vm.pendingMention.collectAsState()
    val selfLogin = vm.myLogin

    val shown = remember(chat.messages, filter) {
        if (filter.isBlank()) chat.messages
        else chat.messages.filter {
            it.display.contains(filter, true) || it.login.contains(filter, true) || it.text.contains(filter, true) ||
                (it.eventTitle?.contains(filter, true) == true)
        }
    }

    LaunchedEffect(pendingMention) {
        pendingMention?.let {
            draft = (draft + " @$it ").trimStart()
            vm.consumeMention()
        }
    }

    val catCmd = prefs.categoryCmd.trim().ifEmpty { "!g" }
    val catQuery: String? =
        if (draft.startsWith("$catCmd ", ignoreCase = true)) draft.substring(catCmd.length + 1).trimStart() else null
    var catResults by remember { mutableStateOf<List<Category>>(emptyList()) }
    LaunchedEffect(catQuery) {
        if (catQuery == null) {
            catResults = emptyList()
        } else {
            if (catQuery.isNotEmpty()) delay(200)
            catResults = vm.suggestCategories(catQuery)
        }
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.filter { !it }.collect {
            follow = !listState.canScrollForward
        }
    }
    LaunchedEffect(shown.lastOrNull()?.id, shown.size) {
        if (follow && shown.isNotEmpty()) listState.scrollToItem(shown.lastIndex)
    }

    val current by vm.current.collectAsState()
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val imeOn = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    LaunchedEffect(imeOn) { if (imeOn) emoteOpen = false }
    val live = chat.stream?.live
    val web: WebView? = if (prefs.showPlayer && live != false) player.value else null
    val channelLogin = current?.login.orEmpty()
    LaunchedEffect(web, channelLogin, prefs.playerMuted) {
        if (web != null && channelLogin.isNotBlank()) {
            val key = "$channelLogin|${prefs.playerMuted}"
            if (web.tag != key) {
                web.tag = key
                loadPlayer(web, channelLogin, prefs.playerMuted)
            }
        }
    }

    PlayerLayout(modifier, web, landscape, imeOn && !landscape) {
        if (!chat.connected) {
            Text(
                chat.status,
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(6.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (prefs.showTempo) TempoStrip(tempo, MaterialTheme.colorScheme.primary)

        val s = chat.settings
        val quick = remember(prefs.quickItems) { prefs.quickItems.split(',').filter { it.isNotBlank() } }
        if (quick.isNotEmpty()) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                quick.forEach { key ->
                    when (key) {
                        "slow" -> FilterChip(
                            selected = s.slow,
                            onClick = { vm.setSlow(!s.slow, s.slowSec) },
                            label = { Text(if (s.slow) "Медленный ${s.slowSec}с" else "Медленный") },
                        )
                        "followers" -> FilterChip(
                            selected = s.followers,
                            onClick = { vm.setFollowers(!s.followers, s.followersMin) },
                            label = { Text(if (s.followers) "Фолловеры ${s.followersMin}м" else "Фолловеры") },
                        )
                        "subs" -> FilterChip(selected = s.subs, onClick = { vm.setSubs(!s.subs) }, label = { Text("Сабы") })
                        "emote" -> FilterChip(selected = s.emote, onClick = { vm.setEmote(!s.emote) }, label = { Text("Эмоуты") })
                        "unique" -> FilterChip(selected = s.unique, onClick = { vm.setUnique(!s.unique) }, label = { Text("Уникальный") })
                        "shield" -> FilterChip(
                            selected = shield,
                            onClick = { vm.setShield(!shield) },
                            label = { Text("Щит") },
                        )
                        "clear" -> AssistChip(
                            onClick = { confirmClear = true },
                            label = { Text("Очистить") },
                            leadingIcon = { Icon(Icons.Filled.Delete, null, Modifier.size(18.dp)) },
                        )
                        "clip" -> AssistChip(
                            onClick = { vm.createClip() },
                            enabled = !clipBusy,
                            label = { Text(if (clipBusy) "Клип…" else "Клип") },
                            leadingIcon = { Icon(Icons.Filled.ContentCut, null, Modifier.size(18.dp)) },
                        )
                        else -> {}
                    }
                }
            }
        }

        if (held.isNotEmpty()) {
            val h = held.first()
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
            ) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "AutoMod: ждёт решения (${held.size})",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                    Text("${h.display}: ${h.text}", color = MaterialTheme.colorScheme.onErrorContainer)
                    Text(
                        h.reason,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.resolveHeld(h, true) }, modifier = Modifier.weight(1f)) { Text("Разрешить") }
                        OutlinedButton(onClick = { vm.resolveHeld(h, false) }, modifier = Modifier.weight(1f)) { Text("Отклонить") }
                    }
                    Text(
                        "Отклонить и наказать:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { vm.punishHeld(h, "timeout", prefs.timeoutSec) },
                            modifier = Modifier.weight(1f),
                        ) { Text("Мут ${fmtDur(prefs.timeoutSec)}") }
                        FilledTonalButton(
                            onClick = { vm.punishHeld(h, "warn") },
                            modifier = Modifier.weight(1f),
                        ) { Text("Пред.") }
                        Button(
                            onClick = {
                                if (prefs.confirmBan) heldBan = h else vm.punishHeld(h, "ban")
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error,
                                contentColor = MaterialTheme.colorScheme.onError,
                            ),
                            modifier = Modifier.weight(1f),
                        ) { Text("Бан") }
                    }
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                items(shown, key = { it.id }) { m ->
                    MessageRow(
                        m = m,
                        prefs = prefs,
                        rules = rules,
                        canModerate = m.kind != MsgKind.SYSTEM && !m.local && !m.isBroadcaster &&
                            m.userId.isNotBlank() && !m.login.equals(selfLogin, true),
                        expanded = expandedId == m.id,
                        onTap = {
                            if (m.kind != MsgKind.SYSTEM) {
                                if (prefs.modIcons == "tap") expandedId = if (expandedId == m.id) null else m.id
                                else selected = m
                            }
                        },
                        onLong = { if (m.kind != MsgKind.SYSTEM) selected = m },
                        onBan = { if (prefs.confirmBan) banTarget = m else vm.banUser(m.userId, m.login, "") },
                        onMute = { vm.timeoutUser(m.userId, m.login, prefs.timeoutSec, "") },
                        onWarn = { vm.warnUser(m.userId, m.login, "") },
                        onDelete = { vm.deleteMessage(m) },
                        onMore = { selected = m },
                        canReply = canReplyTo(m),
                        onReply = { replyTo = m },
                    )
                }
            }
            if (!follow && shown.isNotEmpty()) {
                FilledTonalButton(
                    onClick = {
                        follow = true
                        scope.launch { listState.scrollToItem(shown.lastIndex) }
                    },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
                ) {
                    Icon(Icons.Filled.KeyboardArrowDown, null)
                    Text("К новым сообщениям")
                }
            }
        }

        if (catQuery != null) {
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
                    Text(
                        if (catQuery.isEmpty()) "Недавние и популярные категории" else "Категории для $catCmd",
                        Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (catResults.isEmpty()) {
                        Text(
                            "Ничего не найдено",
                            Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    catResults.forEach { c ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                draft = "$catCmd ${c.name}"
                                vm.rememberCategory(c)
                                if (prefs.catAutoSend) {
                                    vm.sendChat(draft, null)
                                    draft = ""
                                }
                            }.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AsyncImage(
                                model = c.art,
                                contentDescription = null,
                                modifier = Modifier.size(width = 28.dp, height = 38.dp),
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(c.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }

        replyTo?.let { r ->
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
                    Text(
                        "Ответ @${r.login}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        r.text,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                IconButton(onClick = { replyTo = null }) { Icon(Icons.Filled.Close, "Отменить ответ") }
            }
        }

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            phrases.forEach { p ->
                AssistChip(
                    onClick = {
                        vm.sendPhrase(p, replyTo)
                        replyTo = null
                    },
                    label = { Text(p.label) },
                )
            }
            AssistChip(
                onClick = { phrasesOpen = true },
                label = { Text(if (phrases.isEmpty()) "+ Быстрые фразы" else "⚡") },
            )
        }

        // подсказки смайлов по последнему слову
        val lastWord = draft.takeLastWhile { !it.isWhitespace() }
        val emoteSug = remember(lastWord, picker) {
            if (lastWord.length >= 2 && lastWord[0] != '!' && lastWord[0] != '/' && lastWord[0] != '@') {
                vm.suggestEmotes(lastWord)
            } else {
                emptyList()
            }
        }
        if (emoteSug.isNotEmpty() && catQuery == null) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                emoteSug.forEach { e ->
                    AssistChip(
                        onClick = {
                            draft = draft.dropLast(lastWord.length) + e.name + " "
                            vm.useEmote(e)
                        },
                        label = { Text(e.name) },
                        leadingIcon = { EmoteImage(e, Modifier.size(22.dp)) },
                    )
                }
            }
        }

        val send = {
            vm.sendChat(draft, replyTo)
            replyTo = null
            draft = ""
        }

        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column {
                TextField(
                    value = draft,
                    onValueChange = { if (it.length <= 500) draft = it },
                    placeholder = { Text("Начать чат") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { send() }),
                )
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = {
                        emoteOpen = !emoteOpen
                        if (emoteOpen) focus.clearFocus()
                    }) {
                        Icon(if (emoteOpen) Icons.Filled.Keyboard else Icons.Filled.EmojiEmotions, "Смайлы")
                    }
                    Spacer(Modifier.weight(1f))
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "Действия") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(markOn(s.slow, "Медленный режим")) },
                                onClick = {
                                    menuOpen = false
                                    vm.setSlow(!s.slow, s.slowSec)
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(markOn(s.followers, "Только фолловеры")) },
                                onClick = {
                                    menuOpen = false
                                    vm.setFollowers(!s.followers, s.followersMin)
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(markOn(s.subs, "Только сабы")) },
                                onClick = {
                                    menuOpen = false
                                    vm.setSubs(!s.subs)
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(markOn(s.emote, "Только эмоуты")) },
                                onClick = {
                                    menuOpen = false
                                    vm.setEmote(!s.emote)
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(markOn(s.unique, "Уникальный чат")) },
                                onClick = {
                                    menuOpen = false
                                    vm.setUnique(!s.unique)
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Быстрый клип") },
                                enabled = !clipBusy,
                                onClick = {
                                    menuOpen = false
                                    vm.createClip()
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Быстрые фразы") },
                                onClick = {
                                    menuOpen = false
                                    phrasesOpen = true
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(markOn(prefs.showPlayer, "Плеер")) },
                                onClick = {
                                    menuOpen = false
                                    vm.updatePrefs { it.copy(showPlayer = !it.showPlayer) }
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Очистить чат") },
                                onClick = {
                                    menuOpen = false
                                    confirmClear = true
                                },
                            )
                        }
                    }
                    IconButton(onClick = { vm.setShield(!shield) }) {
                        Icon(
                            Icons.Filled.Security,
                            "Режим защиты",
                            tint = if (shield) MaterialTheme.colorScheme.primary else LocalContentColor.current,
                        )
                    }
                    IconButton(onClick = onToggleSearch) { Icon(Icons.Filled.Search, "Поиск по чату") }
                    IconButton(onClick = { if (lastSent.isNotBlank()) draft = lastSent }) {
                        Icon(Icons.Filled.History, "Вернуть последнее сообщение")
                    }
                    IconButton(onClick = { send() }, enabled = draft.isNotBlank()) {
                        Icon(
                            Icons.AutoMirrored.Filled.Send,
                            "Отправить",
                            tint = if (draft.isNotBlank()) MaterialTheme.colorScheme.primary else LocalContentColor.current.copy(alpha = 0.4f),
                        )
                    }
                }
            }
        }
        if (emoteOpen) {
            EmotePanel(
                vm = vm,
                modifier = Modifier.fillMaxWidth().height(300.dp).background(MaterialTheme.colorScheme.surfaceVariant),
                onPick = { e ->
                    draft = (draft.trimEnd() + " " + e.name + " ").trimStart()
                    vm.useEmote(e)
                },
            )
        }
    }

    selected?.let { m ->
        val history = remember(chat.messages, m.userId) {
            chat.messages.filter { it.userId == m.userId && it.kind != MsgKind.SYSTEM }.takeLast(15).reversed()
        }
        UserSheet(
            m = m,
            vm = vm,
            history = history,
            onMention = { draft = (draft + " @$it ").trimStart() },
            onReply = if (canReplyTo(m)) ({ replyTo = m }) else null,
            onDismiss = { selected = null },
        )
    }

    if (phrasesOpen) {
        PhrasesSheet(
            vm = vm,
            onPick = { p ->
                vm.sendPhrase(p, replyTo)
                replyTo = null
                phrasesOpen = false
            },
            onDismiss = { phrasesOpen = false },
        )
    }

    banTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { banTarget = null },
            title = { Text("Забанить @${t.login}?") },
            text = { Text("Бан навсегда. Снять можно в карточке пользователя или в журнале.") },
            confirmButton = {
                TextButton(onClick = {
                    banTarget = null
                    vm.banUser(t.userId, t.login, "")
                }) { Text("Забанить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { banTarget = null }) { Text("Отмена") } },
        )
    }

    heldBan?.let { h ->
        AlertDialog(
            onDismissRequest = { heldBan = null },
            title = { Text("Забанить @${h.login}?") },
            text = { Text("Сообщение будет отклонено, пользователь забанен навсегда.") },
            confirmButton = {
                TextButton(onClick = {
                    heldBan = null
                    vm.punishHeld(h, "ban")
                }) { Text("Забанить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { heldBan = null }) { Text("Отмена") } },
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Очистить чат?") },
            text = { Text("Все сообщения будут удалены у всех зрителей.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    vm.clearChat()
                }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } },
        )
    }
}

// ---------------- строка сообщения ----------------

private fun badgeContent(icon: ImageVector, tint: Color, sizeSp: Float) = InlineTextContent(
    Placeholder(sizeSp.sp, sizeSp.sp, PlaceholderVerticalAlign.TextCenter)
) { Icon(icon, null, Modifier.fillMaxSize(), tint = tint) }

private fun twitchEmoteUrl(id: String) = "https://static-cdn.jtvnw.net/emoticons/v2/$id/default/dark/2.0"

internal fun emoteContent(url: String, sizeSp: Float, aspect: Float, animated: Boolean) = InlineTextContent(
    Placeholder((sizeSp * aspect).sp, sizeSp.sp, PlaceholderVerticalAlign.TextCenter)
) {
    val ctx = LocalContext.current
    val request = remember(url, animated) {
        ImageRequest.Builder(ctx).data(url).apply {
            if (!animated) decoderFactory(BitmapFactoryDecoder.Factory())
        }.build()
    }
    AsyncImage(
        model = request,
        contentDescription = it,
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Fit,
    )
}

internal fun inlineMap(m: ChatMsg, textSize: Float, animated: Boolean, scale: Float): Map<String, InlineTextContent> {
    val map = HashMap<String, InlineTextContent>()
    val badge = textSize * 1.1f
    val emote = textSize * 1.7f * scale
    if (m.isBroadcaster) map["b_bc"] = badgeContent(Icons.Filled.Videocam, Color(0xFFE91916), badge)
    if (m.isMod) map["b_mod"] = badgeContent(Icons.Filled.Security, Color(0xFF00C853), badge)
    if (m.isVip) map["b_vip"] = badgeContent(Icons.Filled.Stars, Color(0xFFE005B9), badge)
    if (m.isSub) map["b_sub"] = badgeContent(Icons.Filled.Star, Color(0xFFB388FF), badge)
    m.emotes.forEach { e -> map["e_${e.id}"] = emoteContent(e.url ?: twitchEmoteUrl(e.id), emote, e.aspect, animated) }
    return map
}

private fun fontOf(name: String?): FontFamily? = when (name) {
    "serif" -> FontFamily.Serif
    "mono" -> FontFamily.Monospace
    "cursive" -> FontFamily.Cursive
    "sans" -> FontFamily.SansSerif
    else -> null
}

private fun buildMsg(m: ChatMsg, showTime: Boolean, showBadges: Boolean, ns: NickStyle): AnnotatedString =
    buildAnnotatedString {
        if (showTime) {
            withStyle(SpanStyle(color = Color(0xFF7A7A85), fontSize = 0.8.em)) {
                append(timeFmt.format(Date(m.time)))
                append(" ")
            }
        }
        if (m.firstMsg && ns.prefix == null) {
            withStyle(SpanStyle(background = Color(0x55FFC400), fontWeight = FontWeight.Bold, fontSize = 0.75.em)) {
                append(" NEW ")
            }
            append(" ")
        }
        if (showBadges && m.isBroadcaster) { appendInlineContent("b_bc", "[B]"); append(" ") }
        if (showBadges && m.isMod) { appendInlineContent("b_mod", "[M]"); append(" ") }
        if (showBadges && m.isVip) { appendInlineContent("b_vip", "[V]"); append(" ") }
        if (showBadges && m.isSub) { appendInlineContent("b_sub", "[S]"); append(" ") }
        ns.prefix?.let { append(it) }

        val baseColor = Color(m.color ?: 0xFFFFFFFF)
        val weight = if (ns.bold == false) FontWeight.Normal else FontWeight.Bold
        val italic = if (ns.italic == true) FontStyle.Italic else null
        val family = fontOf(ns.font)
        val ga = ns.gradA
        val gb = ns.gradB
        if (ga != null && gb != null) {
            withStyle(
                SpanStyle(
                    brush = Brush.horizontalGradient(listOf(Color(ga), Color(gb))),
                    fontWeight = weight, fontStyle = italic, fontFamily = family,
                )
            ) { append(m.display) }
        } else {
            val c = ns.nameColor?.let { Color(it) } ?: baseColor
            withStyle(SpanStyle(color = c, fontWeight = weight, fontStyle = italic, fontFamily = family)) {
                append(m.display)
            }
        }
        append(if (m.kind == MsgKind.ACTION) " " else ": ")

        val bodyColor = ns.textColor?.let { Color(it) }
            ?: if (m.kind == MsgKind.ACTION) (ns.nameColor?.let { Color(it) } ?: baseColor) else Color.Unspecified
        val bodyStyle = SpanStyle(
            color = bodyColor,
            textDecoration = if (m.deleted) TextDecoration.LineThrough else null,
        )
        withStyle(bodyStyle) {
            var i = 0
            for (e in m.emotes) {
                if (e.start < i || e.end > m.text.length || e.start >= e.end) continue
                append(m.text.substring(i, e.start))
                appendInlineContent("e_${e.id}", m.text.substring(e.start, e.end))
                i = e.end
            }
            append(m.text.substring(i))
        }
    }

@Composable
private fun ModIcon(icon: ImageVector, desc: String, tint: Color, box: Dp, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.size(box).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, Modifier.size(box * 0.56f), tint = if (enabled) tint else tint.copy(alpha = 0.3f))
    }
}

@Composable
private fun ModIconBar(
    m: ChatMsg,
    box: Dp,
    prefs: Prefs,
    canModerate: Boolean,
    onReply: (() -> Unit)?,
    onBan: () -> Unit,
    onMute: () -> Unit,
    onWarn: () -> Unit,
    onDelete: () -> Unit,
    onMore: (() -> Unit)? = null,
) {
    val glyphs = remember(prefs.iconPack) { packGlyphs(prefs.iconPack) }
    val accent = MaterialTheme.colorScheme.primary
    val mono = MaterialTheme.colorScheme.onSurfaceVariant
    Row {
        if (onReply != null) {
            ModIcon(Icons.AutoMirrored.Filled.Reply, "Ответить", accent, box, onClick = onReply)
        }
        if (canModerate) {
            GlyphButton(glyphs, 0, "Бан", actionTint(0, prefs.iconColors, accent, mono), prefs.iconShape, box, onClick = onBan)
            GlyphButton(glyphs, 1, "Мут", actionTint(1, prefs.iconColors, accent, mono), prefs.iconShape, box, onClick = onMute)
            GlyphButton(glyphs, 2, "Предупреждение", actionTint(2, prefs.iconColors, accent, mono), prefs.iconShape, box, onClick = onWarn)
            GlyphButton(
                glyphs, 3, "Удалить сообщение", actionTint(3, prefs.iconColors, accent, mono), prefs.iconShape, box,
                enabled = !m.deleted, onClick = onDelete,
            )
        }
        if (onMore != null) ModIcon(Icons.Filled.MoreHoriz, "Ещё", Color(0xFFC4C4CC), box, onClick = onMore)
    }
}

@Composable
private fun MessageRow(
    m: ChatMsg,
    prefs: Prefs,
    rules: List<StyleRule>,
    canModerate: Boolean,
    expanded: Boolean,
    onTap: () -> Unit,
    onLong: () -> Unit,
    onBan: () -> Unit,
    onMute: () -> Unit,
    onWarn: () -> Unit,
    onDelete: () -> Unit,
    onMore: () -> Unit,
    canReply: Boolean,
    onReply: () -> Unit,
) {
    if (m.eventKind != null) {
        val showBar = canModerate && m.text.isNotBlank() && prefs.modIcons != "off" &&
            (prefs.modIcons == "always" || expanded)
        val hp = LocalHapticFeedback.current
        Column {
            EventCard(m, prefs, if (m.userId.isNotBlank() && m.kind != MsgKind.SYSTEM) onTap else null)
            if (showBar) {
                val box0 = when (prefs.iconSize) {
                    "small" -> 30.dp
                    "large" -> 42.dp
                    else -> 34.dp
                }
                fun t0() {
                    if (prefs.haptics) hp.performHapticFeedback(HapticFeedbackType.LongPress)
                }
                Row(Modifier.fillMaxWidth().padding(end = 10.dp), horizontalArrangement = Arrangement.End) {
                    ModIconBar(m, box0, prefs, true, null, { t0(); onBan() }, { t0(); onMute() }, { t0(); onWarn() }, { t0(); onDelete() }, onMore)
                }
            }
        }
        return
    }
    val bg = MaterialTheme.colorScheme.background
    if (m.kind == MsgKind.SYSTEM) {
        Text(
            m.text,
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontStyle = FontStyle.Italic,
        )
        return
    }
    val haptic = LocalHapticFeedback.current
    fun tick() {
        if (prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    val ns = remember(m.login, m.isMod, m.isVip, m.isSub, m.isBroadcaster, m.firstMsg, rules) { styleFor(m, rules) }
    val text = remember(m, prefs.showTime, prefs.showBadges, ns) { buildMsg(m, prefs.showTime, prefs.showBadges, ns) }
    val inline = remember(m.id, m.emotes, m.isMod, m.isSub, m.isVip, m.isBroadcaster, prefs.textSize, prefs.animEmotes, prefs.emoteScale) {
        inlineMap(m, prefs.textSize, prefs.animEmotes, prefs.emoteScale)
    }
    val styleBg = ns.bgColor
    val rowBg = when {
        m.mention -> MaterialTheme.colorScheme.primary.copy(alpha = 0.16f).compositeOver(bg)
        m.suspect != null -> Color(0xFFFF7043).copy(alpha = 0.16f).compositeOver(bg)
        m.flagged -> Color(0xFFFFB300).copy(alpha = 0.18f).compositeOver(bg)
        m.rewardColor != null -> Color(m.rewardColor).copy(alpha = 0.16f).compositeOver(bg)
        styleBg != null -> Color(styleBg).copy(alpha = 0.09f).compositeOver(bg)
        else -> bg
    }
    val bar = ns.barColor ?: m.rewardColor
    val box = when (prefs.iconSize) {
        "small" -> 30.dp
        "large" -> 42.dp
        else -> 34.dp
    }
    val vPad = when (prefs.density) {
        "compact" -> 0.dp
        "roomy" -> 7.dp
        else -> 3.dp
    }
    val hasBar = canModerate || canReply
    val replyAction: (() -> Unit)? = if (canReply) onReply else null
    val side = hasBar && prefs.modIcons == "always"
    val left = prefs.iconSide == "left"
    val below = hasBar && prefs.modIcons == "tap" && expanded
    val fresh = remember(m.id) { System.currentTimeMillis() - m.time < 1500 }
    val animate = prefs.animLevel != "off" && fresh

    Column(
        Modifier
            .fillMaxWidth()
            .appear(animate)
            .background(rowBg)
            .then(
                if (bar != null) {
                    Modifier.drawBehind { drawRect(Color(bar), size = Size(3.dp.toPx(), size.height)) }
                } else {
                    Modifier
                }
            )
            .combinedClickable(onClick = onTap, onLongClick = onLong)
            .padding(
                start = if (side && left) 2.dp else 10.dp,
                end = if (side && !left) 2.dp else 10.dp,
                top = 3.dp,
                bottom = 3.dp,
            )
    ) {
        Row(verticalAlignment = Alignment.Top) {
            if (side && left) {
                ModIconBar(m, box, prefs, canModerate, replyAction, { tick(); onBan() }, { tick(); onMute() }, { tick(); onWarn() }, { tick(); onDelete() })
            }
            Column(Modifier.weight(1f).padding(vertical = vPad).alpha(if (m.deleted) 0.5f else 1f)) {
                m.rewardTag?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(m.rewardColor ?: 0xFFFFC107),
                    )
                }
                m.replyTo?.let {
                    Text(
                        "↪ $it",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(text, inlineContent = inline, fontSize = (prefs.textSize * (ns.scale ?: 1f)).sp)
                val tag = when {
                    m.punished != null -> "⛔ ${m.punished}"
                    m.deleted -> "сообщение удалено"
                    else -> null
                }
                if (tag != null) {
                    Text(tag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                }
                m.suspect?.let {
                    Text("⚠ $it", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFFA040))
                }
            }
            if (side && !left) {
                ModIconBar(m, box, prefs, canModerate, replyAction, { tick(); onBan() }, { tick(); onMute() }, { tick(); onWarn() }, { tick(); onDelete() })
            }
        }
        if (below) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                ModIconBar(m, box, prefs, canModerate, replyAction, { tick(); onBan() }, { tick(); onMute() }, { tick(); onWarn() }, { tick(); onDelete() }, onMore)
            }
        }
    }
}

// ---------------- действия над пользователем ----------------

@Composable
internal fun UserSheet(
    m: ChatMsg,
    vm: AppViewModel,
    history: List<ChatMsg>,
    onMention: (String) -> Unit,
    onReply: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val clipboard = LocalClipboardManager.current
    var reason by remember { mutableStateOf("") }
    var customVal by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf(60) }
    var showHistory by remember { mutableStateOf(false) }
    var confirmBan by remember { mutableStateOf(false) }
    val locked = m.isBroadcaster
    var info by remember { mutableStateOf<UserInfo?>(null) }
    LaunchedEffect(m.userId) { info = vm.loadUserInfo(m.userId) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    m.display,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(m.color ?: 0xFFFFFFFF),
                )
                Text("@${m.login}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val roles = listOfNotNull(
                if (m.isBroadcaster) "стример" else null,
                if (m.isMod) "модератор" else null,
                if (m.isVip) "VIP" else null,
                if (m.isSub) "сабскрайбер" else null,
                if (m.firstMsg) "первое сообщение" else null,
            )
            if (roles.isNotEmpty()) {
                Text(roles.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
            info?.let { i ->
                val f = i.followedAt
                val fol = when {
                    f == null -> "не фолловер"
                    f < 0L -> ""
                    else -> "фолловер с " + SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(f))
                }
                Text(
                    "Аккаунту " + fmtAge(System.currentTimeMillis() - i.createdAt) + if (fol.isNotEmpty()) " · $fol" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            m.suspect?.let {
                Text("⚠ $it", style = MaterialTheme.typography.bodySmall, color = Color(0xFFFFA040))
            }
            if (m.text.isNotBlank()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Text(m.text, Modifier.padding(12.dp).fillMaxWidth())
                }
            }

            OutlinedTextField(
                value = reason,
                onValueChange = { if (it.length <= 200) reason = it },
                label = { Text("Причина (необязательно)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReasonPresets.forEach { r -> AssistChip(onClick = { reason = r }, label = { Text(r) }) }
            }

            Text("Мут", fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MuteDurations.forEach { sec ->
                    FilledTonalButton(
                        onClick = {
                            vm.timeoutUser(m.userId, m.login, sec, reason.trim())
                            onDismiss()
                        },
                        enabled = !locked,
                    ) { Text(fmtDur(sec)) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = customVal,
                    onValueChange = { v -> if (v.length <= 6 && v.all { it.isDigit() }) customVal = v },
                    label = { Text("Своё") },
                    modifier = Modifier.width(100.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                ChipChoice(
                    options = listOf("с" to 1, "м" to 60, "ч" to 3600, "д" to 86400),
                    selected = unit,
                    onSelect = { unit = it },
                    modifier = Modifier.weight(1f),
                )
            }
            val customSec = (customVal.toLongOrNull() ?: 0L) * unit
            Button(
                onClick = {
                    vm.timeoutUser(m.userId, m.login, customSec.coerceIn(1L, 1_209_600L).toInt(), reason.trim())
                    onDismiss()
                },
                enabled = !locked && customSec > 0,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Мут на своё время") }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilledTonalButton(
                    onClick = {
                        vm.warnUser(m.userId, m.login, reason.trim())
                        onDismiss()
                    },
                    enabled = !locked,
                    modifier = Modifier.weight(1f),
                ) { Text("Предупредить") }
                FilledTonalButton(
                    onClick = {
                        vm.deleteMessage(m)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Удалить") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { confirmBan = true },
                    enabled = !locked,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError,
                    ),
                    modifier = Modifier.weight(1f),
                ) { Text("Бан") }
                OutlinedButton(
                    onClick = {
                        vm.unbanUser(m.userId, m.login)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Снять бан/мут") }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (onReply != null) {
                    TextButton(onClick = {
                        onReply()
                        onDismiss()
                    }) { Text("Ответить на сообщение") }
                }
                TextButton(onClick = {
                    onMention(m.login)
                    onDismiss()
                }) { Text("Упомянуть @") }
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(m.text))
                    onDismiss()
                }) { Text("Копировать текст") }
                TextButton(onClick = { showHistory = !showHistory }) {
                    Text(if (showHistory) "Скрыть историю" else "История (${history.size})")
                }
            }
            if (showHistory) {
                history.forEach { h ->
                    Text(
                        "${timeFmt.format(Date(h.time))}  ${h.text}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.size(4.dp))
        }
    }

    if (confirmBan) {
        AlertDialog(
            onDismissRequest = { confirmBan = false },
            title = { Text("Забанить @${m.login}?") },
            text = { Text("Бан навсегда. Снять его можно кнопкой «Снять бан/мут» или в журнале.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmBan = false
                    vm.banUser(m.userId, m.login, reason.trim())
                    onDismiss()
                }) { Text("Забанить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmBan = false }) { Text("Отмена") } },
        )
    }
}
