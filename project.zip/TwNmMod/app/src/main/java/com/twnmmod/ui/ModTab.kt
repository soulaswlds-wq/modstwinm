@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.twnmmod.AppViewModel
import com.twnmmod.ChatMsg
import com.twnmmod.MsgKind
import com.twnmmod.Suspect
import com.twnmmod.UnbanReq
import com.twnmmod.Viewer
import com.twnmmod.fmtDur
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val modFmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

@Composable
fun ModTab(vm: AppViewModel, modifier: Modifier) {
    var mode by rememberSaveable { mutableStateOf(0) }
    val unban by vm.unban.collectAsState()
    val suspects by vm.suspects.collectAsState()
    val viewers by vm.viewers.collectAsState()

    Column(modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
            ChipChoice(
                listOf(
                    "Разбан (${unban.items.size})" to 0,
                    "Обход бана (${suspects.size})" to 1,
                    "Зрители" to 2,
                ),
                mode,
                { mode = it },
            )
        }
        when (mode) {
            0 -> UnbanPanel(vm, unban.items, unban.error)
            1 -> SuspectPanel(vm, suspects)
            else -> ViewersPanel(vm, viewers.items, viewers.total, viewers.loading, viewers.error)
        }
    }
}

// ---------------- запросы на разбан ----------------

@Composable
private fun UnbanPanel(vm: AppViewModel, items: List<UnbanReq>, error: String?) {
    LaunchedEffect(Unit) {
        while (true) {
            vm.loadUnban()
            delay(15_000)
        }
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (error != null) item { NoteCard("Не удалось загрузить запросы: $error", error = true) }
        if (items.isEmpty() && error == null) {
            item {
                Text(
                    "Запросов на разбан нет. Новые появятся здесь сами.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        items(items, key = { it.id }) { r ->
            UnbanCard(
                r,
                onApprove = { vm.resolveUnban(r, true, it) },
                onDeny = { vm.resolveUnban(r, false, it) },
            )
        }
    }
}

@Composable
private fun UnbanCard(r: UnbanReq, onApprove: (String) -> Unit, onDeny: (String) -> Unit) {
    var reply by remember(r.id) { mutableStateOf("") }
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("@${r.login}", fontWeight = FontWeight.Bold)
            Text(
                modFmt.format(Date(r.createdAt)),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(if (r.text.isNotBlank()) r.text else "Без текста")
            OutlinedTextField(
                value = reply,
                onValueChange = { if (it.length <= 500) reply = it },
                label = { Text("Ответ пользователю (необязательно)") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onApprove(reply.trim()) }, modifier = Modifier.weight(1f)) { Text("Принять") }
                OutlinedButton(onClick = { onDeny(reply.trim()) }, modifier = Modifier.weight(1f)) { Text("Отклонить") }
            }
        }
    }
}

// ---------------- вероятный обход бана ----------------

@Composable
private fun SuspectPanel(vm: AppViewModel, suspects: List<Suspect>) {
    val prefs by vm.prefs.collectAsState()
    var banTarget by remember { mutableStateOf<Suspect?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text(
                "Сюда попадают зрители, которых Twitch считает вероятными обходчиками бана, и те, чей ник очень " +
                    "похож на ник забаненного. Проверяй сам: совпадение ников ещё не доказательство.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (suspects.isEmpty()) {
            item { Text("Пока никого подозрительного.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(suspects, key = { it.userId }) { s ->
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("@${s.login}", fontWeight = FontWeight.Bold)
                    Text("⚠ ${s.reason}", color = Color(0xFFFFA040))
                    Text(
                        "Источник: ${s.source} · ${modFmt.format(Date(s.time))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { vm.timeoutUser(s.userId, s.login, prefs.timeoutSec, "") },
                            modifier = Modifier.weight(1f),
                        ) { Text("Мут ${fmtDur(prefs.timeoutSec)}") }
                        Button(
                            onClick = {
                                if (prefs.confirmBan) banTarget = s else vm.banUser(s.userId, s.login, "")
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error,
                                contentColor = MaterialTheme.colorScheme.onError,
                            ),
                            modifier = Modifier.weight(1f),
                        ) { Text("Бан") }
                        OutlinedButton(
                            onClick = { vm.dismissSuspect(s.userId) },
                            modifier = Modifier.weight(1f),
                        ) { Text("Не он") }
                    }
                }
            }
        }
    }

    banTarget?.let { s ->
        AlertDialog(
            onDismissRequest = { banTarget = null },
            title = { Text("Забанить @${s.login}?") },
            text = { Text("Бан навсегда.") },
            confirmButton = {
                TextButton(onClick = {
                    banTarget = null
                    vm.banUser(s.userId, s.login, "")
                }) { Text("Забанить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { banTarget = null }) { Text("Отмена") } },
        )
    }
}

// ---------------- зрители ----------------

@Composable
private fun ViewersPanel(vm: AppViewModel, items: List<Viewer>, total: Int, loading: Boolean, error: String?) {
    val chat by vm.chat.collectAsState()
    val channel by vm.current.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    var selected by remember { mutableStateOf<Viewer?>(null) }

    LaunchedEffect(Unit) { if (items.isEmpty()) vm.loadViewers() }

    val q = query.trim()
    val shown = remember(items, q) {
        if (q.isEmpty()) items else items.filter { it.login.contains(q, true) || it.display.contains(q, true) }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Поиск среди зрителей") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Очистить") }
                    }
                },
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = { vm.loadViewers() }) { Icon(Icons.Filled.Refresh, "Обновить") }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                if (total > 0) "В чате: $total · показано ${shown.size}" else "В чате: ${items.size}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (loading) CircularProgressIndicator(Modifier.padding(2.dp), strokeWidth = 2.dp)
        }
        if (error != null) {
            Box(Modifier.padding(12.dp)) { NoteCard("Не удалось загрузить список: $error", error = true) }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(shown, key = { it.id }) { v ->
                Column(Modifier.fillMaxWidth().clickable { selected = v }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text(v.display, fontWeight = FontWeight.Bold)
                    if (!v.display.equals(v.login, ignoreCase = true)) {
                        Text(
                            "@${v.login}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }

    selected?.let { v ->
        val synthetic = remember(v.id) {
            ChatMsg(
                id = "viewer-${v.id}",
                userId = v.id,
                login = v.login,
                display = v.display,
                color = null,
                text = "",
                kind = MsgKind.CHAT,
                isBroadcaster = v.login.equals(channel?.login, ignoreCase = true),
            )
        }
        val history = remember(chat.messages, v.id) {
            chat.messages.filter { it.userId == v.id && it.kind != MsgKind.SYSTEM }.takeLast(15).reversed()
        }
        UserSheet(
            m = synthetic,
            vm = vm,
            history = history,
            onMention = { vm.mention(it) },
            onReply = null,
            onDismiss = { selected = null },
        )
    }
}
