package com.twnmmod.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twnmmod.Tempo

/** Тонкая полоска «темп чата за последнюю минуту». Обновляется раз в секунду, почти не грузит. */
@Composable
fun TempoStrip(tempo: Tempo, accent: Color, modifier: Modifier = Modifier) {
    if (tempo.bins.isEmpty()) return
    val hot = Color(0xFFFF8A3D)
    Row(
        modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 3.dp).height(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Canvas(Modifier.weight(1f).fillMaxHeight()) {
            val n = tempo.bins.size
            val maxV = maxOf(4, tempo.bins.max())
            val w = size.width / n
            tempo.bins.forEachIndexed { i, v ->
                val h = size.height * (v.toFloat() / maxV).coerceIn(0.07f, 1f)
                val fade = 0.22f + 0.6f * (i.toFloat() / n)
                val c = if (tempo.spike && i >= n - 5) hot.copy(alpha = 0.95f) else accent.copy(alpha = fade)
                drawRoundRect(
                    color = c,
                    topLeft = Offset(i * w + w * 0.18f, size.height - h),
                    size = Size(w * 0.64f, h),
                    cornerRadius = CornerRadius(w * 0.32f),
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Text(
            "${tempo.perMin}/мин" + if (tempo.spike) " ⚡" else "",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
        )
    }
}
