package com.twnmmod.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twnmmod.ChatMsg
import com.twnmmod.Prefs

class EventLook(val color: Color, val icon: ImageVector)

fun eventLook(kind: String, custom: Long?): EventLook = when (kind) {
    "sub", "resub" -> EventLook(Color(0xFFB388FF), Icons.Filled.Star)
    "gift" -> EventLook(Color(0xFFFF6EC7), Icons.Filled.CardGiftcard)
    "raid" -> EventLook(Color(0xFFFF8A3D), Icons.Filled.Flag)
    "follow" -> EventLook(Color(0xFF00E0A0), Icons.Filled.PersonAdd)
    "cheer" -> EventLook(Color(0xFF3B9BFF), Icons.Filled.FlashOn)
    "announce" -> EventLook(if (custom != null) Color(custom) else Color(0xFF9146FF), Icons.Filled.Notifications)
    "ritual" -> EventLook(Color(0xFF26C6DA), Icons.Filled.Favorite)
    "ban" -> EventLook(Color(0xFFFF5252), Icons.Filled.Block)
    "timeout" -> EventLook(Color(0xFFFFA726), Icons.Filled.Timer)
    "clear" -> EventLook(Color(0xFF90A4AE), Icons.Filled.Delete)
    "suspect" -> EventLook(Color(0xFFFFB300), Icons.Filled.Warning)
    "points" -> EventLook(Color(0xFFFFC107), Icons.Filled.CardGiftcard)
    "clip" -> EventLook(Color(0xFF26A69A), Icons.Filled.ContentCut)
    else -> EventLook(Color(0xFF90A4AE), Icons.Filled.Info)
}

/** Плавное появление: прозрачность и лёгкий сдвиг. Считается в слое, перерисовок композиции нет. */
@Composable
fun Modifier.appear(enabled: Boolean, strong: Boolean = false): Modifier {
    if (!enabled) return this
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(if (strong) 340 else 180)) }
    return this.graphicsLayer {
        val p = a.value
        alpha = p
        translationY = (1f - p) * (if (strong) 28f else 12f)
        if (strong) {
            val sc = 0.95f + 0.05f * p
            scaleX = sc
            scaleY = sc
        }
    }
}

private fun buildBody(m: ChatMsg): AnnotatedString = buildAnnotatedString {
    var i = 0
    for (e in m.emotes) {
        if (e.start < i || e.end > m.text.length || e.start >= e.end) continue
        append(m.text.substring(i, e.start))
        appendInlineContent("e_${e.id}", m.text.substring(e.start, e.end))
        i = e.end
    }
    append(m.text.substring(i))
}

/** Карточка события: подписка, рейд, фолловер, биты, объявление, бан, очистка и т.д. */
@Composable
fun EventCard(m: ChatMsg, prefs: Prefs, onClick: (() -> Unit)?) {
    val look = eventLook(m.eventKind ?: "notice", m.eventColor)
    val round = if (prefs.rounding == "sharp") 6.dp else 14.dp
    val shape = RoundedCornerShape(round)
    val body = remember(m.id, m.text, m.emotes) { buildBody(m) }
    val inline = remember(m.id, m.emotes, prefs.textSize, prefs.animEmotes, prefs.emoteScale) {
        inlineMap(m, prefs.textSize, prefs.animEmotes, prefs.emoteScale)
    }
    val fresh = remember(m.id) { System.currentTimeMillis() - m.time < 2500 }
    val animate = prefs.animLevel != "off" && fresh
    val strong = prefs.animLevel == "rich"
    val clickMod = if (onClick != null) Modifier.clickable { onClick() } else Modifier
    val titleSize = (prefs.textSize * 0.95f).sp
    val hasBody = m.text.isNotBlank()

    when (prefs.eventStyle) {
        "compact" -> {
            Row(
                Modifier.fillMaxWidth().appear(animate, strong).then(clickMod).padding(horizontal = 10.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.width(3.dp).size(width = 3.dp, height = 20.dp).background(look.color, CircleShape))
                Spacer(Modifier.width(8.dp))
                Icon(look.icon, null, Modifier.size(16.dp), tint = look.color)
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f)) {
                    Text(m.eventTitle.orEmpty(), color = look.color, fontWeight = FontWeight.SemiBold, fontSize = (prefs.textSize * 0.9f).sp)
                    if (hasBody) Text(body, inlineContent = inline, fontSize = (prefs.textSize * 0.95f).sp)
                }
            }
        }
        "outline" -> {
            Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp).appear(animate, strong)) {
                Row(
                    Modifier.fillMaxWidth().clip2(shape).border(BorderStroke(1.5.dp, look.color.copy(alpha = 0.7f)), shape)
                        .then(clickMod).padding(10.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    Icon(look.icon, null, Modifier.size(20.dp), tint = look.color)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.eventTitle.orEmpty(), color = look.color, fontWeight = FontWeight.Bold, fontSize = titleSize)
                        if (hasBody) Text(body, inlineContent = inline, fontSize = prefs.textSize.sp)
                    }
                }
            }
        }
        else -> {
            Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp).appear(animate, strong)) {
                Row(
                    Modifier.fillMaxWidth().clip2(shape)
                        .background(look.color.copy(alpha = 0.14f))
                        .border(BorderStroke(1.dp, look.color.copy(alpha = 0.32f)), shape)
                        .then(clickMod).padding(10.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    Box(
                        Modifier.size(34.dp).background(look.color.copy(alpha = 0.24f), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Icon(look.icon, null, Modifier.size(19.dp), tint = look.color) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.eventTitle.orEmpty(), color = look.color, fontWeight = FontWeight.Bold, fontSize = titleSize)
                        if (hasBody) {
                            Text(
                                body,
                                inlineContent = inline,
                                fontSize = prefs.textSize.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun Modifier.clip2(shape: androidx.compose.ui.graphics.Shape): Modifier =
    this.then(Modifier.clip(shape))
