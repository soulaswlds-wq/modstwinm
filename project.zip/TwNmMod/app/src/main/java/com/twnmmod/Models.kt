package com.twnmmod

object Config {
    const val CLIENT_ID = "0z0ain8jzpwxfz0ku2jghc1ekm60cf"

    val SCOPES = listOf(
        "chat:read",
        "chat:edit",
        "user:read:moderated_channels",
        "moderator:manage:banned_users",
        "moderator:manage:chat_messages",
        "moderator:manage:warnings",
        "moderator:manage:chat_settings",
        "moderator:manage:announcements",
        "channel:manage:broadcast",
        "channel:manage:polls",
        "channel:manage:predictions",
        "clips:edit",
        "moderator:manage:automod",
        "moderator:manage:blocked_terms",
        "moderator:manage:shield_mode",
        "moderator:manage:shoutouts",
        "moderator:read:followers",
        "channel:manage:raids",
        "moderator:manage:unban_requests",
        "moderator:read:suspicious_users",
        "moderator:read:chatters",
        "user:read:emotes",
        "channel:read:redemptions",
    )
}

enum class MsgKind { CHAT, ACTION, SYSTEM }

data class EmoteSpan(val id: String, val start: Int, val end: Int, val url: String? = null, val aspect: Float = 1f)

data class ChatMsg(
    val id: String,
    val userId: String,
    val login: String,
    val display: String,
    val color: Long?,
    val text: String,
    val emotes: List<EmoteSpan> = emptyList(),
    val isBroadcaster: Boolean = false,
    val isMod: Boolean = false,
    val isVip: Boolean = false,
    val isSub: Boolean = false,
    val firstMsg: Boolean = false,
    val time: Long = System.currentTimeMillis(),
    val kind: MsgKind = MsgKind.CHAT,
    val replyTo: String? = null,
    val mention: Boolean = false,
    val deleted: Boolean = false,
    val punished: String? = null,
    val local: Boolean = false,
    val flagged: Boolean = false,
    val suspect: String? = null,
    val eventKind: String? = null,
    val eventTitle: String? = null,
    val eventColor: Long? = null,
    val rewardTag: String? = null,
    val rewardColor: Long? = null,
)

data class ChannelRef(val id: String, val login: String, val name: String)

data class DeviceCode(
    val deviceCode: String,
    val userCode: String,
    val uri: String,
    val expiresIn: Int,
    val interval: Int,
)

data class ChatSettings(
    val slow: Boolean = false,
    val slowSec: Int = 30,
    val followers: Boolean = false,
    val followersMin: Int = 0,
    val subs: Boolean = false,
    val emote: Boolean = false,
    val unique: Boolean = false,
)

data class ChannelInfo(val title: String, val gameId: String, val gameName: String)
data class Category(val id: String, val name: String, val art: String)
data class StreamInfo(val live: Boolean, val viewers: Int, val startedAt: Long, val gameName: String)

data class PollChoice(val id: String, val title: String, val votes: Int)
data class PollInfo(
    val id: String,
    val title: String,
    val status: String,
    val choices: List<PollChoice>,
    val duration: Int,
    val startedAt: Long,
)

data class Outcome(val id: String, val title: String, val users: Int, val points: Long, val color: String)
data class PredictionInfo(
    val id: String,
    val title: String,
    val status: String,
    val outcomes: List<Outcome>,
    val window: Int,
    val createdAt: Long,
    val winnerId: String?,
)

data class LogEntry(
    val time: Long,
    val channel: String,
    val action: String,
    val target: String,
    val targetId: String,
    val detail: String,
    val ok: Boolean,
    val error: String?,
)

data class Preset(val title: String, val gameId: String, val gameName: String)
data class Template(val title: String, val options: List<String>, val seconds: Int)

data class SelfState(
    val color: Long? = null,
    val isMod: Boolean = false,
    val isBroadcaster: Boolean = false,
    val isVip: Boolean = false,
    val isSub: Boolean = false,
)

data class Prefs(
    val accent: Long = 0xFF9146FF,
    val timeoutSec: Int = 600,
    val modIcons: String = "always",
    val confirmBan: Boolean = true,
    val textSize: Float = 15f,
    val showTime: Boolean = false,
    val keepScreen: Boolean = true,
    val thirdEmotes: Boolean = true,
    val animEmotes: Boolean = true,
    val bg: String = "twitch",
    val rounding: String = "normal",
    val density: String = "normal",
    val iconSize: String = "normal",
    val iconSide: String = "right",
    val quickItems: String = "slow,followers,subs,emote,clear,clip",
    val startTab: Int = 0,
    val showBadges: Boolean = true,
    val highlightWords: String = "",
    val bufferSize: Int = 600,
    val showPlayer: Boolean = true,
    val playerMuted: Boolean = false,
    val categoryCmd: String = "!g",
    val catAutoSend: Boolean = false,
    val emoteScale: Float = 2.0f,
    val themeId: String = "classic",
    val eventStyle: String = "soft",
    val animLevel: String = "normal",
    val haptics: Boolean = true,
    val showTempo: Boolean = true,
    val iconPack: String = "classic",
    val iconColors: String = "colored",
    val iconShape: String = "circle",
)

/** followedAt: null = не фолловер, -1 = неизвестно (нет прав), иначе время подписки. */
data class UserInfo(val createdAt: Long, val followedAt: Long?)

data class UnbanReq(
    val id: String,
    val userId: String,
    val login: String,
    val display: String,
    val text: String,
    val createdAt: Long,
)

data class Suspect(
    val userId: String,
    val login: String,
    val display: String,
    val reason: String,
    val source: String,
    val time: Long,
)

data class Viewer(val id: String, val login: String, val display: String)
data class Phrase(val label: String, val text: String)
data class BannedEntry(val login: String, val norm: String)

data class ListState<T>(
    val items: List<T> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val total: Int = 0,
)

/** Можно ли ответить на это сообщение (у него настоящий id от Twitch). */
fun canReplyTo(m: ChatMsg): Boolean =
    m.kind != MsgKind.SYSTEM && !m.local && m.id.isNotBlank() &&
        !m.id.startsWith("irc-") && !m.id.startsWith("viewer-") && !m.id.startsWith("sys-")

/** Приведение ника к «основе»: без цифр и _ на конце, леетспик в буквы. */
fun normLogin(login: String): String {
    val low = login.lowercase()
    var base = low.trimEnd { it.isDigit() || it == '_' }
    if (base.length < 3) base = low
    val sb = StringBuilder()
    for (c in base) {
        val x = when (c) {
            '0' -> 'o'
            '1' -> 'l'
            '3' -> 'e'
            '4' -> 'a'
            '5' -> 's'
            '7' -> 't'
            else -> c
        }
        if (x != '_') sb.append(x)
    }
    return sb.toString()
}

fun levenshtein(a: String, b: String): Int {
    if (a == b) return 0
    if (a.isEmpty()) return b.length
    if (b.isEmpty()) return a.length
    var prev = IntArray(b.length + 1) { it }
    var cur = IntArray(b.length + 1)
    for (i in 1..a.length) {
        cur[0] = i
        for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
        }
        val t = prev
        prev = cur
        cur = t
    }
    return prev[b.length]
}

data class PickEmote(val name: String, val url: String, val aspect: Float = 1f)
data class EmotePicker(
    val subs: List<PickEmote> = emptyList(),
    val channel: List<PickEmote> = emptyList(),
    val global: List<PickEmote> = emptyList(),
)
data class Tempo(val bins: List<Int> = emptyList(), val perMin: Int = 0, val spike: Boolean = false)

data class UserEmote(val id: String, val name: String, val type: String, val owner: String)
