package com.twnmmod

object Config {
    const val CLIENT_ID = "0z0ain8jzpwxfz0ku2jghc1ekm60cf"

    val SCOPES = listOf(
        "chat:read",
        "chat:edit",
        "user:read:moderated_channels",
        "moderator:manage:banned_users",
        "moderator:manage:chat_messages",
        "moderator:manage:warnings",
        "moderator:manage:chat_settings",
        "moderator:manage:announcements",
        "channel:manage:broadcast",
        "channel:manage:polls",
        "channel:manage:predictions",
    )
}

enum class MsgKind { CHAT, ACTION, SYSTEM }

data class EmoteSpan(val id: String, val start: Int, val end: Int)

data class ChatMsg(
    val id: String,
    val userId: String,
    val login: String,
    val display: String,
    val color: Long?,
    val text: String,
    val emotes: List<EmoteSpan> = emptyList(),
    val isBroadcaster: Boolean = false,
    val isMod: Boolean = false,
    val isVip: Boolean = false,
    val isSub: Boolean = false,
    val firstMsg: Boolean = false,
    val time: Long = System.currentTimeMillis(),
    val kind: MsgKind = MsgKind.CHAT,
    val replyTo: String? = null,
    val mention: Boolean = false,
    val deleted: Boolean = false,
    val punished: String? = null,
    val local: Boolean = false,
)

data class ChannelRef(val id: String, val login: String, val name: String)

data class DeviceCode(
    val deviceCode: String,
    val userCode: String,
    val uri: String,
    val expiresIn: Int,
    val interval: Int,
)

data class ChatSettings(
    val slow: Boolean = false,
    val slowSec: Int = 30,
    val followers: Boolean = false,
    val followersMin: Int = 0,
    val subs: Boolean = false,
    val emote: Boolean = false,
    val unique: Boolean = false,
)

data class ChannelInfo(val title: String, val gameId: String, val gameName: String)
data class Category(val id: String, val name: String, val art: String)
data class StreamInfo(val live: Boolean, val viewers: Int, val startedAt: Long, val gameName: String)

data class PollChoice(val id: String, val title: String, val votes: Int)
data class PollInfo(
    val id: String,
    val title: String,
    val status: String,
    val choices: List<PollChoice>,
    val duration: Int,
    val startedAt: Long,
)

data class Outcome(val id: String, val title: String, val users: Int, val points: Long, val color: String)
data class PredictionInfo(
    val id: String,
    val title: String,
    val status: String,
    val outcomes: List<Outcome>,
    val window: Int,
    val createdAt: Long,
    val winnerId: String?,
)

data class LogEntry(
    val time: Long,
    val channel: String,
    val action: String,
    val target: String,
    val targetId: String,
    val detail: String,
    val ok: Boolean,
    val error: String?,
)

data class Preset(val title: String, val gameId: String, val gameName: String)
data class Template(val title: String, val options: List<String>, val seconds: Int)

data class SelfState(
    val color: Long? = null,
    val isMod: Boolean = false,
    val isBroadcaster: Boolean = false,
    val isVip: Boolean = false,
    val isSub: Boolean = false,
)

data class Prefs(
    val accent: Long = 0xFF9146FF,
    val timeoutSec: Int = 600,
    val swipeRight: String = "delete",
    val swipeLeft: String = "timeout",
    val textSize: Float = 15f,
    val showTime: Boolean = false,
    val keepScreen: Boolean = true,
)
