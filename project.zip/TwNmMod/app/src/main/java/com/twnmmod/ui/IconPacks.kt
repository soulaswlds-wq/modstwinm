package com.twnmmod.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Delete as OutDelete
import androidx.compose.material.icons.outlined.Gavel as OutGavel
import androidx.compose.material.icons.outlined.Timer as OutTimer
import androidx.compose.material.icons.outlined.Warning as OutWarning
import androidx.compose.material.icons.rounded.Delete as RoDelete
import androidx.compose.material.icons.rounded.Gavel as RoGavel
import androidx.compose.material.icons.rounded.Timer as RoTimer
import androidx.compose.material.icons.rounded.Warning as RoWarning
import androidx.compose.material.icons.sharp.Delete as ShDelete
import androidx.compose.material.icons.sharp.Gavel as ShGavel
import androidx.compose.material.icons.sharp.Timer as ShTimer
import androidx.compose.material.icons.sharp.Warning as ShWarning
import androidx.compose.material.icons.twotone.Delete as TwDelete
import androidx.compose.material.icons.twotone.Gavel as TwGavel
import androidx.compose.material.icons.twotone.Timer as TwTimer
import androidx.compose.material.icons.twotone.Warning as TwWarning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Набор для четырёх действий: бан, мут, предупреждение, удалить. Иконки либо текстовые глифы. */
class ModGlyphs(val icons: List<ImageVector>?, val text: List<String>?)

val IconPackOptions = listOf(
    "classic" to "Классика",
    "outlined" to "Контур",
    "rounded" to "Мягкие",
    "sharp" to "Острые",
    "twotone" to "Двухтоновые",
    "emoji" to "Эмодзи",
    "letters" to "Буквы",
)

val IconColorOptions = listOf("colored" to "Цветные", "accent" to "Акцент", "mono" to "Одноцветные")
val IconShapeOptions = listOf("none" to "Без фона", "circle" to "Круг", "square" to "Плашка")

fun packGlyphs(pack: String): ModGlyphs = when (pack) {
    "outlined" -> ModGlyphs(
        listOf(Icons.Outlined.OutGavel, Icons.Outlined.OutTimer, Icons.Outlined.OutWarning, Icons.Outlined.OutDelete), null,
    )
    "rounded" -> ModGlyphs(
        listOf(Icons.Rounded.RoGavel, Icons.Rounded.RoTimer, Icons.Rounded.RoWarning, Icons.Rounded.RoDelete), null,
    )
    "sharp" -> ModGlyphs(
        listOf(Icons.Sharp.ShGavel, Icons.Sharp.ShTimer, Icons.Sharp.ShWarning, Icons.Sharp.ShDelete), null,
    )
    "twotone" -> ModGlyphs(
        listOf(Icons.TwoTone.TwGavel, Icons.TwoTone.TwTimer, Icons.TwoTone.TwWarning, Icons.TwoTone.TwDelete), null,
    )
    "emoji" -> ModGlyphs(null, listOf("🔨", "⏳", "⚠️", "🗑️"))
    "letters" -> ModGlyphs(null, listOf("Б", "М", "П", "У"))
    else -> ModGlyphs(
        listOf(Icons.Filled.Gavel, Icons.Filled.Timer, Icons.Filled.Warning, Icons.Filled.Delete), null,
    )
}

private val ColoredTints = listOf(Color(0xFFFF6B6B), Color(0xFFFFB347), Color(0xFFFFD54F), Color(0xFFC4C4CC))

fun actionTint(index: Int, mode: String, accent: Color, mono: Color): Color = when (mode) {
    "accent" -> accent
    "mono" -> mono
    else -> ColoredTints[index.coerceIn(0, 3)]
}

/** Кнопка действия модерации: иконка или глиф, с фоном-кругом, плашкой или без. */
@Composable
fun GlyphButton(
    glyphs: ModGlyphs,
    index: Int,
    desc: String,
    tint: Color,
    shape: String,
    box: Dp,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val t = if (enabled) tint else tint.copy(alpha = 0.3f)
    val bgShape = if (shape == "circle") CircleShape else RoundedCornerShape(9.dp)
    val look = if (shape == "none") {
        Modifier.size(box).clip(CircleShape)
    } else {
        Modifier.size(box).padding(3.dp).clip(bgShape).background(t.copy(alpha = 0.16f))
    }
    Box(look.clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        val icons = glyphs.icons
        if (icons != null) {
            Icon(icons[index.coerceIn(0, icons.lastIndex)], desc, Modifier.size(box * 0.5f), tint = t)
        } else {
            Text(
                glyphs.text?.getOrNull(index) ?: "",
                fontSize = (box.value * 0.38f).sp,
                fontWeight = FontWeight.Bold,
                color = t,
            )
        }
    }
}
