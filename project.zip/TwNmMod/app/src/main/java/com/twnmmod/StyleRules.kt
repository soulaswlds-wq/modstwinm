package com.twnmmod

import org.json.JSONArray
import org.json.JSONObject

/** Оформление ника и сообщения. null = «не менять». */
data class NickStyle(
    val nameColor: Long? = null,
    val gradA: Long? = null,
    val gradB: Long? = null,
    val bold: Boolean? = null,
    val italic: Boolean? = null,
    val font: String? = null,
    val textColor: Long? = null,
    val bgColor: Long? = null,
    val barColor: Long? = null,
    val prefix: String? = null,
    val scale: Float? = null,
)

data class StyleRule(
    val id: String,
    val title: String,
    val enabled: Boolean,
    val roles: List<String>,
    val users: List<String>,
    val style: NickStyle,
    val builtin: Boolean = false,
)

val RoleOptions = listOf(
    "all" to "Все",
    "broadcaster" to "Стример",
    "mod" to "Модеры",
    "vip" to "VIP",
    "sub" to "Сабы",
    "first" to "Новички",
)

fun roleLabel(r: String): String = RoleOptions.firstOrNull { it.first == r }?.second ?: r

fun ruleMatches(rule: StyleRule, m: ChatMsg): Boolean {
    if (rule.users.any { it.equals(m.login, ignoreCase = true) }) return true
    return rule.roles.any { r ->
        when (r) {
            "all" -> true
            "broadcaster" -> m.isBroadcaster
            "mod" -> m.isMod
            "vip" -> m.isVip
            "sub" -> m.isSub
            "first" -> m.firstMsg
            else -> false
        }
    }
}

fun mergeStyle(b: NickStyle, o: NickStyle): NickStyle {
    var nameColor = b.nameColor
    var gA = b.gradA
    var gB = b.gradB
    if (o.gradA != null && o.gradB != null) {
        gA = o.gradA
        gB = o.gradB
    } else if (o.nameColor != null) {
        nameColor = o.nameColor
        gA = null
        gB = null
    }
    return NickStyle(
        nameColor = nameColor,
        gradA = gA,
        gradB = gB,
        bold = o.bold ?: b.bold,
        italic = o.italic ?: b.italic,
        font = o.font ?: b.font,
        textColor = o.textColor ?: b.textColor,
        bgColor = o.bgColor ?: b.bgColor,
        barColor = o.barColor ?: b.barColor,
        prefix = o.prefix ?: b.prefix,
        scale = o.scale ?: b.scale,
    )
}

/** Правила применяются по порядку в списке: следующие переопределяют предыдущие. */
fun styleFor(m: ChatMsg, rules: List<StyleRule>): NickStyle {
    var r = NickStyle()
    for (rule in rules) {
        if (rule.enabled && ruleMatches(rule, m)) r = mergeStyle(r, rule.style)
    }
    return r
}

fun defaultRules(): List<StyleRule> = listOf(
    StyleRule(
        "sub", "Сабскрайберы", false, listOf("sub"), emptyList(),
        NickStyle(prefix = "✦ ", barColor = 0xFFB388FF), builtin = true,
    ),
    StyleRule(
        "vip", "VIP", true, listOf("vip"), emptyList(),
        NickStyle(gradA = 0xFFFF6EC7, gradB = 0xFFFFC857, bold = true, prefix = "💎 "), builtin = true,
    ),
    StyleRule(
        "mod", "Модераторы", true, listOf("mod"), emptyList(),
        NickStyle(
            gradA = 0xFF00E676, gradB = 0xFF00B0FF, bold = true, prefix = "🛡 ",
            bgColor = 0xFF00E676, barColor = 0xFF00E676,
        ),
        builtin = true,
    ),
    StyleRule(
        "broadcaster", "Стример", true, listOf("broadcaster"), emptyList(),
        NickStyle(
            gradA = 0xFFFF5252, gradB = 0xFFFFC107, bold = true, prefix = "👑 ",
            bgColor = 0xFFFFC107, barColor = 0xFFFFC107,
        ),
        builtin = true,
    ),
    StyleRule(
        "first", "Новички (первое сообщение)", true, listOf("first"), emptyList(),
        NickStyle(prefix = "🆕 ", bgColor = 0xFFFFB300, barColor = 0xFFFFB300), builtin = true,
    ),
    StyleRule(
        "team", "Наша команда (добавь ники)", true, emptyList(), emptyList(),
        NickStyle(gradA = 0xFF00E5FF, gradB = 0xFFB6F442, bold = true, prefix = "🔥 ", barColor = 0xFF00E5FF),
        builtin = true,
    ),
)

private fun JSONObject.putL(k: String, v: Long?) {
    if (v != null) put(k, v)
}

private fun JSONObject.getL(k: String): Long? = if (has(k) && !isNull(k)) optLong(k) else null
private fun JSONObject.getB(k: String): Boolean? = if (has(k) && !isNull(k)) optBoolean(k) else null
private fun JSONObject.getS(k: String): String? = if (has(k) && !isNull(k)) optString(k) else null

fun rulesToJson(list: List<StyleRule>): String {
    val a = JSONArray()
    list.forEach { r ->
        val st = JSONObject()
        st.putL("nc", r.style.nameColor)
        st.putL("ga", r.style.gradA)
        st.putL("gb", r.style.gradB)
        r.style.bold?.let { st.put("b", it) }
        r.style.italic?.let { st.put("i", it) }
        r.style.font?.let { st.put("f", it) }
        st.putL("tc", r.style.textColor)
        st.putL("bg", r.style.bgColor)
        st.putL("br", r.style.barColor)
        r.style.prefix?.let { st.put("p", it) }
        r.style.scale?.let { st.put("sc", it.toDouble()) }
        val roles = JSONArray()
        r.roles.forEach { roles.put(it) }
        val users = JSONArray()
        r.users.forEach { users.put(it) }
        a.put(
            JSONObject().put("id", r.id).put("t", r.title).put("e", r.enabled)
                .put("roles", roles).put("users", users).put("s", st).put("bi", r.builtin)
        )
    }
    return a.toString()
}

fun rulesFromJson(s: String): List<StyleRule>? {
    if (s.isBlank()) return null
    return try {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val st = o.optJSONObject("s") ?: JSONObject()
            val roles = o.optJSONArray("roles")
            val users = o.optJSONArray("users")
            StyleRule(
                id = o.getString("id"),
                title = o.optString("t"),
                enabled = o.optBoolean("e", true),
                roles = (0 until (roles?.length() ?: 0)).map { roles!!.getString(it) },
                users = (0 until (users?.length() ?: 0)).map { users!!.getString(it) },
                style = NickStyle(
                    nameColor = st.getL("nc"), gradA = st.getL("ga"), gradB = st.getL("gb"),
                    bold = st.getB("b"), italic = st.getB("i"), font = st.getS("f"),
                    textColor = st.getL("tc"), bgColor = st.getL("bg"), barColor = st.getL("br"),
                    prefix = st.getS("p"),
                    scale = if (st.has("sc")) st.optDouble("sc").toFloat() else null,
                ),
                builtin = o.optBoolean("bi", false),
            )
        }
    } catch (e: Exception) {
        null
    }
}
