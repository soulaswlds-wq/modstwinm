@file:OptIn(ExperimentalMaterial3Api::class)

package com.twnmmod.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.decode.BitmapFactoryDecoder
import coil.request.ImageRequest
import com.twnmmod.AppViewModel
import com.twnmmod.PickEmote

/** Смайл без анимации (первый кадр): лёгкий для сеток и подсказок. */
@Composable
fun EmoteImage(e: PickEmote, modifier: Modifier) {
    val ctx = LocalContext.current
    val request = remember(e.url) {
        ImageRequest.Builder(ctx).data(e.url).decoderFactory(BitmapFactoryDecoder.Factory()).build()
    }
    AsyncImage(
        model = request,
        contentDescription = e.name,
        modifier = modifier,
        contentScale = ContentScale.Fit,
    )
}

@Composable
fun EmotePanel(vm: AppViewModel, modifier: Modifier, onPick: (PickEmote) -> Unit) {
    val picker by vm.picker.collectAsState()
    val recent by vm.recentEmotes.collectAsState()
    var tab by rememberSaveable { mutableStateOf(if (recent.isNotEmpty()) 0 else 2) }

    val tabs = listOf(
        "Недавние" to recent,
        "Смайлы подписки" to picker.subs,
        "Смайлы канала" to picker.channel,
        "Общедоступные" to picker.global,
    )
    val list = tabs[tab.coerceIn(0, tabs.lastIndex)].second

    Column(modifier) {
        ScrollableTabRow(
            selectedTabIndex = tab.coerceIn(0, tabs.lastIndex),
            containerColor = Color.Transparent,
            edgePadding = 8.dp,
        ) {
            tabs.forEachIndexed { i, (name, items) ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    text = { Text(if (items.isNotEmpty() && i > 0) "$name · ${items.size}" else name) },
                )
            }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (tab == 0) "Здесь появятся смайлы, которые ты используешь" else "Смайлов нет или они ещё загружаются",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp),
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(52.dp),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(list, key = { it.name + it.url }) { e ->
                    EmoteImage(e, Modifier.size(48.dp).clickable { onPick(e) })
                }
            }
        }
    }
}
