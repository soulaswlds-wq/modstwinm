package com.twnmmod

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, message: String, val sessionExpired: Boolean = false) : Exception(message)

object Http {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    val json = "application/json; charset=utf-8".toMediaType()
}

private fun translate(msg: String): String {
    val m = msg.lowercase()
    return when {
        m.contains("missing scope") || m.contains("scope") && m.contains("required") ->
            "Не хватает прав у токена. Выйди из аккаунта и войди заново."
        m.contains("must match") && m.contains("token") ->
            "Это может делать только владелец канала."
        m.contains("offline") || m.contains("not live") ->
            "Клип можно сделать только во время эфира."
        m.contains("already banned") -> "Пользователь уже забанен."
        m.contains("not a moderator") || m.contains("moderator") && m.contains("does not have") ->
            "Нет прав модератора на этом канале."
        m.contains("rate limit") -> "Слишком много запросов, подожди секунду."
        else -> msg
    }
}

fun errorText(body: String, code: Int): String {
    val msg = try {
        JSONObject(body).optString("message", "")
    } catch (e: Exception) {
        ""
    }
    return if (msg.isNotBlank()) translate(msg) else "Ошибка Twitch ($code)"
}

sealed class PollResult {
    object Pending : PollResult()
    object SlowDown : PollResult()
    object Success : PollResult()
    class Failed(val message: String) : PollResult()
}

class Auth(private val store: Store) {
    private val mutex = Mutex()

    /** false, если у текущего токена нет каких-то прав из Config.SCOPES (после обновления приложения). */
    @Volatile var scopesOk: Boolean = true

    private fun hasAllScopes(body: String): Boolean = try {
        val a = JSONObject(body).optJSONArray("scopes")
        if (a == null) {
            true
        } else {
            val have = (0 until a.length()).map { a.getString(it) }.toSet()
            Config.SCOPES.all { it in have }
        }
    } catch (e: Exception) {
        true
    }

    private fun form(vararg p: Pair<String, String>): RequestBody {
        val b = FormBody.Builder()
        p.forEach { b.add(it.first, it.second) }
        return b.build()
    }

    private fun saveTokens(j: JSONObject) {
        store.accessToken = j.getString("access_token")
        store.refreshToken = j.optString("refresh_token", store.refreshToken)
        store.expiresAt = System.currentTimeMillis() + j.optLong("expires_in", 14000L) * 1000L
    }

    suspend fun startDevice(): DeviceCode = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("https://id.twitch.tv/oauth2/device")
            .post(form("client_id" to Config.CLIENT_ID, "scopes" to Config.SCOPES.joinToString(" ")))
            .build()
        Http.client.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException(r.code, errorText(txt, r.code))
            val j = JSONObject(txt)
            DeviceCode(
                j.getString("device_code"),
                j.getString("user_code"),
                j.getString("verification_uri"),
                j.optInt("expires_in", 1800),
                j.optInt("interval", 5),
            )
        }
    }

    suspend fun pollDevice(d: DeviceCode): PollResult = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("https://id.twitch.tv/oauth2/token")
            .post(
                form(
                    "client_id" to Config.CLIENT_ID,
                    "scopes" to Config.SCOPES.joinToString(" "),
                    "device_code" to d.deviceCode,
                    "grant_type" to "urn:ietf:params:oauth:grant-type:device_code",
                )
            ).build()
        Http.client.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (r.isSuccessful) {
                saveTokens(JSONObject(txt))
                PollResult.Success
            } else {
                val m = try {
                    JSONObject(txt).optString("message", "")
                } catch (e: Exception) {
                    ""
                }
                when {
                    m.contains("pending", true) -> PollResult.Pending
                    m.contains("slow", true) -> PollResult.SlowDown
                    else -> PollResult.Failed(m.ifBlank { "Ошибка авторизации (${r.code})" })
                }
            }
        }
    }

    /** Блокирующий вызов; IOException пробрасывается (сеть), false = refresh-токен недействителен. */
    private fun doRefresh(): Boolean {
        val rt = store.refreshToken
        if (rt.isBlank()) return false
        val req = Request.Builder().url("https://id.twitch.tv/oauth2/token")
            .post(
                form(
                    "client_id" to Config.CLIENT_ID,
                    "grant_type" to "refresh_token",
                    "refresh_token" to rt,
                )
            ).build()
        return Http.client.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (r.isSuccessful) {
                saveTokens(JSONObject(txt))
                true
            } else {
                false
            }
        }
    }

    /** stale — токен, с которым пришла ошибка; если он уже заменён другим потоком, повторно не обновляем. */
    suspend fun refresh(stale: String? = null): Boolean = mutex.withLock {
        if (stale != null && store.accessToken != stale && store.accessToken.isNotBlank()) {
            true
        } else {
            withContext(Dispatchers.IO) { doRefresh() }
        }
    }

    suspend fun validToken(): String {
        if (store.accessToken.isBlank()) throw ApiException(401, "Нужно войти в аккаунт", true)
        if (store.expiresAt - System.currentTimeMillis() < 120_000L && store.refreshToken.isNotBlank()) {
            if (!refresh()) throw ApiException(401, "Сессия истекла. Войди заново.", true)
        }
        return store.accessToken
    }

    /** true = токен жив, false = недействителен, null = нет сети / неясно */
    suspend fun validateOnline(): Boolean? = withContext(Dispatchers.IO) {
        val t = store.accessToken
        if (t.isBlank()) return@withContext false
        try {
            val req = Request.Builder().url("https://id.twitch.tv/oauth2/validate")
                .header("Authorization", "OAuth $t").build()
            Http.client.newCall(req).execute().use { r ->
                when (r.code) {
                    200 -> {
                        scopesOk = hasAllScopes(r.body?.string().orEmpty())
                        true
                    }
                    401 -> false
                    else -> null
                }
            }
        } catch (e: java.io.IOException) {
            null
        }
    }

    suspend fun revoke(t: String) = withContext(Dispatchers.IO) {
        if (t.isNotBlank()) {
            try {
                val req = Request.Builder().url("https://id.twitch.tv/oauth2/revoke")
                    .post(form("client_id" to Config.CLIENT_ID, "token" to t)).build()
                Http.client.newCall(req).execute().close()
            } catch (e: Exception) {
            }
        }
    }
}

class Helix(private val auth: Auth) {

    suspend fun call(
        method: String,
        path: String,
        query: List<Pair<String, String>> = emptyList(),
        body: JSONObject? = null,
    ): JSONObject {
        var refreshed = false
        while (true) {
            val token = auth.validToken()
            val b = "https://api.twitch.tv/helix/$path".toHttpUrl().newBuilder()
            query.forEach { b.addQueryParameter(it.first, it.second) }
            val needsBody = method == "POST" || method == "PATCH" || method == "PUT"
            val rb: RequestBody? = when {
                body != null -> body.toString().toRequestBody(Http.json)
                needsBody -> "".toRequestBody(null)
                else -> null
            }
            val req = Request.Builder().url(b.build())
                .header("Authorization", "Bearer $token")
                .header("Client-Id", Config.CLIENT_ID)
                .method(method, rb)
                .build()
            val (code, text) = withContext(Dispatchers.IO) {
                Http.client.newCall(req).execute().use { it.code to it.body?.string().orEmpty() }
            }
            when {
                code == 401 && !refreshed -> {
                    refreshed = true
                    if (!auth.refresh(token)) throw ApiException(401, "Сессия истекла. Войди заново.", true)
                }
                code in 200..299 -> return if (text.isBlank()) JSONObject() else JSONObject(text)
                else -> throw ApiException(code, errorText(text, code), code == 401 && !text.contains("scope", true))
            }
        }
    }

    private fun data(j: JSONObject): JSONArray = j.optJSONArray("data") ?: JSONArray()

    private fun ref(o: JSONObject) =
        ChannelRef(o.getString("id"), o.getString("login"), o.optString("display_name", o.getString("login")))

    suspend fun me(): ChannelRef = ref(data(call("GET", "users")).getJSONObject(0))

    suspend fun userByLogin(login: String): ChannelRef? {
        val l = login.trim().removePrefix("@").lowercase()
        if (l.isEmpty()) return null
        val d = data(call("GET", "users", listOf("login" to l)))
        return if (d.length() == 0) null else ref(d.getJSONObject(0))
    }

    suspend fun moderatedChannels(userId: String): List<ChannelRef> {
        val out = ArrayList<ChannelRef>()
        var cursor: String? = null
        var pages = 0
        do {
            val q = mutableListOf("user_id" to userId, "first" to "100")
            cursor?.let { q.add("after" to it) }
            val j = call("GET", "moderation/channels", q)
            val d = data(j)
            for (i in 0 until d.length()) {
                val o = d.getJSONObject(i)
                out.add(
                    ChannelRef(
                        o.getString("broadcaster_id"),
                        o.getString("broadcaster_login"),
                        o.optString("broadcaster_name", o.getString("broadcaster_login")),
                    )
                )
            }
            cursor = j.optJSONObject("pagination")?.optString("cursor")?.takeIf { it.isNotBlank() }
            pages++
        } while (cursor != null && pages < 10)
        return out
    }

    // ---- модерация ----

    suspend fun ban(b: String, mod: String, userId: String, durationSec: Int?, reason: String) {
        suspend fun send(r: String) {
            val d = JSONObject().put("user_id", userId).put("reason", r.take(500))
            if (durationSec != null) d.put("duration", durationSec)
            call(
                "POST", "moderation/bans",
                listOf("broadcaster_id" to b, "moderator_id" to mod),
                JSONObject().put("data", d),
            )
        }
        try {
            send(reason)
        } catch (e: ApiException) {
            // если Twitch не принял пустую причину, повторяем с минимальной
            if (e.code == 400 && reason.isBlank()) send("-") else throw e
        }
    }

    suspend fun unban(b: String, mod: String, userId: String) {
        call(
            "DELETE", "moderation/bans",
            listOf("broadcaster_id" to b, "moderator_id" to mod, "user_id" to userId),
        )
    }

    suspend fun deleteMessage(b: String, mod: String, messageId: String) {
        call(
            "DELETE", "moderation/chat",
            listOf("broadcaster_id" to b, "moderator_id" to mod, "message_id" to messageId),
        )
    }

    suspend fun clearChat(b: String, mod: String) {
        call("DELETE", "moderation/chat", listOf("broadcaster_id" to b, "moderator_id" to mod))
    }

    suspend fun warn(b: String, mod: String, userId: String, reason: String) {
        call(
            "POST", "moderation/warnings",
            listOf("broadcaster_id" to b, "moderator_id" to mod),
            JSONObject().put(
                "data",
                JSONObject().put("user_id", userId).put("reason", reason.ifBlank { "Предупреждение" }.take(500)),
            ),
        )
    }

    suspend fun announce(b: String, mod: String, message: String, color: String) {
        call(
            "POST", "chat/announcements",
            listOf("broadcaster_id" to b, "moderator_id" to mod),
            JSONObject().put("message", message).put("color", color),
        )
    }

    // ---- настройки чата ----

    suspend fun chatSettings(b: String, mod: String): ChatSettings {
        val d = data(call("GET", "chat/settings", listOf("broadcaster_id" to b, "moderator_id" to mod)))
        if (d.length() == 0) return ChatSettings()
        val o = d.getJSONObject(0)
        val slowSec = if (o.isNull("slow_mode_wait_time")) 30 else o.optInt("slow_mode_wait_time", 30)
        val folMin = if (o.isNull("follower_mode_duration")) 0 else o.optInt("follower_mode_duration", 0)
        return ChatSettings(
            slow = o.optBoolean("slow_mode"),
            slowSec = slowSec.coerceIn(3, 120),
            followers = o.optBoolean("follower_mode"),
            followersMin = folMin,
            subs = o.optBoolean("subscriber_mode"),
            emote = o.optBoolean("emote_mode"),
            unique = o.optBoolean("unique_chat_mode"),
        )
    }

    suspend fun patchChatSettings(b: String, mod: String, body: JSONObject) {
        call("PATCH", "chat/settings", listOf("broadcaster_id" to b, "moderator_id" to mod), body)
    }

    // ---- канал ----

    suspend fun channelInfo(b: String): ChannelInfo? {
        val d = data(call("GET", "channels", listOf("broadcaster_id" to b)))
        if (d.length() == 0) return null
        val o = d.getJSONObject(0)
        return ChannelInfo(o.optString("title"), o.optString("game_id"), o.optString("game_name"))
    }

    suspend fun updateChannel(b: String, title: String?, gameId: String?) {
        val body = JSONObject()
        if (title != null) body.put("title", title)
        if (gameId != null) body.put("game_id", gameId)
        call("PATCH", "channels", listOf("broadcaster_id" to b), body)
    }

    suspend fun searchCategories(q: String): List<Category> {
        val d = data(call("GET", "search/categories", listOf("query" to q, "first" to "12")))
        return (0 until d.length()).map {
            val o = d.getJSONObject(it)
            Category(
                o.getString("id"),
                o.getString("name"),
                o.optString("box_art_url").replace("{width}", "52").replace("{height}", "72"),
            )
        }
    }

    suspend fun userEmotes(userId: String, broadcasterId: String): List<UserEmote> {
        val out = ArrayList<UserEmote>()
        var cursor: String? = null
        var pages = 0
        do {
            val q = mutableListOf("user_id" to userId, "broadcaster_id" to broadcasterId)
            cursor?.let { q.add("after" to it) }
            val j = call("GET", "chat/emotes/user", q)
            val d = data(j)
            for (i in 0 until d.length()) {
                val o = d.getJSONObject(i)
                out.add(UserEmote(o.getString("id"), o.optString("name"), o.optString("emote_type"), o.optString("owner_id")))
            }
            cursor = j.optJSONObject("pagination")?.optString("cursor")?.takeIf { it.isNotBlank() }
            pages++
        } while (cursor != null && pages < 15)
        return out
    }

    suspend fun globalEmotes(): List<UserEmote> {
        val d = data(call("GET", "chat/emotes/global"))
        return (0 until d.length()).map {
            val o = d.getJSONObject(it)
            UserEmote(o.getString("id"), o.optString("name"), "globals", "")
        }
    }

    suspend fun channelEmotes(b: String): List<UserEmote> {
        val d = data(call("GET", "chat/emotes", listOf("broadcaster_id" to b)))
        return (0 until d.length()).map {
            val o = d.getJSONObject(it)
            UserEmote(o.getString("id"), o.optString("name"), o.optString("emote_type", "subscriptions"), b)
        }
    }

    suspend fun topGames(): List<Category> {
        val out = ArrayList<Category>()
        var cursor: String? = null
        var pages = 0
        do {
            val q = mutableListOf("first" to "100")
            cursor?.let { q.add("after" to it) }
            val j = call("GET", "games/top", q)
            val d = data(j)
            for (i in 0 until d.length()) {
                val o = d.getJSONObject(i)
                out.add(
                    Category(
                        o.getString("id"),
                        o.getString("name"),
                        o.optString("box_art_url").replace("{width}", "52").replace("{height}", "72"),
                    )
                )
            }
            cursor = j.optJSONObject("pagination")?.optString("cursor")?.takeIf { it.isNotBlank() }
            pages++
        } while (cursor != null && pages < 2)
        return out
    }

    suspend fun stream(userId: String): StreamInfo {
        val d = data(call("GET", "streams", listOf("user_id" to userId)))
        if (d.length() == 0) return StreamInfo(false, 0, 0L, "")
        val o = d.getJSONObject(0)
        return StreamInfo(true, o.optInt("viewer_count"), parseIso(o.optString("started_at")), o.optString("game_name"))
    }

    // ---- разбан, зрители, список банов ----

    suspend fun unbanRequests(b: String, mod: String): List<UnbanReq> {
        val d = data(
            call(
                "GET", "moderation/unban_requests",
                listOf("broadcaster_id" to b, "moderator_id" to mod, "status" to "pending", "first" to "50"),
            )
        )
        return (0 until d.length()).map {
            val o = d.getJSONObject(it)
            val login = o.optString("user_login")
            UnbanReq(
                o.getString("id"), o.optString("user_id"), login,
                o.optString("user_name", login), o.optString("text"), parseIso(o.optString("created_at")),
            )
        }
    }

    suspend fun resolveUnban(b: String, mod: String, id: String, approve: Boolean, text: String) {
        val status = if (approve) "approved" else "denied"
        val q = mutableListOf(
            "broadcaster_id" to b, "moderator_id" to mod, "unban_request_id" to id, "status" to status,
        )
        if (text.isNotBlank()) q.add("resolution_text" to text.take(500))
        call("PATCH", "moderation/unban_requests", q)
    }

    /** Только постоянные баны (для поиска обхода по похожим никам). */
    suspend fun bannedLogins(b: String): List<String> {
        val out = ArrayList<String>()
        var cursor: String? = null
        var pages = 0
        do {
            val q = mutableListOf("broadcaster_id" to b, "first" to "100")
            cursor?.let { q.add("after" to it) }
            val j = call("GET", "moderation/banned", q)
            val d = data(j)
            for (i in 0 until d.length()) {
                val o = d.getJSONObject(i)
                if (o.optString("expires_at").isBlank()) out.add(o.optString("user_login").lowercase())
            }
            cursor = j.optJSONObject("pagination")?.optString("cursor")?.takeIf { it.isNotBlank() }
            pages++
        } while (cursor != null && pages < 20)
        return out
    }

    suspend fun chatters(b: String, mod: String): Pair<List<Viewer>, Int> {
        val out = ArrayList<Viewer>()
        var total = 0
        var cursor: String? = null
        var pages = 0
        do {
            val q = mutableListOf("broadcaster_id" to b, "moderator_id" to mod, "first" to "1000")
            cursor?.let { q.add("after" to it) }
            val j = call("GET", "chat/chatters", q)
            total = j.optInt("total", total)
            val d = data(j)
            for (i in 0 until d.length()) {
                val o = d.getJSONObject(i)
                val login = o.optString("user_login")
                out.add(Viewer(o.optString("user_id"), login, o.optString("user_name", login)))
            }
            cursor = j.optJSONObject("pagination")?.optString("cursor")?.takeIf { it.isNotBlank() }
            pages++
        } while (cursor != null && pages < 5)
        return out to total
    }

    // ---- AutoMod / щит / слова / шаутаут / рейд ----

    suspend fun automod(mod: String, msgId: String, allow: Boolean) {
        call(
            "POST", "moderation/automod/message", emptyList(),
            JSONObject().put("user_id", mod).put("msg_id", msgId).put("action", if (allow) "ALLOW" else "DENY"),
        )
    }

    suspend fun subscribe(type: String, version: String, condition: JSONObject, sessionId: String) {
        call(
            "POST", "eventsub/subscriptions", emptyList(),
            JSONObject().put("type", type).put("version", version).put("condition", condition)
                .put("transport", JSONObject().put("method", "websocket").put("session_id", sessionId)),
        )
    }

    suspend fun shield(b: String, mod: String): Boolean {
        val d = data(call("GET", "moderation/shield_mode", listOf("broadcaster_id" to b, "moderator_id" to mod)))
        return d.length() > 0 && d.getJSONObject(0).optBoolean("is_active")
    }

    suspend fun setShield(b: String, mod: String, on: Boolean) {
        call(
            "PUT", "moderation/shield_mode",
            listOf("broadcaster_id" to b, "moderator_id" to mod),
            JSONObject().put("is_active", on),
        )
    }

    suspend fun blockedTerms(b: String, mod: String): List<Pair<String, String>> {
        val d = data(call("GET", "moderation/blocked_terms", listOf("broadcaster_id" to b, "moderator_id" to mod, "first" to "100")))
        return (0 until d.length()).map {
            val o = d.getJSONObject(it)
            o.getString("id") to o.optString("text")
        }
    }

    suspend fun addBlockedTerm(b: String, mod: String, text: String) {
        call(
            "POST", "moderation/blocked_terms",
            listOf("broadcaster_id" to b, "moderator_id" to mod),
            JSONObject().put("text", text),
        )
    }

    suspend fun removeBlockedTerm(b: String, mod: String, id: String) {
        call("DELETE", "moderation/blocked_terms", listOf("broadcaster_id" to b, "moderator_id" to mod, "id" to id))
    }

    suspend fun shoutout(from: String, to: String, mod: String) {
        call(
            "POST", "chat/shoutouts",
            listOf("from_broadcaster_id" to from, "to_broadcaster_id" to to, "moderator_id" to mod),
        )
    }

    suspend fun raid(from: String, to: String) {
        call("POST", "raids", listOf("from_broadcaster_id" to from, "to_broadcaster_id" to to))
    }

    suspend fun cancelRaid(b: String) {
        call("DELETE", "raids", listOf("broadcaster_id" to b))
    }

    suspend fun userCreated(id: String): Long {
        val d = data(call("GET", "users", listOf("id" to id)))
        return if (d.length() == 0) 0L else parseIso(d.getJSONObject(0).optString("created_at"))
    }

    /** null = не фолловер */
    suspend fun followedAt(b: String, userId: String): Long? {
        val d = data(call("GET", "channels/followers", listOf("broadcaster_id" to b, "user_id" to userId)))
        return if (d.length() == 0) null else parseIso(d.getJSONObject(0).optString("followed_at"))
    }

    // ---- клипы ----

    suspend fun createClip(b: String): String {
        val d = data(call("POST", "clips", listOf("broadcaster_id" to b)))
        if (d.length() == 0) throw ApiException(500, "Twitch не вернул клип")
        return d.getJSONObject(0).getString("id")
    }

    suspend fun clipExists(id: String): Boolean = data(call("GET", "clips", listOf("id" to id))).length() > 0

    // ---- опросы ----

    private fun parsePoll(o: JSONObject): PollInfo {
        val cs = o.getJSONArray("choices")
        val choices = (0 until cs.length()).map {
            val c = cs.getJSONObject(it)
            PollChoice(c.getString("id"), c.getString("title"), c.optInt("votes"))
        }
        return PollInfo(
            o.getString("id"), o.getString("title"), o.getString("status"), choices,
            o.optInt("duration"), parseIso(o.optString("started_at")),
        )
    }

    suspend fun latestPoll(b: String): PollInfo? {
        val d = data(call("GET", "polls", listOf("broadcaster_id" to b, "first" to "1")))
        return if (d.length() == 0) null else parsePoll(d.getJSONObject(0))
    }

    suspend fun createPoll(b: String, title: String, choices: List<String>, seconds: Int) {
        val arr = JSONArray()
        choices.forEach { arr.put(JSONObject().put("title", it)) }
        call(
            "POST", "polls", emptyList(),
            JSONObject().put("broadcaster_id", b).put("title", title).put("choices", arr).put("duration", seconds),
        )
    }

    suspend fun endPoll(b: String, id: String, archive: Boolean) {
        call(
            "PATCH", "polls", emptyList(),
            JSONObject().put("broadcaster_id", b).put("id", id).put("status", if (archive) "ARCHIVED" else "TERMINATED"),
        )
    }

    // ---- прогнозы (ставки) ----

    private fun parsePrediction(o: JSONObject): PredictionInfo {
        val os = o.getJSONArray("outcomes")
        val outs = (0 until os.length()).map {
            val c = os.getJSONObject(it)
            Outcome(c.getString("id"), c.getString("title"), c.optInt("users"), c.optLong("channel_points"), c.optString("color"))
        }
        return PredictionInfo(
            o.getString("id"), o.getString("title"), o.getString("status"), outs,
            o.optInt("prediction_window"), parseIso(o.optString("created_at")),
            if (o.isNull("winning_outcome_id")) null else o.optString("winning_outcome_id"),
        )
    }

    suspend fun latestPrediction(b: String): PredictionInfo? {
        val d = data(call("GET", "predictions", listOf("broadcaster_id" to b, "first" to "1")))
        return if (d.length() == 0) null else parsePrediction(d.getJSONObject(0))
    }

    suspend fun createPrediction(b: String, title: String, outcomes: List<String>, seconds: Int) {
        val arr = JSONArray()
        outcomes.forEach { arr.put(JSONObject().put("title", it)) }
        call(
            "POST", "predictions", emptyList(),
            JSONObject().put("broadcaster_id", b).put("title", title).put("outcomes", arr).put("prediction_window", seconds),
        )
    }

    suspend fun patchPrediction(b: String, id: String, status: String, winnerId: String?) {
        val body = JSONObject().put("broadcaster_id", b).put("id", id).put("status", status)
        if (winnerId != null) body.put("winning_outcome_id", winnerId)
        call("PATCH", "predictions", emptyList(), body)
    }
}
