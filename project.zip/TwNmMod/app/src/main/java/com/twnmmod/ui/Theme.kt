@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

val AccentChoices: List<Pair<String, Long>> = listOf(
    "Фиолетовый" to 0xFF9146FF,
    "Мята" to 0xFF00E5A8,
    "Синий" to 0xFF3B9BFF,
    "Розовый" to 0xFFFF5C9D,
    "Оранжевый" to 0xFFFF8A3D,
    "Лайм" to 0xFFB6F442,
)

@Composable
fun AppTheme(accent: Color, content: @Composable () -> Unit) {
    val bg = Color(0xFF0E0E10)
    val surface = Color(0xFF18181B)
    val variant = Color(0xFF232329)
    val onAccent = if (accent.luminance() > 0.45f) Color.Black else Color.White
    val scheme = darkColorScheme(
        primary = accent,
        onPrimary = onAccent,
        primaryContainer = lerp(surface, accent, 0.30f),
        onPrimaryContainer = Color.White,
        secondary = accent,
        onSecondary = onAccent,
        secondaryContainer = lerp(variant, accent, 0.25f),
        onSecondaryContainer = Color.White,
        background = bg,
        onBackground = Color(0xFFEFEFF1),
        surface = surface,
        onSurface = Color(0xFFEFEFF1),
        surfaceVariant = variant,
        onSurfaceVariant = Color(0xFFADADB8),
        error = Color(0xFFFF6B6B),
        onError = Color.Black,
        errorContainer = Color(0xFF4A1F22),
        onErrorContainer = Color(0xFFFFD9D9),
        outline = Color(0xFF3A3A44),
        outlineVariant = Color(0xFF2F2F38),
    )
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(24.dp),
        ),
        content = content,
    )
}

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )
            content()
        }
    }
}

@Composable
fun NoteCard(text: String, error: Boolean = false) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (error) MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Text(
            text,
            Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = if (error) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun <T> ChipChoice(
    options: List<Pair<String, T>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    FlowRow(
        modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEach { (label, value) ->
            FilterChip(
                selected = value == selected,
                onClick = { onSelect(value) },
                label = { Text(label) },
            )
        }
    }
}
