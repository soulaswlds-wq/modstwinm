@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

val AccentChoices: List<Pair<String, Long>> = listOf(
    "Фиолетовый" to 0xFF9146FF,
    "Мята" to 0xFF00E5A8,
    "Синий" to 0xFF3B9BFF,
    "Розовый" to 0xFFFF5C9D,
    "Оранжевый" to 0xFFFF8A3D,
    "Лайм" to 0xFFB6F442,
)

/** Готовая тема: фон (градиент + мягкие «блики»), поверхности, акцент и скругления. */
data class ThemeDef(
    val id: String,
    val name: String,
    val top: Color,
    val bottom: Color,
    val glowA: Color?,
    val glowB: Color?,
    val gradient: Boolean,
    val surface: Color,
    val variant: Color,
    val accent: Long,
    val rounding: String,
    val glass: Boolean,
)

val Themes: List<ThemeDef> = listOf(
    ThemeDef(
        "glass", "Стекло", Color(0xFF090D22), Color(0xFF1A0F3A),
        Color(0x593D5AFE), Color(0x4DB04DFF), true,
        Color(0x8C1B2140), Color(0x802A3160), 0xFF8FA8FF, "round", true,
    ),
    ThemeDef(
        "material", "Материал", Color(0xFF141218), Color(0xFF141218),
        null, null, false,
        Color(0xFF1D1B20), Color(0xFF2B2930), 0xFFD0BCFF, "normal", false,
    ),
    ThemeDef(
        "sakura", "Сакура", Color(0xFF1B0F16), Color(0xFF2E1624),
        Color(0x38FF7EB6), Color(0x1FFFB3D1), true,
        Color(0xD92A1722), Color(0xD93A2030), 0xFFFF9EC7, "round", false,
    ),
    ThemeDef(
        "aurora", "Аврора", Color(0xFF04141A), Color(0xFF0A2630),
        Color(0x3800E5A8), Color(0x333B9BFF), true,
        Color(0xD60E2630), Color(0xD615343F), 0xFF4DFFC3, "round", false,
    ),
    ThemeDef(
        "sunset", "Закат", Color(0xFF1A0B14), Color(0xFF2D1220),
        Color(0x40FF7A45), Color(0x2EFF3D81), true,
        Color(0xD92A1420), Color(0xD93A1D2C), 0xFFFF8A5B, "normal", false,
    ),
    ThemeDef(
        "luxe", "Люкс", Color(0xFF0A0A0A), Color(0xFF15120B),
        Color(0x1AE6C068), null, true,
        Color(0xFF141414), Color(0xFF1F1D18), 0xFFE6C068, "sharp", false,
    ),
)

fun themeById(id: String): ThemeDef? = Themes.firstOrNull { it.id == id }

val LocalGlass = compositionLocalOf { false }

/** Фон для градиентных тем: вертикальный градиент и два статичных «блика». Рисуется один раз. */
@Composable
fun ThemeBackdrop(themeId: String, modifier: Modifier = Modifier) {
    val def = themeById(themeId)
    if (def == null || !def.gradient) return
    Box(
        modifier
            .background(Brush.verticalGradient(listOf(def.top, def.bottom)))
            .drawBehind {
                def.glowA?.let {
                    drawRect(
                        brush = Brush.radialGradient(
                            listOf(it, Color.Transparent),
                            center = Offset(size.width * 0.1f, size.height * 0.08f),
                            radius = size.width * 1.1f,
                        ),
                    )
                }
                def.glowB?.let {
                    drawRect(
                        brush = Brush.radialGradient(
                            listOf(it, Color.Transparent),
                            center = Offset(size.width * 0.95f, size.height * 0.85f),
                            radius = size.width * 1.2f,
                        ),
                    )
                }
            }
    )
}

@Composable
fun AppTheme(accent: Color, background: String, rounding: String, themeId: String, content: @Composable () -> Unit) {
    val def = themeById(themeId)
    val bg: Color
    val surface: Color
    val variant: Color
    if (def != null) {
        bg = if (def.gradient) Color.Transparent else def.top
        surface = def.surface
        variant = def.variant
    } else {
        when (background) {
            "amoled" -> {
                bg = Color(0xFF000000); surface = Color(0xFF0B0B0C); variant = Color(0xFF171718)
            }
            "navy" -> {
                bg = Color(0xFF0A0F1E); surface = Color(0xFF111A2E); variant = Color(0xFF1A2540)
            }
            "wine" -> {
                bg = Color(0xFF140A12); surface = Color(0xFF1E1118); variant = Color(0xFF2C1824)
            }
            else -> {
                bg = Color(0xFF0E0E10); surface = Color(0xFF18181B); variant = Color(0xFF232329)
            }
        }
    }
    val round = def?.rounding ?: rounding
    val (rs, rm, rl) = when (round) {
        "sharp" -> Triple(4, 6, 10)
        "round" -> Triple(16, 24, 32)
        else -> Triple(10, 16, 24)
    }
    val onAccent = if (accent.luminance() > 0.45f) Color.Black else Color.White
    // непрозрачные версии для листов, меню и диалогов
    val solidSurface = surface.copy(alpha = 1f)
    val solidVariant = variant.copy(alpha = 1f)
    val scheme = darkColorScheme(
        primary = accent,
        onPrimary = onAccent,
        primaryContainer = lerp(solidSurface, accent, 0.30f),
        onPrimaryContainer = Color.White,
        secondary = accent,
        onSecondary = onAccent,
        secondaryContainer = lerp(solidVariant, accent, 0.25f),
        onSecondaryContainer = Color.White,
        background = bg,
        onBackground = Color(0xFFEFEFF1),
        surface = surface,
        onSurface = Color(0xFFEFEFF1),
        surfaceVariant = variant,
        onSurfaceVariant = Color(0xFFB4B4C0),
        surfaceContainerLowest = solidSurface,
        surfaceContainerLow = solidSurface,
        surfaceContainer = solidSurface,
        surfaceContainerHigh = solidVariant,
        surfaceContainerHighest = solidVariant,
        error = Color(0xFFFF6B6B),
        onError = Color.Black,
        errorContainer = Color(0xFF4A1F22),
        onErrorContainer = Color(0xFFFFD9D9),
        outline = Color(0xFF3A3A44),
        outlineVariant = Color(0xFF2F2F38),
    )
    CompositionLocalProvider(LocalGlass provides (def?.glass == true)) {
        MaterialTheme(
            colorScheme = scheme,
            shapes = Shapes(
                small = RoundedCornerShape(rs.dp),
                medium = RoundedCornerShape(rm.dp),
                large = RoundedCornerShape(rl.dp),
            ),
            content = content,
        )
    }
}

/** Тонкая светлая рамка для «стеклянной» темы, для остальных ничего. */
@Composable
fun glassBorder(): BorderStroke? =
    if (LocalGlass.current) BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)) else null

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = glassBorder(),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )
            content()
        }
    }
}

@Composable
fun NoteCard(text: String, error: Boolean = false) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (error) MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Text(
            text,
            Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = if (error) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun <T> ChipChoice(
    options: List<Pair<String, T>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    FlowRow(
        modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEach { (label, value) ->
            FilterChip(
                selected = value == selected,
                onClick = { onSelect(value) },
                label = { Text(label) },
            )
        }
    }
}
