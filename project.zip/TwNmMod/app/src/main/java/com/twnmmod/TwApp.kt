package com.twnmmod

import android.app.Application
import android.content.Context
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import java.io.File

data class CrashReport(val text: String, val wasReset: Boolean)

class TwApp : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components {
            if (Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory()) else add(GifDecoder.Factory())
        }
        .build()

    override fun onCreate() {
        super.onCreate()
        val boot = getSharedPreferences("boot", MODE_PRIVATE)
        val last = boot.getLong("lastLaunch", 0L)
        val crashAt = boot.getLong("crashAt", 0L)
        // Сбой сразу после запуска -> сбрасываем сохранённые данные, чтобы разорвать цикл падений
        if (crashAt > last && crashAt - last < 20_000L) {
            getSharedPreferences("twnmmod", MODE_PRIVATE).edit().clear().commit()
            boot.edit().putBoolean("wasReset", true).commit()
        }
        boot.edit().putLong("lastLaunch", System.currentTimeMillis()).commit()

        val file = File(filesDir, "crash.txt")
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val ver = try {
                    packageManager.getPackageInfo(packageName, 0).versionName
                } catch (x: Exception) {
                    "?"
                }
                file.writeText(
                    "TwNmMod $ver, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), " +
                        "${Build.MANUFACTURER} ${Build.MODEL}\n" + android.util.Log.getStackTraceString(e)
                )
                boot.edit().putLong("crashAt", System.currentTimeMillis()).commit()
            } catch (x: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }

    companion object {
        fun readCrash(ctx: Context): CrashReport? {
            val f = File(ctx.filesDir, "crash.txt")
            if (!f.exists()) return null
            val text = try {
                f.readText().take(6000)
            } catch (e: Exception) {
                return null
            }
            val reset = ctx.getSharedPreferences("boot", MODE_PRIVATE).getBoolean("wasReset", false)
            return CrashReport(text, reset)
        }

        fun clearCrash(ctx: Context) {
            File(ctx.filesDir, "crash.txt").delete()
            ctx.getSharedPreferences("boot", MODE_PRIVATE).edit().putBoolean("wasReset", false).apply()
        }
    }
}
