@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.twnmmod.ui

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twnmmod.AppViewModel
import com.twnmmod.ChatMsg
import com.twnmmod.MsgKind
import com.twnmmod.NickStyle
import com.twnmmod.Prefs
import com.twnmmod.RoleOptions
import com.twnmmod.StyleRule
import com.twnmmod.roleLabel
import kotlin.math.abs

// ---------------------------------------------------------------- темы

@Composable
fun ThemesCard(p: Prefs, vm: AppViewModel) {
    SectionCard("Темы") {
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ThemeSwatch("Классика", Color(0xFF0E0E10), Color(0xFF2A2A33), p.themeId == "classic") {
                vm.updatePrefs { it.copy(themeId = "classic") }
            }
            Themes.forEach { t ->
                ThemeSwatch(t.name, t.top, t.bottom.copy(alpha = 1f), p.themeId == t.id, accent = Color(t.accent)) {
                    vm.updatePrefs { it.copy(themeId = t.id, accent = t.accent, rounding = t.rounding) }
                }
            }
        }
        Text(
            "Тема задаёт фон, поверхности, скругления и цвет акцента. Акцент потом можно поменять отдельно. " +
                "«Классика» использует фон и скругления из раздела «Оформление» ниже.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ThemeSwatch(name: String, top: Color, bottom: Color, selected: Boolean, accent: Color? = null, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp).clickable { onClick() }) {
        Box(
            Modifier
                .size(width = 76.dp, height = 54.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(top.copy(alpha = 1f), bottom)))
                .border(
                    if (selected) 2.dp else 1.dp,
                    if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.12f),
                    RoundedCornerShape(14.dp),
                ),
            contentAlignment = Alignment.BottomEnd,
        ) {
            if (accent != null) {
                Box(Modifier.padding(6.dp).size(14.dp).background(accent, CircleShape))
            }
            if (selected) {
                Icon(Icons.Filled.Check, null, Modifier.align(Alignment.TopStart).padding(4.dp).size(16.dp), tint = Color.White)
            }
        }
        Text(name, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

// ---------------------------------------------------------------- события, анимации

@Composable
fun EventsCard(p: Prefs, vm: AppViewModel) {
    SectionCard("Карточки событий в чате") {
        ChipChoice(
            listOf("Мягкие" to "soft", "Контурные" to "outline", "Компактные" to "compact"),
            p.eventStyle,
            { v -> vm.updatePrefs { it.copy(eventStyle = v) } },
        )
        val now = System.currentTimeMillis()
        val samples = listOf(
            ChatMsg(
                id = "demo-sub", userId = "", login = "demo", display = "neomelin_", color = null,
                text = "спасибо за стрим, ты лучший!", kind = MsgKind.SYSTEM, time = 0L,
                eventKind = "resub", eventTitle = "neomelin_ продлил подписку · 12 мес. · Tier 1",
            ),
            ChatMsg(
                id = "demo-raid", userId = "", login = "demo", display = "Streamer", color = null,
                text = "", kind = MsgKind.SYSTEM, time = 0L,
                eventKind = "raid", eventTitle = "Рейд от Streamer · 148 зрителей",
            ),
            ChatMsg(
                id = "demo-ban", userId = "", login = "demo", display = "x", color = null,
                text = "", kind = MsgKind.SYSTEM, time = 0L,
                eventKind = "ban", eventTitle = "@spammer · бан",
            ),
            ChatMsg(
                id = "demo-follow", userId = "", login = "demo", display = "x", color = null,
                text = "", kind = MsgKind.SYSTEM, time = 0L + now * 0,
                eventKind = "follow", eventTitle = "Gel1x теперь фолловер",
            ),
        )
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            samples.forEach { EventCard(it, p.copy(animLevel = "off"), null) }
        }
        Text(
            "Так выглядят подписки, подарки, рейды, фолловеры, биты, объявления, баны и очистка чата.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun AnimationsCard(p: Prefs, vm: AppViewModel) {
    SectionCard("Анимации и отклик") {
        Text("Анимации")
        ChipChoice(
            listOf("Выкл" to "off", "Лёгкие" to "normal", "Богатые" to "rich"),
            p.animLevel,
            { v -> vm.updatePrefs { it.copy(animLevel = v) } },
        )
        Text(
            "Лёгкие: плавное появление сообщений. Богатые: ещё и мягкий «въезд» карточек событий. " +
                "Всё считается на видеокарте и почти не расходует батарею. В тяжёлом чате ставь «Выкл».",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SwitchLine("Лёгкая вибрация на значках модерации", p.haptics) { v -> vm.updatePrefs { it.copy(haptics = v) } }
        SwitchLine("Темп чата над сообщениями", p.showTempo) { v -> vm.updatePrefs { it.copy(showTempo = v) } }
    }
}

@Composable
private fun SwitchLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ---------------------------------------------------------------- наборы значков

@Composable
fun IconPackCard(p: Prefs, vm: AppViewModel) {
    SectionCard("Набор значков модерации") {
        Text("Набор")
        ChipChoice(IconPackOptions, p.iconPack, { v -> vm.updatePrefs { it.copy(iconPack = v) } })
        Text("Цвета")
        ChipChoice(IconColorOptions, p.iconColors, { v -> vm.updatePrefs { it.copy(iconColors = v) } })
        Text("Фон значка")
        ChipChoice(IconShapeOptions, p.iconShape, { v -> vm.updatePrefs { it.copy(iconShape = v) } })
        val glyphs = remember(p.iconPack) { packGlyphs(p.iconPack) }
        val accent = MaterialTheme.colorScheme.primary
        val mono = MaterialTheme.colorScheme.onSurfaceVariant
        val box = when (p.iconSize) {
            "small" -> 30.dp
            "large" -> 42.dp
            else -> 34.dp
        }
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Предпросмотр:", modifier = Modifier.padding(end = 8.dp), style = MaterialTheme.typography.bodySmall)
            val names = listOf("Бан", "Мут", "Предупреждение", "Удалить")
            names.forEachIndexed { i, n ->
                GlyphButton(glyphs, i, n, actionTint(i, p.iconColors, accent, mono), p.iconShape, box) {}
            }
        }
    }
}

// ---------------------------------------------------------------- иконка приложения

private val IconAliases = listOf(
    "IconPurple" to "Фиолетовая",
    "IconMint" to "Мятная",
    "IconPink" to "Розовая",
    "IconOrange" to "Оранжевая",
)

private fun isIconActive(ctx: Context, name: String): Boolean {
    val st = ctx.packageManager.getComponentEnabledSetting(ComponentName(ctx.packageName, "com.twnmmod.$name"))
    return st == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
        (st == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && name == "IconPurple")
}

private fun switchIcon(ctx: Context, name: String) {
    val pm = ctx.packageManager
    // сначала включаем выбранную, потом выключаем остальные: у приложения всегда есть значок
    pm.setComponentEnabledSetting(
        ComponentName(ctx.packageName, "com.twnmmod.$name"),
        PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
        PackageManager.DONT_KILL_APP,
    )
    IconAliases.forEach { (n, _) ->
        if (n != name) {
            pm.setComponentEnabledSetting(
                ComponentName(ctx.packageName, "com.twnmmod.$n"),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
    }
}

@Composable
fun AppIconCard() {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf(IconAliases.firstOrNull { isIconActive(ctx, it.first) }?.first ?: "IconPurple") }
    SectionCard("Значок приложения") {
        ChipChoice(
            IconAliases.map { it.second to it.first },
            selected,
            { n ->
                try {
                    switchIcon(ctx, n)
                    selected = n
                } catch (e: Exception) {
                }
            },
        )
        Text(
            "Значок на рабочем столе поменяется через несколько секунд. На некоторых лаунчерах нужно подождать или " +
                "перезапустить рабочий стол.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ---------------------------------------------------------------- стили ников и сообщений

private val Swatches = listOf(
    0xFFFF5252, 0xFFFF7043, 0xFFFFB300, 0xFFFFEB3B, 0xFFB6F442, 0xFF00E676, 0xFF00E5FF, 0xFF3B9BFF,
    0xFF7C4DFF, 0xFFB388FF, 0xFFFF6EC7, 0xFFFFFFFF, 0xFFB0B0BA, 0xFF8D6E63,
)

private val Emojis = listOf("🛡", "💎", "👑", "🔥", "⭐", "🆕", "⚡", "🎯", "🌸", "❤️", "🧿", "🎮")

/** Собирает строку ника и сообщения в выбранном стиле: используется в предпросмотре. */
private fun previewText(st: NickStyle, name: String, text: String): AnnotatedString = buildAnnotatedString {
    st.prefix?.let { append(it) }
    val weight = if (st.bold == false) FontWeight.Normal else FontWeight.Bold
    val italic = if (st.italic == true) FontStyle.Italic else null
    val family: FontFamily? = when (st.font) {
        "serif" -> FontFamily.Serif
        "mono" -> FontFamily.Monospace
        "cursive" -> FontFamily.Cursive
        "sans" -> FontFamily.SansSerif
        else -> null
    }
    val ga = st.gradA
    val gb = st.gradB
    if (ga != null && gb != null) {
        withStyle(
            SpanStyle(
                brush = Brush.horizontalGradient(listOf(Color(ga), Color(gb))),
                fontWeight = weight, fontStyle = italic, fontFamily = family,
            )
        ) { append(name) }
    } else {
        val c = st.nameColor?.let { Color(it) } ?: Color(0xFFB388FF)
        withStyle(SpanStyle(color = c, fontWeight = weight, fontStyle = italic, fontFamily = family)) { append(name) }
    }
    append(": ")
    val tc = st.textColor?.let { Color(it) } ?: Color.Unspecified
    withStyle(SpanStyle(color = tc)) { append(text) }
}

@Composable
fun StylePreview(st: NickStyle, modifier: Modifier = Modifier) {
    val bar = st.barColor
    val tint = st.bgColor?.let { Color(it).copy(alpha = 0.09f) } ?: Color.Transparent
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f))
            .background(tint)
            .then(
                if (bar != null) {
                    Modifier.drawBehind { drawRect(Color(bar), size = Size(3.dp.toPx(), size.height)) }
                } else {
                    Modifier
                }
            )
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(previewText(st, "neomelin_", "привет всем, как дела?"), fontSize = (15f * (st.scale ?: 1f)).sp)
    }
}

private fun whoText(r: StyleRule): String {
    val parts = ArrayList<String>()
    if (r.roles.isNotEmpty()) parts.add(r.roles.joinToString(", ") { roleLabel(it) })
    if (r.users.isNotEmpty()) parts.add(r.users.joinToString(", ") { "@$it" })
    return if (parts.isEmpty()) "Пока никому: добавь роли или ники" else parts.joinToString(" + ")
}

@Composable
fun RulesCard(vm: AppViewModel) {
    val rules by vm.styleRules.collectAsState()
    var editing by remember { mutableStateOf<StyleRule?>(null) }

    SectionCard("Стили ников и сообщений") {
        Text(
            "Для каждой группы можно сделать свой вид ника и сообщения. Правила применяются сверху вниз: нижние " +
                "переопределяют верхние. Можно создавать свои правила для любых групп и для конкретных людей.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        rules.forEachIndexed { i, r ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = r.enabled, onCheckedChange = { vm.toggleRule(r.id, it) })
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.title, fontWeight = FontWeight.Bold)
                            Text(
                                whoText(r),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { vm.moveRule(r.id, -1) }, enabled = i > 0) {
                            Icon(Icons.Filled.KeyboardArrowUp, "Выше")
                        }
                        IconButton(onClick = { vm.moveRule(r.id, 1) }, enabled = i < rules.lastIndex) {
                            Icon(Icons.Filled.KeyboardArrowDown, "Ниже")
                        }
                        IconButton(onClick = { editing = r }) { Icon(Icons.Filled.Edit, "Править") }
                    }
                    StylePreview(r.style)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                editing = StyleRule(
                    id = "u${System.currentTimeMillis()}",
                    title = "Новое правило",
                    enabled = true,
                    roles = emptyList(),
                    users = emptyList(),
                    style = NickStyle(bold = true),
                )
            }) { Text("Добавить правило") }
            OutlinedButton(onClick = { vm.resetRules() }) { Text("Сбросить") }
        }
    }

    editing?.let { r ->
        RuleEditor(
            rule = r,
            isNew = rules.none { it.id == r.id },
            onSave = {
                vm.saveRule(it)
                editing = null
            },
            onDelete = {
                vm.deleteRule(r.id)
                editing = null
            },
            onDismiss = { editing = null },
        )
    }
}

@Composable
private fun ColorRow(label: String, value: Long?, onChange: (Long?) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(32.dp)
                    .border(
                        if (value == null) 2.dp else 1.dp,
                        if (value == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        CircleShape,
                    )
                    .clickable { onChange(null) },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Close, "Нет", Modifier.size(16.dp)) }
            Swatches.forEach { c ->
                Box(
                    Modifier
                        .size(32.dp)
                        .background(Color(c), CircleShape)
                        .border(
                            if (value == c) 3.dp else 1.dp,
                            if (value == c) Color.White else Color.White.copy(alpha = 0.2f),
                            CircleShape,
                        )
                        .clickable { onChange(c) },
                )
            }
        }
    }
}

@Composable
private fun RuleEditor(
    rule: StyleRule,
    isNew: Boolean,
    onSave: (StyleRule) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var title by remember { mutableStateOf(rule.title) }
    var roles by remember { mutableStateOf(rule.roles) }
    var users by remember { mutableStateOf(rule.users.joinToString(", ")) }
    var st by remember { mutableStateOf(rule.style) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Правило оформления", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            StylePreview(st)

            OutlinedTextField(
                value = title,
                onValueChange = { if (it.length <= 40) title = it },
                label = { Text("Название") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Кому применять", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                RoleOptions.forEach { (key, label) ->
                    FilterChip(
                        selected = key in roles,
                        onClick = { roles = if (key in roles) roles - key else roles + key },
                        label = { Text(label) },
                    )
                }
            }
            OutlinedTextField(
                value = users,
                onValueChange = { users = it.take(400) },
                label = { Text("Конкретные ники через запятую") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
            )

            ColorRow("Цвет ника", st.nameColor) { c ->
                st = if (c == null) st.copy(nameColor = null) else st.copy(nameColor = c, gradA = null, gradB = null)
            }
            ColorRow("Градиент ника: начало", st.gradA) { c ->
                st = st.copy(gradA = c, gradB = if (c != null && st.gradB == null) c else st.gradB)
            }
            ColorRow("Градиент ника: конец", st.gradB) { c ->
                st = st.copy(gradB = c, gradA = if (c != null && st.gradA == null) c else st.gradA)
            }
            ColorRow("Цвет текста сообщения", st.textColor) { c -> st = st.copy(textColor = c) }
            ColorRow("Подсветка строки", st.bgColor) { c -> st = st.copy(bgColor = c) }
            ColorRow("Цветная полоса слева", st.barColor) { c -> st = st.copy(barColor = c) }

            Text("Жирный ник", style = MaterialTheme.typography.labelLarge)
            ChipChoice(listOf("Как есть" to null, "Да" to true, "Нет" to false), st.bold, { v -> st = st.copy(bold = v) })
            Text("Курсив", style = MaterialTheme.typography.labelLarge)
            ChipChoice(listOf("Как есть" to null, "Да" to true, "Нет" to false), st.italic, { v -> st = st.copy(italic = v) })
            Text("Шрифт ника", style = MaterialTheme.typography.labelLarge)
            ChipChoice(
                listOf(
                    "Как есть" to null, "Без засечек" to "sans", "С засечками" to "serif",
                    "Моно" to "mono", "Рукописный" to "cursive",
                ),
                st.font,
                { v -> st = st.copy(font = v) },
            )

            OutlinedTextField(
                value = st.prefix ?: "",
                onValueChange = { v -> st = st.copy(prefix = v.take(6).ifEmpty { null }) },
                label = { Text("Значок перед ником (эмодзи или символ)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Emojis.forEach { e ->
                    FilterChip(
                        selected = st.prefix?.trim() == e,
                        onClick = { st = st.copy(prefix = "$e ") },
                        label = { Text(e) },
                    )
                }
            }

            val scale = st.scale ?: 1f
            Text("Размер текста: ×${"%.2f".format(scale)}", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = scale,
                onValueChange = { v ->
                    val r = (v * 20).toInt() / 20f
                    st = st.copy(scale = if (abs(r - 1f) < 0.03f) null else r)
                },
                valueRange = 0.8f..1.5f,
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        onSave(
                            rule.copy(
                                title = title.trim().ifEmpty { "Правило" },
                                roles = roles,
                                users = users.split(',', ' ', ';', '\n')
                                    .map { it.trim().removePrefix("@").lowercase() }
                                    .filter { it.isNotEmpty() }
                                    .distinct(),
                                style = st,
                            )
                        )
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Сохранить") }
                if (!isNew && !rule.builtin) {
                    OutlinedButton(onClick = onDelete, modifier = Modifier.weight(1f)) { Text("Удалить") }
                }
                TextButton(onClick = onDismiss) { Text("Отмена") }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}
